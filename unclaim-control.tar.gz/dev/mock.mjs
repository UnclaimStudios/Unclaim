// Faux Pelican + faux Cloudflare KV + fausses origines, pour tester le panneau en local sans rien d'autre.
//   Pelican (API client)  : http://localhost:4810/api/client/...   clé : pacc_mock
//   Cloudflare (KV)       : http://localhost:4810/client/v4/accounts/acc/storage/kv/namespaces/ns/values/state   jeton : cf_mock
//   Origines des sites    : http://localhost:4810/origin/<identifiant>  (200 si le serveur tourne, 502 sinon)
import { createServer } from "node:http";

export const MOCK_PORT = Number(process.env.MOCK_PORT || 4810);
const PELICAN_KEY = "pacc_mock";
const CF_TOKEN = "cf_mock";

const v = (env_variable, name, server_value, { editable = true, default_value = "", description = "" } = {}) =>
  ({ env_variable, name, server_value, is_editable: editable, default_value, description, rules: "nullable|string" });

export const servers = {
  a1b2c3d4: {
    name: "Unclaim.fr", description: "Site principal (TanStack Start)", state: "running",
    vars: [
      v("PUBLIC_URL", "Adresse publique", "https://unclaim.fr"),
      v("NODE_ENV", "Environnement", "production", { editable: false }),
      v("UNCLAIM_CLIENT_ID", "Unclaim Auth : client_id", "unclaim-fr"),
      v("UNCLAIM_CLIENT_SECRET", "Unclaim Auth : client_secret", "s3cr3t-unclaim-fr"),
      v("DATABASE_URL", "Base de données", "file:/home/container/data/site.db", { editable: false }),
    ],
    files: { "/.env": "# Site unclaim.fr\nSESSION_SECRET=0d1f2e3c4b5a\nRESEND_API_KEY=re_test_123\nCONTACT_EMAIL=contact@unclaim.fr\n\n# Fonctionnalités\nFEATURE_SHOP=0\n" },
  },
  e5f6a7b8: {
    name: "Unclaim Chat", description: "Chat de support (chat.unclaim.fr)", state: "running",
    vars: [
      v("PUBLIC_URL", "Adresse publique", "https://chat.unclaim.fr"),
      v("UNCLAIM_API_URL", "Unclaim Auth : adresse", "https://auth.unclaim.fr"),
      v("UNCLAIM_CLIENT_ID", "Unclaim Auth : client_id", "chat-unclaim"),
      v("UNCLAIM_CLIENT_SECRET", "Unclaim Auth : client_secret", "chat-secret-xyz"),
      v("ADMIN_DISCORD_IDS", "Super-admins (IDs Discord)", "1429078624056905731"),
      v("AI_API_KEY", "Assistant IA : clé API", ""),
      v("AI_MODEL", "Assistant IA : modèle", "gpt-4o-mini", { default_value: "gpt-4o-mini" }),
    ],
    files: {},
  },
  c9d0e1f2: {
    name: "Unclaim Auth", description: "Passerelle d'authentification", state: "running",
    vars: [],
    files: { "/.env": "NODE_ENV=production\nPORT=3000\nPUBLIC_URL=https://auth.unclaim.fr\nBEHIND_CLOUDFLARE=1\nADMIN_DISCORD_IDS=1429078624056905731\nDISCORD_CLIENT_ID=123456\nDISCORD_CLIENT_SECRET=abcdef\nUNCLAIM_MASTER_KEY=mk_9f8e7d\n" },
  },
  f3a4b5c6: {
    name: "Unclaim Radio", description: "Radio en continu", state: "offline",
    vars: [v("STREAM_URL", "Flux", "https://radio.unclaim.fr/live"), v("ICECAST_PASSWORD", "Mot de passe Icecast", "hackme")],
    files: { "/.env": "TITLE=Unclaim Radio\n" },
  },
};
export const kv = new Map();

function send(res, status, body, type = "application/json") {
  res.writeHead(status, { "Content-Type": type });
  res.end(body === undefined ? "" : typeof body === "string" ? body : JSON.stringify(body));
}
const pErr = (res, status, detail) => send(res, status, { errors: [{ code: "Error", status: String(status), detail }] });

async function body(req) {
  const chunks = [];
  for await (const c of req) chunks.push(c);
  return Buffer.concat(chunks).toString("utf8");
}

function setState(s, steps) {
  clearTimeout(s.timer);
  const [[state, ms], ...rest] = steps;
  s.state = state;
  if (rest.length) s.timer = setTimeout(() => setState(s, rest), ms);
}

async function handle(req, res) {
  const url = new URL(req.url, "http://localhost");
  const p = url.pathname;

  // --- fausses origines ---
  const o = p.match(/^\/origin\/(\w+)/);
  if (o) {
    const s = servers[o[1]];
    if (!s || s.state !== "running") return send(res, 502, "<h1>502 Bad Gateway</h1>", "text/html");
    return send(res, 200, `<h1>${s.name}</h1>`, "text/html");
  }

  // --- faux Cloudflare KV ---
  const k = p.match(/^\/client\/v4\/accounts\/[^/]+\/storage\/kv\/namespaces\/[^/]+\/values\/([^/]+)$/);
  if (k) {
    if (req.headers.authorization !== `Bearer ${CF_TOKEN}`) return send(res, 403, { success: false, errors: [{ code: 10000, message: "Authentication error" }] });
    if (req.method === "PUT") { kv.set(decodeURIComponent(k[1]), await body(req)); return send(res, 200, { success: true, errors: [], messages: [], result: null }); }
    if (kv.has(k[1])) return send(res, 200, kv.get(k[1]), "text/plain");
    return send(res, 404, { success: false, errors: [{ code: 10009, message: "key not found" }] });
  }

  // --- faux Pelican ---
  if (!p.startsWith("/api/client")) return send(res, 404, { error: "not found" });
  if (req.headers.authorization !== `Bearer ${PELICAN_KEY}`) return pErr(res, 401, "Unauthenticated.");
  if (p === "/api/client" || p === "/api/client/") {
    const data = Object.entries(servers).map(([identifier, s]) => ({
      object: "server", attributes: { identifier, uuid: `${identifier}-0000-4000-8000-000000000000`, name: s.name, description: s.description, node: "Node 1" },
    }));
    return send(res, 200, { object: "list", data, meta: { pagination: { total: data.length, count: data.length, per_page: 100, current_page: 1, total_pages: 1 } } });
  }
  const m = p.match(/^\/api\/client\/servers\/(\w+)\/(.+)$/);
  const s = m && servers[m[1]];
  if (!s) return pErr(res, 404, "The requested resource could not be found on the server.");
  const sub = m[2];

  if (req.method === "GET" && sub === "resources") {
    const running = s.state === "running";
    return send(res, 200, { object: "stats", attributes: { current_state: s.state, is_suspended: false, resources: {
      memory_bytes: running ? 90_000_000 + Math.round(Math.random() * 40_000_000) : 0, cpu_absolute: running ? Math.random() * 12 : 0,
      disk_bytes: 52_000_000, network_rx_bytes: 0, network_tx_bytes: 0, uptime: running ? 3_600_000 * 26 : 0 } } });
  }
  if (req.method === "POST" && sub === "power") {
    const { signal } = JSON.parse(await body(req) || "{}");
    if (signal === "start" || signal === "restart") setState(s, [[signal === "restart" ? "stopping" : "starting", 1000], ["starting", 2000], ["running", 0]]);
    else if (signal === "stop") setState(s, [["stopping", 1500], ["offline", 0]]);
    else if (signal === "kill") setState(s, [["offline", 0]]);
    else return pErr(res, 422, "Invalid signal.");
    return send(res, 204);
  }
  if (req.method === "GET" && sub === "startup") {
    return send(res, 200, { object: "list", data: s.vars.map((x) => ({ object: "egg_variable", attributes: x })),
      meta: { startup_command: "node server.mjs", raw_startup_command: "node server.mjs" } });
  }
  if (req.method === "PUT" && sub === "startup/variable") {
    const { key, value } = JSON.parse(await body(req) || "{}");
    const x = s.vars.find((y) => y.env_variable === key);
    if (!x || !x.is_editable) return pErr(res, 400, "The environment variable you are trying to edit does not exist.");
    x.server_value = value;
    return send(res, 200, { object: "egg_variable", attributes: x });
  }
  if (req.method === "GET" && sub === "files/contents") {
    const f = url.searchParams.get("file");
    if (!(f in s.files)) return pErr(res, 404, "The requested resource could not be found on the server.");
    return send(res, 200, s.files[f], "text/plain");
  }
  if (req.method === "POST" && sub === "files/write") {
    s.files[url.searchParams.get("file")] = await body(req);
    return send(res, 204);
  }
  return pErr(res, 404, "Not found");
}

export function startMock(port = MOCK_PORT) {
  return new Promise((resolve) => {
    const srv = createServer((req, res) => handle(req, res).catch((e) => pErr(res, 500, e.message)));
    srv.listen(port, () => resolve(srv));
  });
}

if (import.meta.url === `file://${process.argv[1]}` || process.argv[1]?.endsWith("mock.mjs")) {
  await startMock();
  console.log(`Faux Pelican + Cloudflare KV sur http://localhost:${MOCK_PORT}`);
}
