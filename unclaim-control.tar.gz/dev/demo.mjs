// Démo locale complète en un seul processus : faux Pelican + faux Cloudflare KV + panneau, sites d'exemple.
//   npm run demo   puis   http://localhost:4100   (« Connexion de test », ID Discord 1429078624056905731)
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";
import { startMock, MOCK_PORT } from "./mock.mjs";

const HERE = dirname(fileURLToPath(import.meta.url));
const mock = `http://localhost:${MOCK_PORT}`;
Object.assign(process.env, {
  PORT: process.env.PORT || "4100",
  PUBLIC_URL: process.env.PUBLIC_URL || `http://localhost:${process.env.PORT || 4100}`,
  DATA_DIR: process.env.DATA_DIR || join(HERE, "..", "data-demo"),
  NODE_ENV: "development",
  CONTROL_DEV_LOGIN: "1",
  ADMIN_DISCORD_IDS: process.env.ADMIN_DISCORD_IDS || "1429078624056905731",
  PELICAN_URL: mock,
  PELICAN_CLIENT_KEY: "pacc_mock",
  CF_API_URL: `${mock}/client/v4`,
  CF_API_TOKEN: "cf_mock",
  CF_ACCOUNT_ID: "acc",
  CF_KV_NAMESPACE_ID: "ns",
  BYPASS_SECRET: "demo-bypass-secret-change-me",
  PUBLIC_CONTACT_EMAIL: "contact@unclaim.fr",
  HEALTH_INTERVAL: "20",
});

await startMock();
const { get, run } = await import("../lib/db.mjs");
if (!get("SELECT COUNT(*) AS n FROM sites").n) {
  const add = (id, name, server, hosts, extra = {}) => run(
    `INSERT INTO sites (id, name, description, hosts, public_url, health_url, pelican_server, env_mode, contacts, support_email, position)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    id, name, extra.description || "", JSON.stringify(hosts), `https://${hosts[0]}`, `${mock}/origin/${server}`, server,
    extra.env_mode || "both", JSON.stringify(extra.contacts || ["tom@unclaim.fr"]), extra.support || "", extra.position || 0,
  );
  add("unclaim", "Unclaim.fr", "a1b2c3d4", ["unclaim.fr", "www.unclaim.fr"], { description: "Site principal", position: 1 });
  add("chat", "Unclaim Chat", "e5f6a7b8", ["chat.unclaim.fr"], { description: "Chat de support", env_mode: "startup", position: 2, support: "support@unclaim.fr" });
  add("auth", "Unclaim Auth", "c9d0e1f2", ["auth.unclaim.fr"], { description: "Passerelle d'authentification", env_mode: "dotenv", position: 3, contacts: ["tom@unclaim.fr", "securite@unclaim.fr"] });
  add("radio", "Unclaim Radio", "f3a4b5c6", ["radio.unclaim.fr"], { description: "Radio en continu", position: 4 });
  run("UPDATE sites SET status_group = 'Services', public_description = 'Site vitrine et boutique' WHERE id = 'unclaim'");
  run("UPDATE sites SET status_group = 'Services', public_description = 'Support en direct' WHERE id = 'chat'");
  run("UPDATE sites SET status_group = 'Comptes', public_name = 'Connexion Unclaim', public_description = 'auth.unclaim.fr' WHERE id = 'auth'");
  run("UPDATE sites SET status_group = 'Divertissement' WHERE id = 'radio'");

  // Historique fictif sur 90 jours (un test par minute), avec quelques pannes, pour une page de statut réaliste.
  const { parisDay, createIncident } = await import("../lib/status.mjs");
  const glitches = { unclaim: { 12: 38, 47: 4 }, chat: { 5: 12, 30: 90, 31: 6 }, auth: { 64: 3 }, radio: { 2: 300, 20: 45 } };
  for (const id of ["unclaim", "chat", "auth", "radio"]) {
    for (let i = 89; i >= 1; i--) {
      const down = glitches[id][i] || 0;
      const deg = i % 17 === 0 ? 20 : 0;
      const maint = id === "chat" && i === 40 ? 120 : 0;
      run("INSERT INTO uptime_daily (site_id, day, total, up, degraded, down, maintenance, ms_sum, ms_count) VALUES (?, ?, 1440, ?, ?, ?, ?, ?, ?)",
        id, parisDay(new Date(Date.now() - i * 86_400_000)), 1440 - down - deg - maint, deg, down, maint, 1400 * 80, 1400);
    }
  }
  const id = createIncident({ title: "Le chat ne répond plus", impact: "major", sites: ["chat"], body: "Le chat de support ne répond plus. Nous enquêtons.", author: "Tom" });
  const { addIncidentUpdate } = await import("../lib/status.mjs");
  addIncidentUpdate(id, { status: "identified", body: "Le serveur a manqué de mémoire après une mise à jour. Nous redémarrons avec plus de RAM.", author: "Tom" });
  addIncidentUpdate(id, { status: "resolved", body: "Le chat fonctionne de nouveau normalement. Les messages envoyés pendant la panne ont bien été reçus.", author: "Tom" });
  const t = (h) => new Date(Date.now() - h * 3_600_000).toISOString();
  run("UPDATE incidents SET created_at = ?, resolved_at = ? WHERE id = ?", t(50), t(48), id);
  const ups = (await import("../lib/db.mjs")).all("SELECT id FROM incident_updates WHERE incident_id = ? ORDER BY id", id);
  ups.forEach((u, k) => run("UPDATE incident_updates SET created_at = ? WHERE id = ?", t(50 - k), u.id));
}
await import("../server.mjs");
console.log(`Démo : faux Pelican/Cloudflare sur ${mock} · connexion de test avec l'ID Discord ${process.env.ADMIN_DISCORD_IDS}`);
