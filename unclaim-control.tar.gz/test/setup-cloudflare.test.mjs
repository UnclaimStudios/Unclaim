// Script de configuration Cloudflare, exécuté contre une fausse API Cloudflare.
import { test, before, after } from "node:test";
import assert from "node:assert/strict";
import { createServer } from "node:http";
import { execFile } from "node:child_process";
import { mkdtempSync, readFileSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";

const SCRIPT = join(dirname(fileURLToPath(import.meta.url)), "..", "scripts", "setup-cloudflare.mjs");
const TOKEN = "cf_test_token";
const cfState = { namespaces: [], routes: [], dns: [], scripts: {}, tokens: [] };
let server, base;

const ok = (res, result) => { res.writeHead(200, { "Content-Type": "application/json" }); res.end(JSON.stringify({ success: true, errors: [], result })); };
const ko = (res, status, message) => { res.writeHead(status, { "Content-Type": "application/json" }); res.end(JSON.stringify({ success: false, errors: [{ code: status, message }] })); };

before(async () => {
  server = createServer(async (req, res) => {
    if (req.headers.authorization !== `Bearer ${TOKEN}`) return ko(res, 403, "Invalid token");
    const chunks = [];
    for await (const c of req) chunks.push(c);
    const raw = Buffer.concat(chunks);
    const body = () => JSON.parse(raw.toString() || "{}");
    const p = new URL(req.url, "http://x").pathname.replace(/^\/client\/v4/, "");
    const m = req.method;
    if (m === "GET" && p === "/user/tokens/verify") return ok(res, { status: "active" });
    if (m === "GET" && p === "/zones") return ok(res, [{ id: "zone1", name: "unclaim.fr", account: { id: "acc1", name: "Unclaim" } }]);
    if (p === "/accounts/acc1/storage/kv/namespaces") {
      if (m === "GET") return ok(res, cfState.namespaces);
      const ns = { id: `ns${cfState.namespaces.length + 1}`, title: body().title };
      cfState.namespaces.push(ns);
      return ok(res, ns);
    }
    if (m === "PUT" && p.startsWith("/accounts/acc1/workers/scripts/")) {
      cfState.scripts[p.split("/").pop()] = raw.toString("latin1");
      return ok(res, { id: p.split("/").pop() });
    }
    if (p === "/zones/zone1/workers/routes") {
      if (m === "GET") return ok(res, cfState.routes);
      const r = { id: `r${cfState.routes.length + 1}`, ...body() };
      cfState.routes.push(r);
      return ok(res, r);
    }
    if (m === "PUT" && p.startsWith("/zones/zone1/workers/routes/")) {
      const r = cfState.routes.find((x) => x.id === p.split("/").pop());
      Object.assign(r, body());
      return ok(res, r);
    }
    if (p === "/zones/zone1/dns_records") {
      if (m === "GET") return ok(res, cfState.dns);
      cfState.dns.push(body());
      return ok(res, body());
    }
    if (m === "GET" && p === "/user/tokens/permission_groups") return ok(res, [{ id: "pg-kv", name: "Workers KV Storage Write" }, { id: "pg-x", name: "DNS Write" }]);
    if (m === "POST" && p === "/user/tokens") { cfState.tokens.push(body()); return ok(res, { id: "t1", value: "panel_kv_token" }); }
    return ko(res, 404, `route inconnue ${m} ${p}`);
  });
  await new Promise((r) => server.listen(0, r));
  base = `http://localhost:${server.address().port}/client/v4`;
});
after(() => server.close());

const dir = mkdtempSync(join(tmpdir(), "uc-cf-"));
writeFileSync(join(dir, "unclaim-edge.js"), "export default { fetch() { return new Response('ok'); } };");

const run = (args, token = TOKEN) => new Promise((resolve) => {
  execFile(process.execPath, [SCRIPT, ...args], { cwd: dir, env: { ...process.env, CF_API_URL: base, CLOUDFLARE_API_TOKEN: token } },
    (err, stdout, stderr) => resolve({ code: err?.code ?? 0, out: stdout + stderr }));
});

test("simulation : rien n'est créé", async () => {
  const r = await run(["--dry-run"]);
  assert.equal(r.code, 0, r.out);
  assert.match(r.out, /créer l'espace KV/);
  assert.equal(cfState.namespaces.length + cfState.routes.length + cfState.dns.length, 0);
});

test("jeton refusé : arrêt propre", async () => {
  const r = await run(["--yes"], "mauvais");
  assert.notEqual(r.code, 0);
  assert.match(r.out, /Jeton refusé/);
});

test("configuration complète puis relance sans doublon, avec le même secret", async () => {
  // le Worker cherche unclaim-edge.js à côté du script ; on lance depuis un dossier qui le contient
  const r = await run(["--yes"]);
  assert.equal(r.code, 0, r.out);
  assert.equal(cfState.namespaces.length, 1);
  assert.deepEqual(cfState.routes.map((x) => x.pattern).sort(), ["*.unclaim.fr/*", "unclaim.fr/*"]);
  assert.ok(cfState.routes.every((x) => x.script === "unclaim-edge"));
  assert.deepEqual(cfState.dns[0], { type: "AAAA", name: "status.unclaim.fr", content: "100::", proxied: true, comment: "Page de statut servie par le Worker unclaim-edge" });
  const upload = cfState.scripts["unclaim-edge"];
  assert.match(upload, /"name":"STATE","namespace_id":"ns1"/);
  assert.match(upload, /"type":"secret_text","name":"BYPASS_SECRET"/);
  assert.equal(cfState.tokens[0].policies[0].permission_groups[0].id, "pg-kv");

  const env = readFileSync(join(dir, "cloudflare-result.env"), "utf8");
  assert.match(env, /CF_ACCOUNT_ID=acc1/);
  assert.match(env, /CF_KV_NAMESPACE_ID=ns1/);
  assert.match(env, /CF_API_TOKEN=panel_kv_token/);
  const secret = env.match(/BYPASS_SECRET=([0-9a-f]{64})/)[1];
  assert.ok(!env.includes(TOKEN), "le jeton principal n'est jamais écrit");

  const again = await run(["--yes"]);
  assert.equal(again.code, 0, again.out);
  assert.equal(cfState.namespaces.length, 1);
  assert.equal(cfState.routes.length, 2);
  assert.equal(cfState.dns.length, 1);
  assert.match(readFileSync(join(dir, "cloudflare-result.env"), "utf8"), new RegExp(`BYPASS_SECRET=${secret}`));
});

test("route déjà prise par un autre Worker : refus sans --force, remplacée avec", async () => {
  cfState.routes.find((x) => x.pattern === "unclaim.fr/*").script = "ancien-worker";
  const r = await run(["--yes"]);
  assert.notEqual(r.code, 0);
  assert.match(r.out, /ancien-worker/);
  const f = await run(["--yes", "--force"]);
  assert.equal(f.code, 0, f.out);
  assert.equal(cfState.routes.find((x) => x.pattern === "unclaim.fr/*").script, "unclaim-edge");
});
