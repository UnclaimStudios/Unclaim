// Tests du Worker Cloudflare, exécuté dans Node avec un faux KV et un faux fetch vers l'origine.
import { test, beforeEach } from "node:test";
import assert from "node:assert/strict";
import { createHmac } from "node:crypto";

const SECRET = "secret-de-test";
const until = new Date(Date.now() + 3_600_000).toISOString();
const state = {
  v: 1, brand: "Unclaim", contact: "contact@unclaim.fr", status_url: "",
  sites: {
    chat: { name: "Unclaim Chat", maintenance: true, message: "Migration <en cours>", until, since: new Date().toISOString(), support: "" },
    site: { name: "Unclaim.fr", maintenance: false, message: "", until: null, since: null, support: "" },
  },
  hosts: { "chat.unclaim.fr": "chat", "unclaim.fr": "site" },
  status_host: "status.unclaim.fr",
};
const status = {
  updated_at: new Date().toISOString(), title: "État des services Unclaim", intro: "", announcement: "", contact: "", interval: 60,
  history_days: 1, overall: "operational", incidents: [], maintenances: [], history: [],
  groups: [{ name: "", sites: [{ id: "site", name: "Unclaim.fr", description: "", status: "online", latency_ms: 40, uptime: 1, days: [{ d: "2026-10-23", r: 1, down: 0, deg: 0, maint: 0, ms: 40 }] }] }],
};
const env = { BYPASS_SECRET: SECRET, STATE: { get: async (key) => (key === "status" ? status : state) } };

let origin;
globalThis.fetch = async (req) => origin(req);
const { default: worker } = await import("../worker/worker.js");

const sign = (exp) => {
  const payload = Buffer.from(JSON.stringify({ u: "x", exp })).toString("base64url");
  return `${payload}.${createHmac("sha256", SECRET).update(payload).digest("base64url")}`;
};
const req = (url, headers = {}) => new Request(url, { headers: { Accept: "text/html", ...headers } });

beforeEach(() => { origin = async () => new Response("origine", { status: 200 }); });

test("site en maintenance : page 503 avec Retry-After, message échappé", async () => {
  const res = await worker.fetch(req("https://chat.unclaim.fr/"), env);
  assert.equal(res.status, 503);
  assert.ok(Number(res.headers.get("Retry-After")) > 3000);
  const html = await res.text();
  assert.match(html, /Maintenance en cours/);
  assert.match(html, /Migration &lt;en cours&gt;/);
  assert.match(html, /contact@unclaim\.fr/);
});

test("maintenance : réponse JSON pour une requête d'API", async () => {
  const res = await worker.fetch(new Request("https://chat.unclaim.fr/api/x", { headers: { Accept: "application/json" } }), env);
  assert.equal(res.status, 503);
  assert.equal((await res.json()).error, "maintenance");
});

test("maintenance : le staff passe avec un jeton valide, pas avec un jeton expiré ou falsifié", async () => {
  const ok = await worker.fetch(req("https://chat.unclaim.fr/", { Cookie: `a=1; uc_bypass=${sign(Math.floor(Date.now() / 1000) + 600)}` }), env);
  assert.equal(await ok.text(), "origine");
  const expired = await worker.fetch(req("https://chat.unclaim.fr/", { Cookie: `uc_bypass=${sign(Math.floor(Date.now() / 1000) - 5)}` }), env);
  assert.equal(expired.status, 503);
  const forged = sign(Math.floor(Date.now() / 1000) + 600).replace(/.$/, (c) => (c === "A" ? "B" : "A"));
  assert.equal((await worker.fetch(req("https://chat.unclaim.fr/", { Cookie: `uc_bypass=${forged}` }), env)).status, 503);
});

test("site en ligne : la réponse de l'origine passe telle quelle", async () => {
  const res = await worker.fetch(req("https://unclaim.fr/"), env);
  assert.equal(res.status, 200);
  assert.equal(await res.text(), "origine");
});

test("erreurs Cloudflare 52x : remplacées par la page Unclaim", async () => {
  for (const code of [521, 522, 530]) {
    origin = async () => new Response("cloudflare", { status: code });
    const res = await worker.fetch(req("https://unclaim.fr/"), env);
    assert.equal(res.status, code);
    const html = await res.text();
    assert.match(html, /Unclaim\.fr/);
    assert.match(html, new RegExp(`Erreur ${code}`));
  }
});

test("502 de l'origine : page Unclaim pour un navigateur, inchangé pour une API ou avec X-Unclaim-Passthrough", async () => {
  origin = async () => new Response("bad gateway", { status: 502 });
  assert.match(await (await worker.fetch(req("https://unclaim.fr/"), env)).text(), /rencontre un problème/);
  const api = await worker.fetch(new Request("https://unclaim.fr/api", { headers: { Accept: "application/json" } }), env);
  assert.equal(await api.text(), "bad gateway");
  origin = async () => new Response("page de l'appli", { status: 503, headers: { "X-Unclaim-Passthrough": "1" } });
  assert.equal(await (await worker.fetch(req("https://unclaim.fr/"), env)).text(), "page de l'appli");
});

test("origine injoignable : page 502 ; hôte inconnu : page générique", async () => {
  origin = async () => { throw new Error("connexion refusée"); };
  const res = await worker.fetch(req("https://inconnu.unclaim.fr/"), env);
  assert.equal(res.status, 502);
  assert.match(await res.text(), /inconnu\.unclaim\.fr/);
});

test("KV indisponible : le trafic passe quand même", async () => {
  const broken = { BYPASS_SECRET: SECRET, STATE: { get: async () => { throw new Error("KV"); } } };
  // nouvel import pour repartir sans cache
  const { default: w } = await import(`../worker/worker.js?kv=${Date.now()}`);
  const res = await w.fetch(req("https://chat.unclaim.fr/"), broken);
  assert.equal(res.status, 200);
});

test("page de statut : servie par le Worker sans contacter d'origine", async () => {
  origin = async () => { throw new Error("aucune origine ne doit être appelée"); };
  const page = await worker.fetch(req("https://status.unclaim.fr/"), env);
  assert.equal(page.status, 200);
  assert.match(await page.text(), /Tous les services sont opérationnels/);
  const api = await worker.fetch(req("https://status.unclaim.fr/api/status.json"), env);
  assert.equal((await api.json()).components[0].name, "Unclaim.fr");
  assert.equal(api.headers.get("Access-Control-Allow-Origin"), "*");
  assert.match(await (await worker.fetch(req("https://status.unclaim.fr/feed.atom"), env)).text(), /<feed/);
  const other = await worker.fetch(req("https://status.unclaim.fr/nimporte"), env);
  assert.equal(other.status, 302);
});

test("maintenance prioritaire : servie même si le site répond normalement", async () => {
  let called = false;
  origin = async () => { called = true; return new Response("site en ligne", { status: 200 }); };
  const res = await worker.fetch(req("https://chat.unclaim.fr/page"), env);
  assert.equal(res.status, 503);
  assert.equal(called, false, "l'origine n'est même pas contactée");
});
