// Test de bout en bout : panneau + faux Pelican + faux Cloudflare KV (dev/demo.mjs) dans un processus séparé.
import { test, before, after } from "node:test";
import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = join(dirname(fileURLToPath(import.meta.url)), "..");
const PORT = 4199;
const MOCK = 4899;
const BASE = `http://localhost:${PORT}`;
const SUPER = "1429078624056905731";
const STAFF = "222222222222222222";
const dir = mkdtempSync(join(tmpdir(), "uc-control-e2e-"));
let child;

before(async () => {
  child = spawn(process.execPath, ["dev/demo.mjs"], {
    cwd: ROOT,
    env: { ...process.env, PORT: String(PORT), MOCK_PORT: String(MOCK), DATA_DIR: dir, PUBLIC_URL: BASE, ADMIN_DISCORD_IDS: SUPER, HEALTH_INTERVAL: "600" },
    stdio: ["ignore", "pipe", "pipe"],
  });
  child.stderr.on("data", (d) => process.stderr.write(d));
  for (let i = 0; i < 100; i++) {
    try { if ((await fetch(`${BASE}/health`)).ok) return; } catch { /* pas encore prêt */ }
    await new Promise((r) => setTimeout(r, 100));
  }
  throw new Error("Le panneau n'a pas démarré");
});
after(() => { child?.kill(); try { rmSync(dir, { recursive: true, force: true }); } catch { /* Windows : base encore ouverte */ } });

async function login(discordId) {
  const res = await fetch(`${BASE}/auth/start?dev=${discordId}&name=Test`, { redirect: "manual" });
  const cookies = res.headers.getSetCookie();
  return { status: res.status, cookies, jar: cookies.map((c) => c.split(";")[0]).join("; ") };
}
const call = (jar, method, path, body, headers = {}) => fetch(`${BASE}${path}`, {
  method,
  headers: { Cookie: jar, Origin: BASE, ...(body ? { "Content-Type": "application/json" } : {}), ...headers },
  body: body ? JSON.stringify(body) : undefined,
});
const kv = async () => JSON.parse(await (await fetch(`http://localhost:${MOCK}/client/v4/accounts/acc/storage/kv/namespaces/ns/values/state`, { headers: { Authorization: "Bearer cf_mock" } })).text());

test("sans session : 401 ; compte inconnu : 403", async () => {
  assert.equal((await fetch(`${BASE}/api/sites`)).status, 401);
  assert.equal((await login("999999999999999999")).status, 403);
});

test("super-admin : sites, variables Pelican, .env, maintenance publiée dans KV", async () => {
  const s = await login(SUPER);
  assert.equal(s.status, 302);
  assert.ok(s.cookies.some((c) => c.startsWith("uc_bypass=")), "cookie de contournement posé");

  const sites = (await (await call(s.jar, "GET", "/api/sites")).json()).sites;
  assert.deepEqual(sites.map((x) => x.id), ["unclaim", "chat", "auth", "radio"]);

  // variables de démarrage
  const env = await (await call(s.jar, "GET", "/api/sites/unclaim/env")).json();
  assert.equal(env.startup.variables.find((v) => v.key === "UNCLAIM_CLIENT_SECRET").secret, true);
  assert.equal(env.dotenv.entries.find((e) => e.key === "CONTACT_EMAIL").value, "contact@unclaim.fr");
  let r = await call(s.jar, "PUT", "/api/sites/unclaim/env/startup", { changes: { PUBLIC_URL: "https://www.unclaim.fr" } });
  assert.equal(r.status, 200);
  r = await call(s.jar, "PUT", "/api/sites/unclaim/env/startup", { changes: { NODE_ENV: "development" } });
  assert.equal(r.status, 400, "variable verrouillée refusée");
  const after = await (await call(s.jar, "GET", "/api/sites/unclaim/env")).json();
  assert.equal(after.startup.variables.find((v) => v.key === "PUBLIC_URL").value, "https://www.unclaim.fr");

  // .env : modification, suppression, création du fichier quand il n'existe pas
  r = await (await call(s.jar, "PUT", "/api/sites/unclaim/env/dotenv", { changes: { FEATURE_SHOP: "1", RESEND_API_KEY: null } })).json();
  assert.match(r.raw, /# Fonctionnalités\nFEATURE_SHOP=1/);
  assert.doesNotMatch(r.raw, /RESEND_API_KEY/);
  const chatEnv = await (await call(s.jar, "PATCH", "/api/sites/chat", { env_mode: "both" })).json();
  assert.equal(chatEnv.site.env_mode, "both");
  const created = await (await call(s.jar, "PUT", "/api/sites/chat/env/dotenv", { changes: { NEW_VAR: "ok" } })).json();
  assert.equal(created.raw, "NEW_VAR=ok\n");
  assert.equal((await call(s.jar, "PUT", "/api/sites/chat/env/dotenv", { changes: { "BAD KEY": "x" } })).status, 400);

  // maintenance de tous les sites → KV
  r = await (await call(s.jar, "POST", "/api/maintenance", { sites: "all", enabled: true, message: "Mise à jour", until: new Date(Date.now() + 3600e3).toISOString() })).json();
  assert.equal(r.published, true);
  let state = await kv();
  assert.equal(Object.values(state.sites).filter((x) => x.maintenance).length, 4);
  assert.equal(state.hosts["www.unclaim.fr"], "unclaim");
  assert.equal(state.sites.auth.message, "Mise à jour");
  assert.equal(JSON.stringify(state).includes("tom@unclaim.fr"), false, "les emails internes ne sont pas publiés");

  // fin de maintenance pour un seul site
  await call(s.jar, "POST", "/api/maintenance", { sites: ["radio"], enabled: false });
  state = await kv();
  assert.equal(state.sites.radio.maintenance, false);
  assert.equal(state.sites.chat.maintenance, true);
  await call(s.jar, "POST", "/api/maintenance", { sites: "all", enabled: false });

  // redémarrage et vérification
  assert.equal((await call(s.jar, "POST", "/api/sites/radio/power", { signal: "start" })).status, 200);
  const checked = await (await call(s.jar, "POST", "/api/sites/unclaim/check")).json();
  assert.equal(checked.site.status, "online");

  // journal : noms de variables, jamais les valeurs
  const audit = (await (await call(s.jar, "GET", "/api/audit")).json()).entries;
  assert.ok(audit.some((e) => e.action === "variables de démarrage modifiées" && e.detail === "PUBLIC_URL"));
  assert.ok(!JSON.stringify(audit).includes("www.unclaim.fr\""), "aucune valeur dans le journal");
});

test("staff : maintenance et redémarrage oui, variables et arrêt non ; retrait immédiat", async () => {
  const s = await login(SUPER);
  assert.equal((await call(s.jar, "POST", "/api/staff", { discord_id: STAFF, note: "support" })).status, 201);
  const st = await login(STAFF);
  assert.equal(st.status, 302);
  assert.equal((await call(st.jar, "GET", "/api/sites/chat/env")).status, 403);
  assert.equal((await call(st.jar, "PUT", "/api/sites/chat/env/dotenv", { changes: { A: "1" } })).status, 403);
  assert.equal((await call(st.jar, "POST", "/api/sites/chat/power", { signal: "stop" })).status, 403);
  assert.equal((await call(st.jar, "POST", "/api/sites/chat/power", { signal: "restart" })).status, 200);
  assert.equal((await call(st.jar, "POST", "/api/maintenance", { sites: ["chat"], enabled: true })).status, 200);
  assert.equal((await call(st.jar, "PATCH", "/api/sites/chat", { name: "X" })).status, 403);
  const site = (await (await call(st.jar, "GET", "/api/sites/chat")).json()).site;
  assert.equal(site.env_file, undefined, "le chemin du .env n'est pas exposé au staff");
  await call(st.jar, "POST", "/api/maintenance", { sites: ["chat"], enabled: false });

  await call(s.jar, "DELETE", `/api/staff/${STAFF}`);
  assert.equal((await call(st.jar, "GET", "/api/sites")).status, 401);
});

test("CSRF : une requête venant d'un autre site est refusée", async () => {
  const s = await login(SUPER);
  const r = await call(s.jar, "POST", "/api/maintenance", { sites: "all", enabled: true }, { Origin: "https://evil.example" });
  assert.equal(r.status, 403);
});

test("validation des sites : hôte en double, identifiant invalide", async () => {
  const s = await login(SUPER);
  assert.equal((await call(s.jar, "POST", "/api/sites", { id: "doublon", name: "D", hosts: "chat.unclaim.fr" })).status, 409);
  assert.equal((await call(s.jar, "POST", "/api/sites", { id: "A B", name: "D" })).status, 400);
  const ok = await call(s.jar, "POST", "/api/sites", { id: "suite", name: "Unclaim Suite", hosts: "suite.unclaim.fr", public_url: "https://suite.unclaim.fr/", contacts: "a@unclaim.fr, b@unclaim.fr" });
  assert.equal(ok.status, 201);
  const site = (await ok.json()).site;
  assert.equal(site.public_url, "https://suite.unclaim.fr");
  assert.deepEqual(site.contacts, ["a@unclaim.fr", "b@unclaim.fr"]);
  assert.equal((await call(s.jar, "DELETE", "/api/sites/suite")).status, 200);
});

const kvStatus = async () => JSON.parse(await (await fetch(`http://localhost:${MOCK}/client/v4/accounts/acc/storage/kv/namespaces/ns/values/status`, { headers: { Authorization: "Bearer cf_mock" } })).text());

test("page de statut : incidents automatiques, incidents manuels, réglages, publication KV", async () => {
  const s = await login(SUPER);
  // Incident automatique dès la première panne constatée
  let r = await call(s.jar, "PUT", "/api/status/settings", { auto_incidents: true, auto_delay: 0, title: "État Unclaim", host: "status.unclaim.fr" });
  assert.equal(r.status, 200);
  await call(s.jar, "POST", "/api/sites/radio/power", { signal: "kill" });
  await call(s.jar, "POST", "/api/sites/radio/check");
  await call(s.jar, "POST", "/api/sites/radio/check");
  let st = await (await call(s.jar, "GET", "/api/status")).json();
  const auto = st.incidents.find((i) => i.auto && i.status !== "resolved" && i.sites.includes("radio"));
  assert.ok(auto, "incident automatique ouvert");
  assert.deepEqual(auto.sites, ["radio"]);

  // Publié dans KV : la page de statut le montre, et l'hôte est connu du Worker
  let pub = await kvStatus();
  assert.equal(pub.title, "État Unclaim");
  assert.ok(pub.incidents.some((i) => i.id === auto.id));
  assert.equal(pub.groups.flatMap((g) => g.sites).find((x) => x.id === "radio").status, "down");
  assert.equal((await kv()).status_host, "status.unclaim.fr");
  assert.equal(JSON.stringify(pub).includes("f3a4b5c6"), false, "aucun identifiant Pelican publié");

  // Retour en ligne → résolu automatiquement
  await call(s.jar, "POST", "/api/sites/radio/power", { signal: "start" });
  await new Promise((res) => setTimeout(res, 3500));
  const back = await (await call(s.jar, "POST", "/api/sites/radio/check")).json();
  assert.equal(back.site.status, "online");
  st = await (await call(s.jar, "GET", "/api/status")).json();
  assert.equal(st.incidents.find((i) => i.id === auto.id).status, "resolved");

  // Incident déclaré à la main, mis à jour puis résolu (tous les sites d'abord revérifiés : ils sont en ligne)
  await call(s.jar, "POST", "/api/sites/check");
  r = await call(s.jar, "POST", "/api/incidents", { title: "Lenteurs", impact: "minor", body: "On enquête", sites: ["chat"] });
  const { id } = await r.json();
  pub = await kvStatus();
  assert.equal(pub.overall, "degraded");
  assert.equal(pub.groups.flatMap((g) => g.sites).find((x) => x.id === "chat").status, "degraded");
  assert.equal((await call(s.jar, "POST", `/api/incidents/${id}/updates`, { status: "nimporte", body: "x" })).status, 400);
  await call(s.jar, "POST", `/api/incidents/${id}/updates`, { status: "resolved", body: "Corrigé" });
  pub = await kvStatus();
  assert.equal(pub.incidents.length, 0);
  assert.equal(pub.history.find((i) => i.id === id).updates[0].body, "Corrigé");

  // Site masqué de la page, et texte attendu absent → hors ligne
  await call(s.jar, "PATCH", "/api/sites/auth", { status_public: false, health_keyword: "texte-introuvable" });
  const auth = await (await call(s.jar, "POST", "/api/sites/auth/check")).json();
  assert.equal(auth.site.status, "down");
  assert.match(auth.site.status_detail, /introuvable/);
  const page = await (await fetch(`${BASE}/status`)).text();
  assert.doesNotMatch(page, /Unclaim Auth/);
  await call(s.jar, "PATCH", "/api/sites/auth", { status_public: true, health_keyword: "" });

  // le staff déclare des incidents mais ne touche pas aux réglages
  await call(s.jar, "POST", "/api/staff", { discord_id: "333333333333333333" });
  const staff = await login("333333333333333333");
  assert.equal((await call(staff.jar, "PUT", "/api/status/settings", { title: "x" })).status, 403);
  assert.equal((await call(staff.jar, "POST", "/api/incidents", { title: "T", body: "B" })).status, 201);
});
