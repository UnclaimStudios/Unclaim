// Tests unitaires : fichier .env et calcul de l'état d'un site.
import { test } from "node:test";
import assert from "node:assert/strict";
import { mkdtempSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";

process.env.DATA_DIR = mkdtempSync(join(tmpdir(), "uc-control-unit-"));
const { applyEnv, parseEnv, isSecretKey } = await import("../lib/dotenv.mjs");
const { decide } = await import("../lib/monitor.mjs");

test("parseEnv lit guillemets, export, commentaires et doublons", () => {
  const env = parseEnv('# c\nA=1\nexport B="deux mots"\nC=\'x # y\'\nD=val # commentaire\nA=2\n\nE=');
  assert.deepEqual(env, [
    { key: "A", value: "2" }, { key: "B", value: "deux mots" }, { key: "C", value: "x # y" }, { key: "D", value: "val" }, { key: "E", value: "" },
  ]);
});

test("applyEnv conserve les commentaires et modifie, ajoute, supprime", () => {
  const src = "# Site\nA=1\nB=2\n\n# fin\nC=3\nA=doublon\n";
  const out = applyEnv(src, { A: "un", B: null, D: "avec espace" });
  assert.equal(out, '# Site\nA=un\n\n# fin\nC=3\nD="avec espace"\n');
  assert.deepEqual(parseEnv(out).map((e) => e.key), ["A", "C", "D"]);
});

test("applyEnv garde les fins de ligne Windows et échappe les valeurs", () => {
  const out = applyEnv("A=1\r\nB=2\r\n", { B: 'a"b\\c' });
  assert.equal(out, 'A=1\r\nB="a\\"b\\\\c"\r\n');
  assert.equal(parseEnv(out)[1].value, 'a"b\\c');
});

test("applyEnv sur un fichier vide crée les lignes", () => {
  assert.equal(applyEnv("", { X: "1" }), "X=1\n");
});

test("isSecretKey repère les secrets", () => {
  for (const k of ["UNCLAIM_CLIENT_SECRET", "API_KEY", "GIT_TOKEN", "DB_PASSWORD", "SENTRY_DSN", "DISCORD_WEBHOOK_URL"]) assert.ok(isSecretKey(k), k);
  for (const k of ["PORT", "PUBLIC_URL", "NODE_ENV", "KEYCLOAK_URL"]) assert.ok(!isSecretKey(k), k);
});

test("decide : Pelican, HTTP et maintenance", () => {
  const site = { maintenance: 0 };
  assert.equal(decide(site, { state: "running" }, { code: 200, ms: 40 }).status, "online");
  assert.equal(decide(site, { state: "offline" }, { code: 502, ms: 10 }).status, "down");
  assert.equal(decide(site, { state: "starting" }, null).status, "degraded");
  assert.equal(decide(site, { state: "running" }, { code: 503, ms: 10 }).status, "down");
  assert.equal(decide(site, { state: "running" }, { code: null, ms: 8000, error: "délai" }).status, "down");
  assert.equal(decide(site, { state: "running" }, { code: 200, ms: 5000 }).status, "degraded");
  assert.equal(decide(site, { error: "Pelican 500" }, { code: 200, ms: 20 }).status, "degraded");
  assert.equal(decide(site, null, { code: 301, ms: 20 }).status, "online");
  assert.equal(decide(site, null, null).status, "unknown");
  const m = decide({ maintenance: 1 }, { state: "offline" }, null);
  assert.equal(m.status, "maintenance");
  assert.match(m.detail, /arrêté/);
});

const { codeMatcher } = await import("../lib/monitor.mjs");
const { overallOf } = await import("../lib/status.mjs");
const { statusPage, statusJson, atomFeed } = await import("../worker/status.js");

test("codeMatcher : plages et listes de codes", () => {
  const m = codeMatcher("200-299, 418");
  assert.ok(m(204) && m(418) && !m(301) && !m(500));
  assert.ok(codeMatcher("")(302) && !codeMatcher("")(404), "défaut 200-399");
});

test("decide : réponse refusée par les codes attendus ou le texte attendu", () => {
  const r = decide({ maintenance: 0 }, null, { code: 200, ms: 20, ok: false, error: "Texte « Unclaim » absent de la réponse" });
  assert.equal(r.status, "down");
  assert.match(r.detail, /absent/);
});

test("overallOf : du plus grave au plus calme", () => {
  const s = (status) => ({ status });
  assert.equal(overallOf([s("online"), s("online")], []), "operational");
  assert.equal(overallOf([s("online"), s("degraded")], []), "degraded");
  assert.equal(overallOf([s("online"), s("online"), s("down")], []), "partial");
  assert.equal(overallOf([s("down"), s("down"), s("online")], []), "major");
  assert.equal(overallOf([s("online"), s("maintenance")], []), "maintenance");
  assert.equal(overallOf([s("online")], [{ impact: "minor" }]), "degraded");
  assert.equal(overallOf([s("online")], [{ impact: "critical" }]), "major");
});

test("page de statut : rendu, échappement, JSON et flux Atom", () => {
  const now = new Date().toISOString();
  const day = (r) => ({ d: "2026-10-20", r, down: r === 1 ? 0 : 5, deg: 0, maint: 0, ms: 50 });
  const data = {
    updated_at: now, title: "État <Unclaim>", intro: "", announcement: "Info", contact: "c@unclaim.fr", interval: 60, history_days: 3,
    overall: "partial",
    groups: [{ name: "Services", sites: [{ id: "chat", name: "Chat", description: "", status: "down", latency_ms: null, uptime: 0.98765, days: [day(1), day(0.9), day(null)] }] }],
    incidents: [{ id: 7, title: "Panne <chat>", impact: "major", status: "investigating", sites: ["Chat"], created_at: now, resolved_at: null, updates: [{ status: "investigating", body: "On regarde", created_at: now }] }],
    maintenances: [], history: [],
  };
  const html = statusPage(data, { host: "status.unclaim.fr" });
  assert.match(html, /État &lt;Unclaim&gt;/);
  assert.match(html, /Panne &lt;chat&gt;/);
  assert.match(html, /Panne partielle en cours/);
  assert.match(html, /98,76 %/);
  assert.equal((html.match(/<i class="(ok|warn|bad|none|maint)"/g) || []).length, 3);
  const j = statusJson(data);
  assert.equal(j.status.indicator, "partial");
  assert.equal(j.components[0].status, "down");
  assert.match(atomFeed(data, "https://status.unclaim.fr"), /<entry><id>https:\/\/status\.unclaim\.fr\/#incident-7/);
  assert.match(statusPage(null), /pas encore été publiée/);
});
