# Unclaim Control

Panneau staff de tous les sites Unclaim hébergés sur Pelican : **control.unclaim.fr**.

- **Tableau de bord** : chaque site avec son état (en ligne, dégradé, hors ligne, maintenance), l'état de son serveur Pelican (RAM, CPU, durée de fonctionnement), le code HTTP et le temps de réponse, et les emails de contact. Un test automatique a lieu chaque minute, et une alerte Discord est envoyée si tu le souhaites.
- **Maintenance** : en un clic, pour tous les sites ou seulement certains, avec un message et une fin estimée. Les visiteurs voient « Maintenance en cours », tandis que le staff connecté au panneau continue de voir les sites normalement.
- **Pages d'erreur Unclaim** : elles remplacent les pages 502/521/522/530 de Cloudflare et expliquent ce qui se passe.
- **Page de statut publique** (`status.unclaim.fr`), façon GitHub Status ou Discord Status : état de chaque site, historique de disponibilité sur 90 jours, incidents avec leurs mises à jour, maintenances en cours, flux Atom et API JSON. Les incidents s'ouvrent et se ferment tout seuls quand un site tombe ou revient, et le staff peut en déclarer à la main. Tout se règle depuis l'onglet **Statut** : titre, annonce, sites affichés, groupes, ce qui compte comme « joignable ».
- **Variables d'environnement par site** : variables de démarrage de l'œuf Pelican **et/ou** fichier `.env` du serveur. On peut les modifier puis redémarrer, et chaque modification est journalisée (noms des variables seulement, jamais les valeurs).
- **Connexion Unclaim Auth** (PKCE). Les **super-admins** (`ADMIN_DISCORD_IDS`) ont accès à tout. Le **staff**, ajouté depuis le panneau, voit l'état, gère la maintenance et peut démarrer ou redémarrer un serveur.

Node ≥ 22.13, **aucune dépendance npm**, base SQLite (`node:sqlite`) dans `data/`.

## Comment ça marche

```
Visiteur ──► Cloudflare ──► Worker « unclaim-edge » ──► serveur Pelican du site (tunnel ou proxy)
                              │  lit l'état dans Workers KV (clé « state »)
                              │  · status.unclaim.fr → page de statut (clé « status »), sans aucun serveur derrière
                              │  · site en maintenance → page Maintenance (503), sauf cookie staff signé
                              │  · origine injoignable / 502-504 / 52x / 530 → page Erreur Unclaim
                              ▲
Unclaim Control ──────────────┘  écrit l'état dans KV (API Cloudflare) à chaque changement
      │
      └──► API client Pelican : état et ressources, start/restart/stop, variables de démarrage, lecture/écriture du .env
```

- **Les pages sont intégrées au Worker** : elles s'affichent même si le serveur du site, Pelican ou le panneau sont arrêtés. C'est aussi vrai pour la page de statut, qui montre la dernière version publiée.
- **La maintenance passe toujours en premier** : pour un site en maintenance, le Worker répond sans même contacter le serveur, donc la page s'affiche aussi quand le site répond normalement.
- **L'état est dans Workers KV** : si le panneau tombe, la maintenance en cours reste affichée. Un changement met **30 à 60 secondes** à atteindre tous les points de présence Cloudflare.
- **Les secrets** (clé Pelican, jeton Cloudflare, client Unclaim) restent dans les variables du serveur du panneau, jamais en base. KV ne reçoit que des informations publiques : nom du site, message, fin estimée, email public.

## Essayer en local (faux Pelican + faux Cloudflare)

```bash
npm run demo
```

Ouvre http://localhost:4100, puis « Connexion de test » avec l'ID Discord `1429078624056905731`. Quatre sites d'exemple sont branchés sur un faux Pelican (`dev/mock.mjs`, port 4810). La radio y est éteinte, et tu peux l'allumer depuis le panneau.

```bash
npm test
```

Les 26 tests couvrent :
- le fichier `.env`, le calcul d'état, les codes attendus ;
- la page de statut (rendu, JSON, Atom) ;
- le Worker : maintenance prioritaire, cookie staff, pages d'erreur, page de statut, KV en panne ;
- un parcours complet du panneau contre le faux Pelican : rôles, variables, maintenance et statut publiés dans KV, incidents automatiques, CSRF.

La page de statut de la démo est sur http://localhost:4100/status, avec 90 jours d'historique fictif.

---

## Installation sur Pelican

### 1. Importer l'œuf

Panel admin › **Eggs** › **Import** › `pelican/egg-unclaim-control.json`. Image : `ghcr.io/parkervcp/yolks:nodejs_22`.

Après une modification de `pelican/install-control.sh`, lance `npm run egg` pour régénérer le JSON.

### 2. Créer le serveur

Panel admin › **Servers › Create** : œuf **Unclaim Control**, 256 Mo de RAM, 1 Go de disque, et un port libre (ex. 4100).

Source du code : `GIT_REPO` (+ `GIT_SUBDIR=unclaim-control` si le panneau est dans un sous-dossier), ou `ARCHIVE_URL`. Tu peux aussi déposer `unclaim-control.tar.gz` dans le gestionnaire de fichiers, puis faire clic droit › **Unarchive**.

Le serveur est « en ligne » quand la console affiche `Unclaim Control sur https://control.unclaim.fr`.

### 3. Remplir les variables

Toutes les variables sont décrites dans `.env.example`. L'essentiel :

| Variable | Valeur |
|---|---|
| `PUBLIC_URL` | `https://control.unclaim.fr` |
| `UNCLAIM_CLIENT_ID` / `UNCLAIM_CLIENT_SECRET` | Application « Unclaim Control » sur auth.unclaim.fr, URL de retour `https://control.unclaim.fr/auth/callback` |
| `ADMIN_DISCORD_IDS` | Ton ID Discord |
| `PELICAN_URL` / `PELICAN_CLIENT_KEY` | Voir l'étape 4 |
| `CF_API_TOKEN` / `CF_ACCOUNT_ID` / `CF_KV_NAMESPACE_ID` | Voir la partie Cloudflare |
| `BYPASS_SECRET` | `openssl rand -hex 32`, même valeur que le secret du Worker |
| `COOKIE_DOMAIN` | `.unclaim.fr` |

### 4. Clé API Pelican

Le panneau parle à Pelican avec l'**API client**, celle des utilisateurs :

1. Connecte-toi à Pelican avec un compte qui a accès à **tous** les serveurs Unclaim : le propriétaire, un administrateur, ou un sous-utilisateur ajouté sur chaque serveur avec les permissions *Control*, *Startup* (lecture + modification) et *File* (lecture + écriture).
2. **Compte › Clés API › Créer**. Restreins-la à l'IP du nœud qui héberge le panneau si tu peux.
3. Colle-la dans `PELICAN_CLIENT_KEY`.

> **Variables verrouillées.** L'API client ne modifie que les variables marquées « modifiable par l'utilisateur » dans l'œuf. Les autres s'affichent avec le tag *verrouillée* : rends-les modifiables dans l'œuf (Admin › Eggs › Variables), ou passe par le fichier `.env`.

### 5. Domaine

Comme pour les autres sites : une entrée `control.unclaim.fr` dans le tunnel Cloudflare (`cloudflared`), ou un proxy (Caddy/Nginx) vers `IP_DU_NŒUD:PORT`. Le nom doit être **proxifié par Cloudflare** (nuage orange).

---

## Cloudflare : le Worker des pages d'erreur et de maintenance

Le code se trouve dans `worker/` : `worker.js` pour la logique, `pages.js` pour les pages.

### Avec Wrangler (recommandé)

```bash
cd worker
npx wrangler login
npx wrangler kv namespace create STATE        # → recopie l'id dans wrangler.toml ET dans CF_KV_NAMESPACE_ID
npx wrangler secret put BYPASS_SECRET          # même valeur que dans le panneau
npx wrangler deploy
```

Dans `wrangler.toml`, ajuste les routes (`unclaim.fr/*`, `*.unclaim.fr/*`) pour couvrir tous les sites.

### Sans Wrangler (tableau de bord)

1. Lance `npm run worker:build`, qui produit `worker/dist/unclaim-edge.js` (un seul fichier).
2. Cloudflare › **Workers & Pages › Créer › Worker** : colle le fichier, puis déploie.
3. Dans les **Paramètres du Worker** :
   - Liaisons › KV : nom **`STATE`**, vers un espace créé dans **Stockage › KV** ;
   - Variables › secret **`BYPASS_SECRET`** ;
   - Déclencheurs › routes `unclaim.fr/*` et `*.unclaim.fr/*` (zone unclaim.fr).

### Jeton API pour le panneau

Mon profil › **Jetons d'API › Créer un jeton** › modèle personnalisé, avec la permission *Compte › Workers KV Storage › Modifier*. Reporte ensuite `CF_API_TOKEN` et `CF_ACCOUNT_ID` dans les variables du panneau.

Le panneau publie l'état au démarrage et à chaque changement. En cas d'échec, il affiche un bandeau rouge et réessaie à chaque tour de vérification. Le bouton « Republier » force l'envoi.

### Ce que fait le Worker

| Situation | Réponse |
|---|---|
| Site en maintenance, visiteur | Page « Maintenance en cours », **503** + `Retry-After` (JSON si la requête n'attend pas de HTML) |
| Site en maintenance, staff connecté au panneau | Le site normal (cookie `uc_bypass` signé HMAC, valable 12 h) |
| `/.well-known/*` pendant une maintenance | Passe (certificats, vérifications de domaine) |
| Origine injoignable, 52x, 530 (tunnel coupé) | Page « Site indisponible » qui explique la panne, nouvel essai toutes les 30 s |
| 502/503/504 renvoyé par l'application | Page Unclaim pour un navigateur ; réponse intacte pour une API ou si l'application envoie `X-Unclaim-Passthrough: 1` |
| Nom d'hôte de la page de statut | Page de statut, `/api/status.json`, `/feed.atom` (aucun serveur derrière) |
| Tout le reste | Passe tel quel (WebSocket et SSE du chat compris) |

Tu peux voir les pages depuis l'onglet **Aperçu** d'un site (« Aperçu : maintenance », « serveur éteint »…).

---

## Page de statut publique

### Mise en place

1. Cloudflare › DNS : crée `status` en **AAAA** vers `100::`, **proxifié** (nuage orange). Aucun serveur n'est nécessaire, car c'est le Worker qui répond.
2. Vérifie que la route `*.unclaim.fr/*` du Worker couvre `status.unclaim.fr`.
3. Dans le panneau, onglet **Statut** › Réglages, vérifie le nom d'hôte (`status.unclaim.fr` par défaut, ou `STATUS_HOST`).

Sans Cloudflare, la même page est visible sur `/status` du panneau.

### Ce qui est affiché

- **État global** : opérationnel, perturbé, panne partielle, panne majeure ou maintenance.
- **Chaque site public**, rangé par groupe, avec son état actuel, son temps de réponse (option) et une barre par jour sur 30, 60 ou 90 jours. Survoler une barre affiche le taux de disponibilité et la durée de panne estimée. Les maintenances ne comptent pas comme des pannes.
- **Incidents en cours** avec leur fil de mises à jour (Enquête en cours › Cause identifiée › Surveillance › Résolu), puis les incidents des 14 derniers jours, jour par jour.
- **Pour s'abonner** : un flux Atom (`/feed.atom`) et une API JSON (`/api/status.json`, CORS ouvert).

Rien d'interne n'est publié : pas d'identifiant Pelican, pas d'email du staff, pas de détail technique de la surveillance.

### Ce qui compte comme « joignable » (par site, dans Réglages)

| Réglage | Défaut | Effet |
|---|---|---|
| Adresse de test | adresse publique | URL appelée à chaque vérification |
| Codes HTTP acceptés | `200-399` | Ex. `200,204` ; tout autre code = hors ligne |
| Texte attendu | — | Si renseigné, doit apparaître dans la réponse (détecte une page blanche ou une page d'erreur servie en 200) |
| Délai max | 8 s | Au-delà = hors ligne. Au-delà de `HEALTH_SLOW_MS` (3 s) = dégradé |

L'état du serveur Pelican compte aussi : un serveur éteint ou suspendu est hors ligne, et un serveur en démarrage est dégradé.

### Incidents

- **Automatiques** (désactivables) : un incident « X est inaccessible » s'ouvre quand un site public est hors ligne depuis plus de 2 minutes (délai réglable). Il se résout tout seul quand le site revient, sauf si le staff y a déjà publié une mise à jour : dans ce cas, c'est à lui de le clore.
- **Manuels** : le staff et les super-admins déclarent un incident (titre, impact, sites concernés, message), puis publient les mises à jour. Un site concerné par un incident ouvert apparaît « perturbé » même s'il répond. Seuls les super-admins peuvent supprimer un incident.

> **Écritures KV.** L'offre gratuite de Workers KV permet 1 000 écritures par jour. Les changements d'état, les incidents et les maintenances sont publiés tout de suite ; l'historique, lui, ne part qu'au plus toutes les 5 minutes (`STATUS_PUSH_INTERVAL`), soit environ 300 écritures par jour.

## Ajouter les sites

**Sites › Importer depuis Pelican** liste les serveurs visibles par la clé. Choisis-en un, puis complète la fiche :

- **Noms d'hôte** : tous ceux qui servent le site (`unclaim.fr, www.unclaim.fr`). C'est par eux que le Worker reconnaît le site.
- **Adresse de test** : facultative. Par défaut, c'est l'adresse publique qui est testée, en passant par le Worker avec le cookie staff : on teste donc le vrai chemin, même pendant une maintenance. Indique une route légère si le site en a une (`/health`).
- **Configuration** : *Variables Pelican*, *fichier .env* ou les deux, plus le chemin du fichier (`/.env` par défaut, à la racine du serveur).
- **Contacts** (internes, visibles du staff) et **email public** (affiché aux visiteurs).

> **Qui gagne entre la variable de démarrage et le `.env` ?** Les sites Unclaim démarrent avec `node --env-file-if-exists=.env`. Dans ce cas, une variable de démarrage Pelican (variable d'environnement réelle) **l'emporte** sur la même clé du `.env`. Le panneau signale ces lignes avec le tag « écrasée par Pelican ». Rien ne change tant que le serveur n'a pas redémarré : coche « Redémarrer ensuite ».

## Rôles

| | Super-admin | Staff |
|---|---|---|
| Voir les sites, leur état, les contacts, le journal | ✓ | ✓ |
| Maintenance (tous ou certains sites) | ✓ | ✓ |
| Démarrer / redémarrer un serveur | ✓ | ✓ |
| Déclarer et mettre à jour des incidents | ✓ | ✓ |
| Réglages de la page de statut, suppression d'incidents | ✓ | — |
| Arrêter un serveur | ✓ | — |
| Voir et modifier les variables, `.env` | ✓ | — |
| Ajouter, modifier ou retirer des sites ; gérer le staff | ✓ | — |

Retirer quelqu'un du staff ferme sa session immédiatement. Son cookie de contournement de la maintenance reste valable jusqu'à son expiration (12 h max). Pour le couper tout de suite pour tout le monde, change `BYPASS_SECRET` dans le panneau et dans le Worker.

## Sécurité

- Les requêtes qui modifient quelque chose doivent venir du panneau lui-même (contrôle de l'en-tête `Origin`).
- Les cookies de session sont `HttpOnly`, `SameSite=Lax` et `Secure` en HTTPS.
- La clé Pelican et le jeton Cloudflare donnent la main sur tous les sites. Ils ne vivent que dans les variables du serveur du panneau, et le jeton Cloudflare se limite à « Workers KV : Modifier ».
- Les valeurs des variables ne sont jamais écrites dans le journal ni dans KV. La consultation des variables est elle-même journalisée.

## Fichiers

```
server.mjs            serveur HTTP et API
lib/                  auth (Unclaim Auth), pelican, dotenv, edge (Cloudflare KV), status (page de statut, incidents), monitor, db
public/               interface du panneau
worker/               Worker Cloudflare + pages d'erreur/maintenance (pages.js) + page de statut (status.js) + wrangler.toml
pelican/              œuf et script d'installation
dev/                  faux Pelican/Cloudflare et démo
test/                 tests (npm test)
```
