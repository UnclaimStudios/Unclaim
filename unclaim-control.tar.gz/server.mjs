// Unclaim Control — panneau staff des sites Unclaim hébergés sur Pelican (control.unclaim.fr).
// État des sites, maintenance (publiée vers le Worker Cloudflare via Workers KV), variables d'environnement.
// Zéro dépendance : Node ≥ 22.13 (node:http, node:sqlite). Voir README.md.
import { createServer } from "node:http";
import { readFileSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";
import { all, audit, get, json, run, setSetting, tx } from "./lib/db.mjs";
import {
  COOKIE, PUBLIC_URL, bypassCookie, clearBypassCookie, cookie, createSession, deleteSession, devLoginEnabled,
  exchangeCode, parseCookies, readLoginState, roleOf, sessionUser, startLogin, upsertUser,
} from "./lib/auth.mjs";
import * as pelican from "./lib/pelican.mjs";
import { applyEnv, isSecretKey, parseEnv, validKey } from "./lib/dotenv.mjs";
import { buildState, edgeConfigured, edgeStatus, publishState, pushNow } from "./lib/edge.mjs";
import { checkAll, checkSite, startMonitor } from "./lib/monitor.mjs";
import {
  INCIDENT_STATUS, IMPACT, STATUS_DEFAULTS, addIncidentUpdate, buildStatus, createIncident, publishStatus, pushStatus,
  startStatusPublisher, statusSettings, uptimeOf,
} from "./lib/status.mjs";
import { errorPage, maintenancePage } from "./worker/pages.js";
import { atomFeed, statusJson, statusPage } from "./worker/status.js";

const ROOT = dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT || 4100);
const MAX_BODY = 512 * 1024;
const ORIGIN = new URL(PUBLIC_URL).origin;

// ---------- utilitaires HTTP ----------
class HttpError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}
const fail = (status, message) => { throw new HttpError(status, message); };

const SECURITY_HEADERS = {
  "X-Content-Type-Options": "nosniff",
  "X-Frame-Options": "DENY",
  "Referrer-Policy": "same-origin",
};

function send(res, status, body, headers = {}) {
  const isJson = typeof body !== "string";
  res.writeHead(status, {
    "Content-Type": isJson ? "application/json; charset=utf-8" : "text/html; charset=utf-8",
    "Cache-Control": "no-store",
    ...SECURITY_HEADERS,
    ...headers,
  });
  res.end(isJson ? JSON.stringify(body) : body);
}

async function readJson(req) {
  let size = 0;
  const chunks = [];
  for await (const c of req) {
    size += c.length;
    if (size > MAX_BODY) fail(413, "Requête trop volumineuse");
    chunks.push(c);
  }
  if (!chunks.length) return {};
  try {
    return JSON.parse(Buffer.concat(chunks).toString("utf8"));
  } catch {
    fail(400, "JSON invalide");
  }
}

const str = (v, max, field, { required = false } = {}) => {
  const s = typeof v === "string" ? v.trim() : v == null ? "" : String(v).trim();
  if (required && !s) fail(400, `${field} requis`);
  if (s.length > max) fail(400, `${field} trop long (${max} caractères max)`);
  return s;
};
const EMAIL = /^[^\s@<>"]+@[^\s@<>"]+\.[^\s@<>"]+$/;
const HOST = /^(?=.{1,253}$)([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,}$|^localhost$/;

function httpUrl(v, field) {
  const s = str(v, 300, field);
  if (!s) return "";
  try {
    const u = new URL(s);
    if (u.protocol !== "https:" && u.protocol !== "http:") throw 0;
    return s.replace(/\/+$/, "");
  } catch {
    fail(400, `${field} : adresse invalide`);
  }
}

const list = (v) => (Array.isArray(v) ? v : String(v ?? "").split(/[\s,;]+/)).map((x) => String(x).trim()).filter(Boolean);

// ---------- vues ----------
function siteView(s, role) {
  const view = {
    ...s,
    hosts: json(s.hosts),
    contacts: json(s.contacts),
    resources: json(s.resources, null),
    maintenance: !!s.maintenance,
  };
  if (role !== "super") delete view.env_file;
  return view;
}
const siteRow = (siteId) => get("SELECT * FROM sites WHERE id = ?", siteId) ?? fail(404, "Site introuvable");

function config(role) {
  return {
    pelican: pelican.pelicanConfigured(),
    pelican_url: role === "super" ? (process.env.PELICAN_URL || "") : "",
    edge: edgeConfigured(),
    edge_status: edgeStatus,
    bypass: !!process.env.BYPASS_SECRET,
    dev_login: devLoginEnabled(),
  };
}

function readSiteBody(body, existing) {
  const out = {};
  if (!existing) {
    out.id = str(body.id, 32, "Identifiant", { required: true }).toLowerCase();
    if (!/^[a-z0-9][a-z0-9-]{1,31}$/.test(out.id)) fail(400, "Identifiant : lettres minuscules, chiffres et tirets (2 à 32)");
  }
  if (!existing || "name" in body) out.name = str(body.name, 80, "Nom", { required: true });
  if ("description" in body) out.description = str(body.description, 300, "Description");
  if ("hosts" in body) {
    out.hosts = list(body.hosts).map((h) => h.toLowerCase().replace(/^https?:\/\//, "").replace(/\/.*$/, ""));
    for (const h of out.hosts) if (!HOST.test(h)) fail(400, `Nom d'hôte invalide : ${h}`);
    const taken = all("SELECT id, hosts FROM sites WHERE id != ?", existing?.id ?? out.id)
      .find((s) => json(s.hosts).some((h) => out.hosts.includes(h)));
    if (taken) fail(409, `Un nom d'hôte est déjà utilisé par le site « ${taken.id} »`);
    out.hosts = JSON.stringify([...new Set(out.hosts)]);
  }
  if ("public_url" in body) out.public_url = httpUrl(body.public_url, "Adresse publique");
  if ("health_url" in body) out.health_url = httpUrl(body.health_url, "Adresse de test");
  if ("pelican_server" in body) {
    out.pelican_server = str(body.pelican_server, 40, "Serveur Pelican");
    if (out.pelican_server && !/^[A-Za-z0-9-]+$/.test(out.pelican_server)) fail(400, "Serveur Pelican : identifiant invalide");
  }
  if ("env_mode" in body) {
    if (!["startup", "dotenv", "both", "none"].includes(body.env_mode)) fail(400, "Mode de configuration inconnu");
    out.env_mode = body.env_mode;
  }
  if ("env_file" in body) {
    out.env_file = str(body.env_file, 200, "Fichier .env") || "/.env";
    if (!out.env_file.startsWith("/") || out.env_file.includes("..")) fail(400, "Fichier .env : chemin absolu attendu, ex. /.env");
  }
  if ("contacts" in body) {
    const c = list(body.contacts);
    for (const e of c) if (!EMAIL.test(e)) fail(400, `Email invalide : ${e}`);
    out.contacts = JSON.stringify(c);
  }
  if ("support_email" in body) {
    out.support_email = str(body.support_email, 200, "Email public");
    if (out.support_email && !EMAIL.test(out.support_email)) fail(400, "Email public invalide");
  }
  if ("position" in body) out.position = Number(body.position) || 0;
  // page de statut
  if ("status_public" in body) out.status_public = body.status_public === true || body.status_public === "1" || body.status_public === "on" ? 1 : 0;
  if ("public_name" in body) out.public_name = str(body.public_name, 80, "Nom public");
  if ("status_group" in body) out.status_group = str(body.status_group, 60, "Groupe");
  if ("public_description" in body) out.public_description = str(body.public_description, 200, "Description publique");
  // surveillance
  if ("health_expect" in body) {
    out.health_expect = str(body.health_expect, 60, "Codes attendus") || "200-399";
    if (!/^\s*\d{3}(-\d{3})?(\s*[,; ]\s*\d{3}(-\d{3})?)*\s*$/.test(out.health_expect)) fail(400, "Codes attendus : ex. 200-399 ou 200,204");
  }
  if ("health_keyword" in body) out.health_keyword = str(body.health_keyword, 200, "Texte attendu");
  if ("health_timeout" in body) {
    out.health_timeout = Number(body.health_timeout) || 8;
    if (out.health_timeout < 2 || out.health_timeout > 60) fail(400, "Délai : entre 2 et 60 secondes");
  }
  return out;
}

function untilValue(v) {
  if (!v) return null;
  const d = new Date(v);
  if (Number.isNaN(d.getTime())) fail(400, "Date de fin invalide");
  return d.toISOString();
}

async function envOf(site) {
  if (!site.pelican_server) fail(400, "Aucun serveur Pelican n'est associé à ce site");
  const out = { mode: site.env_mode, startup: null, dotenv: null };
  if (site.env_mode === "startup" || site.env_mode === "both") {
    try {
      const r = await pelican.startupVariables(site.pelican_server);
      out.startup = { command: r.command, variables: r.variables.map((v) => ({ ...v, secret: isSecretKey(v.key) })) };
    } catch (e) {
      out.startup = { error: e.message };
    }
  }
  if (site.env_mode === "dotenv" || site.env_mode === "both") {
    try {
      const raw = await pelican.readFile(site.pelican_server, site.env_file);
      out.dotenv = {
        file: site.env_file,
        exists: raw !== null,
        raw: raw ?? "",
        entries: parseEnv(raw ?? "").map((e) => ({ ...e, secret: isSecretKey(e.key) })),
      };
    } catch (e) {
      out.dotenv = { file: site.env_file, error: e.message };
    }
  }
  return out;
}

// ---------- routes ----------
const STATIC = {
  "/app.js": ["public/app.js", "text/javascript; charset=utf-8"],
  "/app.css": ["public/app.css", "text/css; charset=utf-8"],
};

async function handle(req, res) {
  const url = new URL(req.url, PUBLIC_URL);
  const path = url.pathname.replace(/\/+$/, "") || "/";
  const method = req.method;
  const cookies = parseCookies(req.headers.cookie);

  if (path === "/health") return send(res, 200, { ok: true, dev_login: devLoginEnabled() });

  // Page de statut publique servie aussi par le panneau (aperçu, ou secours si le Worker n'est pas en place).
  if (method === "GET" && (path === "/status" || path === "/status/api/status.json" || path === "/status/feed.atom")) {
    const data = buildStatus();
    if (path.endsWith(".json")) return send(res, 200, statusJson(data), { "Access-Control-Allow-Origin": "*" });
    if (path.endsWith(".atom")) return send(res, 200, atomFeed(data, `${PUBLIC_URL}/status`), { "Content-Type": "application/atom+xml; charset=utf-8" });
    return send(res, 200, statusPage(data, { host: statusSettings().host }).replace(/href="\/(feed\.atom|api\/status\.json)"/g, 'href="/status/$1"'));
  }

  if (method === "GET" && (path === "/" || STATIC[path] || path.startsWith("/sites") || path === "/staff" || path === "/journal" || path === "/statut")) {
    const [file, type] = STATIC[path] || ["public/index.html", "text/html; charset=utf-8"];
    res.writeHead(200, { "Content-Type": type, "Cache-Control": STATIC[path] ? "no-cache" : "no-store", ...SECURITY_HEADERS });
    return res.end(readFileSync(join(ROOT, file)));
  }

  // Protection CSRF : toute requête qui modifie quelque chose doit venir du panneau lui-même.
  if (method !== "GET" && method !== "HEAD") {
    const origin = req.headers.origin;
    if (origin ? origin !== ORIGIN : req.headers["sec-fetch-site"] && req.headers["sec-fetch-site"] !== "same-origin") {
      fail(403, "Origine refusée");
    }
  }

  // ----- connexion -----
  if (method === "GET" && path === "/auth/start") {
    if (devLoginEnabled() && url.searchParams.get("dev")) {
      const discordId = url.searchParams.get("dev").slice(0, 32);
      const userId = upsertUser({ unclaim_id: `dev-${discordId}`, discord_id: discordId, username: url.searchParams.get("name") || `Dev ${discordId}` });
      return loginDone(res, userId);
    }
    if (!process.env.UNCLAIM_CLIENT_ID) return send(res, 500, page("Connexion indisponible", "UNCLAIM_CLIENT_ID n'est pas configuré."));
    const { url: to, cookie: c } = startLogin();
    return send(res, 302, "", { Location: to, "Set-Cookie": c });
  }

  if (method === "GET" && path === "/auth/callback") {
    const state = readLoginState(cookies, url.searchParams.get("state"));
    const code = url.searchParams.get("code");
    if (!state || !code) return send(res, 400, page("Connexion expirée", "Recommence depuis la page d'accueil du panneau."));
    try {
      const u = await exchangeCode(code, state.v);
      const userId = upsertUser(u);
      return loginDone(res, userId, [cookie("uc_oauth", "", 0)]);
    } catch (e) {
      console.error("Connexion :", e.message);
      return send(res, 502, page("Connexion impossible", "Unclaim Auth a refusé la connexion. Réessaie dans un instant."));
    }
  }

  if (method === "POST" && path === "/auth/logout") {
    deleteSession(cookies[COOKIE]);
    return send(res, 200, { ok: true }, { "Set-Cookie": [cookie(COOKIE, "", 0), clearBypassCookie()] });
  }

  // ----- tout le reste demande une session staff -----
  const me = sessionUser(cookies[COOKIE]);
  if (!me) {
    if (path.startsWith("/api/")) fail(401, "Connexion requise");
    if (path.startsWith("/preview/")) return send(res, 302, "", { Location: "/" });
    fail(404, "Page introuvable");
  }
  const isSuper = me.role === "super";
  const superOnly = () => isSuper || fail(403, "Réservé aux super-admins");

  // Aperçus des pages servies par le Worker.
  const preview = path.match(/^\/preview\/(maintenance|error)\/([a-z0-9-]+)$/);
  if (method === "GET" && preview) {
    const s = buildState();
    const site = s.sites[preview[2]] ?? fail(404, "Site introuvable");
    const host = json(siteRow(preview[2]).hosts)[0] || "";
    if (preview[1] === "maintenance") {
      const demo = { ...site, maintenance: true, since: site.since || new Date().toISOString() };
      return send(res, 200, maintenancePage({ site: demo, state: s, host, ray: "aperçu" }));
    }
    const code = url.searchParams.get("code") === "unreachable" ? "unreachable" : Number(url.searchParams.get("code")) || 521;
    return send(res, 200, errorPage({ site, state: s, host, code, ray: "aperçu" }));
  }

  if (!path.startsWith("/api/")) fail(404, "Page introuvable");
  const body = method === "GET" ? {} : await readJson(req);

  if (method === "GET" && path === "/api/me") {
    return send(res, 200, {
      user: { id: me.id, name: me.name, avatar_url: me.avatar_url, discord_id: me.discord_id, role: me.role },
      config: config(me.role),
    });
  }

  // ----- sites -----
  if (method === "GET" && path === "/api/sites") {
    return send(res, 200, { sites: all("SELECT * FROM sites ORDER BY position, name").map((s) => siteView(s, me.role)), edge_status: edgeStatus });
  }

  if (method === "POST" && path === "/api/sites") {
    superOnly();
    const data = readSiteBody(body, null);
    if (get("SELECT 1 AS x FROM sites WHERE id = ?", data.id)) fail(409, "Cet identifiant existe déjà");
    const pos = get("SELECT COALESCE(MAX(position), 0) + 1 AS p FROM sites").p;
    const cols = Object.keys(data);
    run(`INSERT INTO sites (${cols.join(", ")}, position) VALUES (${cols.map(() => "?").join(", ")}, ?)`, ...cols.map((c) => data[c]), pos);
    audit(me, "site créé", data.id, data.name);
    publishState();
    publishStatus({ now: true });
    checkSite(siteRow(data.id)).catch(() => {});
    return send(res, 201, { site: siteView(siteRow(data.id), me.role) });
  }

  if (method === "POST" && path === "/api/sites/check") {
    await checkAll();
    return send(res, 200, { sites: all("SELECT * FROM sites ORDER BY position, name").map((s) => siteView(s, me.role)) });
  }

  // Maintenance groupée : { sites: [ids] | "all", enabled, message, until }
  if (method === "POST" && path === "/api/maintenance") {
    const ids = body.sites === "all" ? all("SELECT id FROM sites").map((s) => s.id) : list(body.sites);
    if (!ids.length) fail(400, "Choisis au moins un site");
    const enabled = !!body.enabled;
    const message = str(body.message, 1000, "Message");
    const until = untilValue(body.until);
    const now = new Date().toISOString();
    tx(() => {
      for (const sid of ids) {
        const s = siteRow(sid);
        if (enabled) {
          run(`UPDATE sites SET maintenance = 1, maintenance_message = ?, maintenance_until = ?,
                 maintenance_since = COALESCE(CASE WHEN maintenance = 1 THEN maintenance_since END, ?), status = 'maintenance' WHERE id = ?`,
            message, until, now, sid);
        } else if (s.maintenance) {
          run("UPDATE sites SET maintenance = 0, maintenance_since = NULL, maintenance_until = NULL, status = 'unknown' WHERE id = ?", sid);
        }
        audit(me, enabled ? "maintenance activée" : "maintenance terminée", sid, enabled ? [message, until && `fin estimée ${until}`].filter(Boolean).join(" · ") : "");
      }
    });
    const pushed = await publishState({ now: true });
    publishStatus({ now: true });
    if (!enabled) for (const sid of ids) checkSite(siteRow(sid)).catch(() => {});
    return send(res, 200, {
      ok: true,
      published: pushed,
      edge_status: edgeStatus,
      sites: all("SELECT * FROM sites ORDER BY position, name").map((s) => siteView(s, me.role)),
    });
  }

  if (method === "POST" && path === "/api/edge/publish") {
    superOnly();
    const ok = await pushNow();
    return send(res, ok ? 200 : 502, { ok, edge_status: edgeStatus, error: edgeStatus.error || undefined });
  }

  if (method === "GET" && path === "/api/pelican/servers") {
    superOnly();
    const servers = await pelican.listServers();
    const used = new Map(all("SELECT id, pelican_server FROM sites WHERE pelican_server != ''").map((s) => [s.pelican_server, s.id]));
    return send(res, 200, { servers: servers.map((s) => ({ ...s, site_id: used.get(s.identifier) ?? null })) });
  }

  const m = path.match(/^\/api\/sites\/([a-z0-9-]+)(?:\/(.+))?$/);
  if (m) {
    const site = siteRow(m[1]);
    const sub = m[2] || "";

    if (method === "GET" && sub === "") return send(res, 200, { site: siteView(site, me.role), uptime: uptimeOf(site.id, 90) });

    if (method === "PATCH" && sub === "") {
      superOnly();
      const data = readSiteBody(body, site);
      const cols = Object.keys(data);
      if (cols.length) run(`UPDATE sites SET ${cols.map((c) => `${c} = ?`).join(", ")} WHERE id = ?`, ...cols.map((c) => data[c]), site.id);
      audit(me, "site modifié", site.id, cols.join(", "));
      publishState();
      publishStatus({ now: true });
      return send(res, 200, { site: siteView(siteRow(site.id), me.role) });
    }

    if (method === "DELETE" && sub === "") {
      superOnly();
      run("DELETE FROM sites WHERE id = ?", site.id);
      audit(me, "site supprimé", site.id, site.name);
      publishState();
      publishStatus({ now: true });
      return send(res, 200, { ok: true });
    }

    if (method === "POST" && sub === "check") return send(res, 200, { site: siteView(await checkSite(site), me.role) });

    if (method === "POST" && sub === "power") {
      const signal = String(body.signal || "");
      // Le staff peut démarrer ou redémarrer un site ; arrêter ou forcer l'arrêt est réservé aux super-admins.
      if (!["start", "restart"].includes(signal)) superOnly();
      if (!site.pelican_server) fail(400, "Aucun serveur Pelican n'est associé à ce site");
      await pelican.power(site.pelican_server, signal);
      audit(me, `alimentation : ${signal}`, site.id);
      setTimeout(() => checkSite(siteRow(site.id)).catch(() => {}), 8000).unref();
      return send(res, 200, { ok: true });
    }

    if (method === "GET" && sub === "audit") {
      return send(res, 200, { entries: all("SELECT * FROM audit WHERE site_id = ? ORDER BY id DESC LIMIT 100", site.id) });
    }

    // ----- variables d'environnement (super-admins) -----
    if (method === "GET" && sub === "env") {
      superOnly();
      const env = await envOf(site);
      audit(me, "variables consultées", site.id);
      return send(res, 200, env);
    }

    if (method === "PUT" && sub === "env/startup") {
      superOnly();
      if (!site.pelican_server) fail(400, "Aucun serveur Pelican n'est associé à ce site");
      const changes = body.changes && typeof body.changes === "object" ? body.changes : fail(400, "Aucun changement");
      const current = await pelican.startupVariables(site.pelican_server);
      const keys = Object.keys(changes);
      for (const k of keys) {
        const v = current.variables.find((x) => x.key === k) ?? fail(400, `Variable inconnue : ${k}`);
        if (!v.editable) fail(400, `${k} n'est pas modifiable depuis l'API client (rends-la modifiable dans l'œuf)`);
      }
      const done = [];
      for (const k of keys) {
        try {
          await pelican.setStartupVariable(site.pelican_server, k, str(changes[k], 10_000, k));
          done.push(k);
        } catch (e) {
          if (done.length) audit(me, "variables de démarrage modifiées", site.id, done.join(", "));
          fail(e.status === 422 ? 400 : e.status || 502, `${k} : ${e.message}${done.length ? ` (déjà enregistrées : ${done.join(", ")})` : ""}`);
        }
      }
      audit(me, "variables de démarrage modifiées", site.id, keys.join(", "));
      if (body.restart) { await pelican.power(site.pelican_server, "restart"); audit(me, "alimentation : restart", site.id); }
      return send(res, 200, { ok: true, restarted: !!body.restart });
    }

    if (method === "PUT" && sub === "env/dotenv") {
      superOnly();
      if (!site.pelican_server) fail(400, "Aucun serveur Pelican n'est associé à ce site");
      let content;
      let detail;
      if (typeof body.raw === "string") {
        if (body.raw.length > 200_000) fail(413, "Fichier trop volumineux");
        content = body.raw.replace(/\r\n/g, "\n");
        detail = "fichier réécrit (texte brut)";
      } else {
        const changes = body.changes && typeof body.changes === "object" ? body.changes : fail(400, "Aucun changement");
        for (const [k, v] of Object.entries(changes)) {
          if (!validKey(k)) fail(400, `Nom de variable invalide : ${k}`);
          if (v !== null) changes[k] = str(v, 10_000, k);
        }
        const current = (await pelican.readFile(site.pelican_server, site.env_file)) ?? "";
        content = applyEnv(current, changes);
        detail = Object.entries(changes).map(([k, v]) => (v === null ? `−${k}` : k)).join(", ");
      }
      await pelican.writeFile(site.pelican_server, site.env_file, content);
      audit(me, `${site.env_file} modifié`, site.id, detail);
      if (body.restart) { await pelican.power(site.pelican_server, "restart"); audit(me, "alimentation : restart", site.id); }
      return send(res, 200, { ok: true, restarted: !!body.restart, entries: parseEnv(content).map((e) => ({ ...e, secret: isSecretKey(e.key) })), raw: content });
    }
  }

  // ----- page de statut : réglages (super-admins) et incidents (staff) -----
  if (method === "GET" && path === "/api/status") {
    const incidents = all("SELECT * FROM incidents ORDER BY (status = 'resolved'), id DESC LIMIT 60").map((i) => ({
      ...i, sites: json(i.sites), auto: !!i.auto,
      updates: all("SELECT * FROM incident_updates WHERE incident_id = ? ORDER BY id DESC", i.id),
    }));
    return send(res, 200, { settings: statusSettings(), incidents, overall: buildStatus().overall, labels: { status: INCIDENT_STATUS, impact: IMPACT } });
  }

  if (method === "PUT" && path === "/api/status/settings") {
    superOnly();
    const cur = statusSettings();
    const next = { ...cur };
    if ("title" in body) next.title = str(body.title, 120, "Titre") || STATUS_DEFAULTS.title;
    if ("intro" in body) next.intro = str(body.intro, 1000, "Introduction");
    if ("announcement" in body) next.announcement = str(body.announcement, 1000, "Annonce");
    if ("host" in body) {
      next.host = str(body.host, 200, "Nom d'hôte").toLowerCase().replace(/^https?:\/\//, "").replace(/\/.*$/, "");
      if (next.host && !HOST.test(next.host)) fail(400, "Nom d'hôte invalide");
    }
    if ("history_days" in body) next.history_days = [30, 60, 90].includes(Number(body.history_days)) ? Number(body.history_days) : 90;
    if ("show_latency" in body) next.show_latency = !!body.show_latency;
    if ("auto_incidents" in body) next.auto_incidents = !!body.auto_incidents;
    if ("auto_delay" in body) {
      next.auto_delay = Number(body.auto_delay);
      if (!(next.auto_delay >= 0 && next.auto_delay <= 3600)) fail(400, "Délai : entre 0 et 3600 secondes");
    }
    setSetting("status", next);
    audit(me, "page de statut modifiée", null, Object.keys(body).join(", "));
    if (next.host !== cur.host) publishState({ now: true }); // le Worker apprend le nouveau nom d'hôte
    const published = await publishStatus({ now: true });
    return send(res, 200, { settings: next, published });
  }

  if (method === "POST" && path === "/api/status/publish") {
    const ok = await pushStatus();
    return send(res, ok ? 200 : 502, { ok, edge_status: edgeStatus });
  }

  const incidentFields = (b, partial) => {
    const out = {};
    if (!partial || "title" in b) out.title = str(b.title, 160, "Titre", { required: true });
    if (!partial || "impact" in b) {
      out.impact = b.impact || "minor";
      if (!IMPACT[out.impact]) fail(400, "Impact inconnu");
    }
    if (!partial || "sites" in b) {
      out.sites = list(b.sites);
      for (const sid of out.sites) siteRow(sid);
    }
    return out;
  };
  const incidentStatus = (s) => (INCIDENT_STATUS[s] ? s : fail(400, "État d'incident inconnu"));

  if (method === "POST" && path === "/api/incidents") {
    const f = incidentFields(body, false);
    const id = createIncident({ ...f, status: incidentStatus(body.status || "investigating"), body: str(body.body, 4000, "Message", { required: true }), author: me.name });
    audit(me, "incident déclaré", f.sites[0] || null, `#${id} ${f.title}`);
    const published = await publishStatus({ now: true });
    return send(res, 201, { id, published });
  }

  const inc = path.match(/^\/api\/incidents\/(\d+)(\/updates)?$/);
  if (inc) {
    const incident = get("SELECT * FROM incidents WHERE id = ?", Number(inc[1])) ?? fail(404, "Incident introuvable");
    if (method === "POST" && inc[2]) {
      addIncidentUpdate(incident.id, { status: incidentStatus(body.status), body: str(body.body, 4000, "Message", { required: true }), author: me.name });
      audit(me, `incident : ${INCIDENT_STATUS[body.status]}`, json(incident.sites)[0] || null, `#${incident.id} ${incident.title}`);
      return send(res, 200, { ok: true, published: await publishStatus({ now: true }) });
    }
    if (method === "PATCH" && !inc[2]) {
      const f = incidentFields(body, true);
      const cols = Object.keys(f);
      if (cols.length) run(`UPDATE incidents SET ${cols.map((c) => `${c} = ?`).join(", ")} WHERE id = ?`,
        ...cols.map((c) => (c === "sites" ? JSON.stringify(f[c]) : f[c])), incident.id);
      audit(me, "incident modifié", null, `#${incident.id}`);
      return send(res, 200, { ok: true, published: await publishStatus({ now: true }) });
    }
    if (method === "DELETE" && !inc[2]) {
      superOnly();
      run("DELETE FROM incidents WHERE id = ?", incident.id);
      audit(me, "incident supprimé", null, `#${incident.id} ${incident.title}`);
      return send(res, 200, { ok: true, published: await publishStatus({ now: true }) });
    }
  }

  // ----- journal -----
  if (method === "GET" && path === "/api/audit") {
    const before = Number(url.searchParams.get("before")) || Number.MAX_SAFE_INTEGER;
    return send(res, 200, { entries: all("SELECT * FROM audit WHERE id < ? ORDER BY id DESC LIMIT 100", before) });
  }

  // ----- staff (super-admins) -----
  if (method === "GET" && path === "/api/staff") {
    superOnly();
    const supers = (process.env.ADMIN_DISCORD_IDS || "").split(",").map((s) => s.trim()).filter(Boolean);
    const users = new Map(all("SELECT discord_id, name, avatar_url, last_login_at FROM users WHERE discord_id IS NOT NULL").map((u) => [u.discord_id, u]));
    return send(res, 200, {
      supers: supers.map((d) => ({ discord_id: d, ...users.get(d) })),
      staff: all("SELECT * FROM staff ORDER BY created_at").map((s) => ({ ...s, ...users.get(s.discord_id), discord_id: s.discord_id })),
    });
  }

  if (method === "POST" && path === "/api/staff") {
    superOnly();
    const discordId = str(body.discord_id, 32, "ID Discord", { required: true });
    if (!/^\d{15,22}$/.test(discordId)) fail(400, "ID Discord invalide (15 à 22 chiffres)");
    run("INSERT INTO staff (discord_id, note, added_by) VALUES (?, ?, ?) ON CONFLICT(discord_id) DO UPDATE SET note = excluded.note",
      discordId, str(body.note, 120, "Note"), me.id);
    audit(me, "staff ajouté", null, discordId);
    return send(res, 201, { ok: true });
  }

  const st = path.match(/^\/api\/staff\/(\d{15,22})$/);
  if (method === "DELETE" && st) {
    superOnly();
    run("DELETE FROM staff WHERE discord_id = ?", st[1]);
    run("DELETE FROM sessions WHERE user_id IN (SELECT id FROM users WHERE discord_id = ?)", st[1]);
    audit(me, "staff retiré", null, st[1]);
    return send(res, 200, { ok: true });
  }

  fail(404, "Route introuvable");
}

function loginDone(res, userId, extraCookies = []) {
  const user = get("SELECT * FROM users WHERE id = ?", userId);
  if (!roleOf(user)) {
    return send(res, 403, page("Accès réservé au staff",
      `Ton compte (${user.name}, ID Discord ${user.discord_id || "inconnu"}) n'a pas accès au panneau. Demande à un super-admin de t'ajouter.`),
      { "Set-Cookie": extraCookies });
  }
  const cookies = [...extraCookies, cookie(COOKIE, createSession(userId), 12 * 3600)];
  const bypass = bypassCookie(userId);
  if (bypass) cookies.push(bypass);
  audit({ id: user.id, name: user.name }, "connexion");
  return send(res, 302, "", { Location: "/", "Set-Cookie": cookies });
}

function page(title, text) {
  const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c]);
  return `<!doctype html><html lang="fr"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>${esc(title)} · Unclaim Control</title><link rel="stylesheet" href="/app.css">
<body class="center"><main class="notice"><span class="label">Unclaim Control</span><h1>${esc(title)}</h1><p class="muted">${esc(text)}</p>
<a class="btn" href="/">Retour</a></main></body></html>`;
}

const server = createServer((req, res) => {
  handle(req, res).catch((e) => {
    const status = e instanceof HttpError || e instanceof pelican.PelicanError ? e.status : 500;
    if (status >= 500 && !(e instanceof pelican.PelicanError)) console.error(e);
    if (res.headersSent) return res.end();
    const wantsJson = (req.url || "").startsWith("/api/") || (req.headers.accept || "").includes("application/json");
    const message = status === 500 ? "Erreur interne" : e.message;
    send(res, status, wantsJson ? { error: message } : page("Erreur", message));
  });
});

server.listen(PORT, () => {
  console.log(`Unclaim Control sur ${PUBLIC_URL} (port ${PORT})`);
  if (!pelican.pelicanConfigured()) console.warn("Pelican non configuré : PELICAN_URL et PELICAN_CLIENT_KEY sont requis pour l'état serveur et les variables.");
  if (!edgeConfigured()) console.warn("Cloudflare KV non configuré : la maintenance ne sera pas publiée vers le Worker.");
  if (!process.env.BYPASS_SECRET) console.warn("BYPASS_SECRET absent : le staff ne pourra pas voir les sites pendant une maintenance.");
  startMonitor();
  startStatusPublisher();
  publishStatus({ now: true });
  publishState();
});
