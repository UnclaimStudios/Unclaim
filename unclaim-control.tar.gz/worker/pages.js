// Pages « Maintenance en cours » et « Site indisponible » d'Unclaim.
// Autonomes (CSS et icône intégrés, aucune ressource externe) : elles s'affichent même quand tout est en panne.
// Partagées par le Worker Cloudflare et par le panneau (aperçus).

const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);

/** « jeudi 23 octobre à 18 h 30 » (heure de Paris). */
export function formatDate(iso) {
  const d = new Date(iso);
  if (!iso || Number.isNaN(d.getTime())) return "";
  const day = new Intl.DateTimeFormat("fr-FR", { weekday: "long", day: "numeric", month: "long", timeZone: "Europe/Paris" }).format(d);
  const time = new Intl.DateTimeFormat("fr-FR", { hour: "2-digit", minute: "2-digit", timeZone: "Europe/Paris" }).format(d).replace(":", " h ");
  return `${day} à ${time}`;
}

/** Codes d'erreur de l'origine → explication pour le visiteur. */
export function errorKind(code) {
  if (code === "unreachable" || code === 521 || code === 530 || code === 523) return {
    title: "ne répond pas",
    text: "Le serveur qui fait tourner ce site est injoignable pour le moment : il est sans doute en train de redémarrer ou d'être mis à jour.",
    broken: "server",
  };
  if (code === 522 || code === 524 || code === 504) return {
    title: "met trop de temps à répondre",
    text: "Le serveur est joignable mais il ne répond pas dans les temps. Il est peut-être très sollicité ou bloqué sur une tâche.",
    broken: "server",
  };
  if (code === 525 || code === 526) return {
    title: "a un souci de connexion sécurisée",
    text: "La liaison chiffrée entre notre réseau et le serveur du site a échoué. C'est un problème de configuration de notre côté.",
    broken: "link",
  };
  return {
    title: "rencontre un problème",
    text: "Le serveur a renvoyé une réponse invalide. L'application a probablement planté et va redémarrer.",
    broken: "server",
  };
}

const CSS = `
:root{--bg:#0E0F12;--card:#16181C;--line:#2A2D34;--fg:#ECEAE4;--muted:#8A8C93;--accent:#FF5A1F;--ok:#6FA88F;--danger:#F04438;
--display:"Bricolage Grotesque","Arial Narrow","Helvetica Neue",system-ui,sans-serif;--sans:Inter,system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;--mono:"Geist Mono",ui-monospace,SFMono-Regular,Consolas,monospace}
*{box-sizing:border-box;margin:0;padding:0}
html{color-scheme:dark}
body{min-height:100vh;display:flex;flex-direction:column;background:var(--bg);color:var(--fg);font:16px/1.6 var(--sans);-webkit-font-smoothing:antialiased;border-top:4px solid var(--accent)}
a{color:inherit;text-underline-offset:3px}
a:hover{color:var(--accent)}
:focus-visible{outline:2px solid var(--accent);outline-offset:3px}
header,footer{display:flex;align-items:center;gap:14px;padding:18px 24px}
header{border-bottom:1px solid var(--line)}
.brand{font:800 20px var(--display);letter-spacing:-.04em;text-decoration:none}
.brand span{color:transparent;-webkit-text-stroke:1px var(--fg)}
.host{font:500 12px var(--mono);color:var(--muted);letter-spacing:.04em}
main{flex:1;width:100%;max-width:760px;margin:0 auto;padding:clamp(40px,9vh,96px) 24px 48px}
.chip{display:inline-flex;align-items:center;gap:8px;padding:4px 9px;border:1.5px solid currentColor;border-radius:2px;font:500 11.5px var(--mono);letter-spacing:.08em;text-transform:uppercase;color:var(--accent)}
.bloc{width:8px;height:8px;background:currentColor;display:inline-block}
.pulse{animation:p 1.6s ease-in-out infinite}
@keyframes p{50%{opacity:.25}}
@media (prefers-reduced-motion:reduce){.pulse{animation:none}}
h1{margin:22px 0 18px;font:800 clamp(38px,7vw,64px)/1.02 var(--display);letter-spacing:-.04em;text-wrap:balance}
h1 em{font-style:normal;color:var(--accent)}
.lead{font-size:18px;color:#C9C7C1;max-width:58ch;white-space:pre-line}
.facts{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:1px;margin:36px 0;background:var(--line);border:1px solid var(--line)}
.facts div{background:var(--card);padding:14px 16px}
.label{display:block;font:500 11px var(--mono);letter-spacing:.1em;text-transform:uppercase;color:var(--muted);margin-bottom:4px}
.facts b{font-weight:600}
.path{display:flex;align-items:center;margin:36px 0;font:500 12px var(--mono);letter-spacing:.04em;text-transform:uppercase}
.node{display:grid;justify-items:center;gap:8px;min-width:84px;color:var(--muted)}
.node i{width:44px;height:44px;display:grid;place-items:center;border:1.5px solid var(--line);border-radius:2px;font:600 18px var(--sans);font-style:normal;color:var(--ok)}
.node.bad i{border-color:var(--danger);color:var(--danger)}
.node.bad{color:var(--fg)}
.wire{flex:1;height:0;border-top:1.5px solid var(--line);margin:0 6px 26px}
.wire.bad{border-top:1.5px dashed var(--danger)}
.actions{display:flex;flex-wrap:wrap;gap:10px;margin-top:8px}
.btn{display:inline-flex;align-items:center;height:42px;padding:0 18px;border-radius:2px;border:1px solid var(--accent);background:var(--accent);color:#0E0F12;font:600 15px var(--sans);text-decoration:none;cursor:pointer}
.btn:hover{color:#0E0F12;filter:brightness(1.07)}
.btn.ghost{background:transparent;color:var(--fg);border-color:var(--line)}
.btn.ghost:hover{border-color:var(--fg);color:var(--fg)}
.note{margin-top:18px;color:var(--muted);font-size:14px}
footer{flex-wrap:wrap;justify-content:space-between;border-top:1px solid var(--line);color:var(--muted);font-size:13px}
footer .mono{font:500 11.5px var(--mono);letter-spacing:.04em}
@media (max-width:520px){header,footer{padding:14px 16px}main{padding:40px 16px}.node{min-width:64px}.lead{font-size:16.5px}}
`;

const ICON = "data:image/svg+xml," + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><rect width="32" height="32" fill="#0E0F12"/><rect x="11" y="11" width="10" height="10" fill="#FF5A1F"/></svg>');

function layout({ title, host, refresh, body, footer }) {
  return `<!doctype html>
<html lang="fr"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="robots" content="noindex"><meta name="theme-color" content="#0E0F12">
${refresh ? `<meta http-equiv="refresh" content="${refresh}">` : ""}
<title>${esc(title)}</title><link rel="icon" href="${ICON}"><style>${CSS}</style>
</head><body>
<header><a class="brand" href="https://unclaim.fr">UN<span>CLAIM</span></a>${host ? `<span class="host">${esc(host)}</span>` : ""}</header>
<main>${body}</main>
<footer>${footer}</footer>
</body></html>`;
}

function footerOf({ site, state, code, ray }) {
  const mail = site?.support || state?.contact;
  const left = mail ? `Une question ? <a href="mailto:${esc(mail)}">${esc(mail)}</a>` : `${esc(state?.brand || "Unclaim")}`;
  const right = [code ? `Code ${esc(code)}` : "", ray ? `Ray ${esc(ray)}` : ""].filter(Boolean).join(" · ");
  return `<span>${left}</span><span class="mono">${right}</span>`;
}

const statusLink = (state) => state?.status_url ? `<a class="btn ghost" href="${esc(state.status_url)}">État des services</a>` : "";

/** Page de maintenance (le site est volontairement fermé). */
export function maintenancePage({ site, state, host, ray } = {}) {
  const name = site?.name || host || "Ce site";
  const until = formatDate(site?.until);
  const since = formatDate(site?.since);
  const late = site?.until && new Date(site.until).getTime() < Date.now();
  const facts = [
    since && `<div><span class="label">Début</span><b>${esc(since)}</b></div>`,
    until && `<div><span class="label">${late ? "Fin prévue (dépassée)" : "Fin estimée"}</span><b>${esc(until)}</b></div>`,
    `<div><span class="label">Vos données</span><b>Conservées, rien n'est perdu</b></div>`,
  ].filter(Boolean).join("");
  const body = `
<span class="chip"><span class="bloc pulse"></span>Maintenance en cours</span>
<h1>${esc(name)} revient <em>très vite.</em></h1>
<p class="lead">${esc(site?.message || "Le site est momentanément fermé pour une opération de maintenance. Tout revient à la normale dès la fin de l'intervention.")}</p>
<div class="facts">${facts}</div>
<div class="actions"><a class="btn" href="">Réessayer</a>${statusLink(state)}</div>
<p class="note">Cette page se recharge toute seule chaque minute${late ? " : l'intervention prend un peu plus de temps que prévu" : ""}.</p>`;
  return layout({ title: `Maintenance en cours · ${name}`, host, refresh: 60, body, footer: footerOf({ site, state, code: 503, ray }) });
}

/** Page d'erreur (le site devrait être en ligne mais son serveur ne répond pas correctement). */
export function errorPage({ site, state, host, code = 502, ray } = {}) {
  const name = site?.name || host || "Ce site";
  const k = errorKind(code);
  const shown = code === "unreachable" ? 521 : code;
  const node = (label, glyph, bad) => `<div class="node${bad ? " bad" : ""}"><i aria-hidden="true">${glyph}</i>${label}</div>`;
  const body = `
<span class="chip"><span class="bloc"></span>Site indisponible · Erreur ${esc(shown)}</span>
<h1>${esc(name)} <em>${esc(k.title)}.</em></h1>
<p class="lead">${esc(k.text)}</p>
<div class="path" role="img" aria-label="Ton navigateur fonctionne, le réseau Unclaim fonctionne, le serveur du site ne répond pas.">
  ${node("Toi", "✓")}<span class="wire"></span>${node("Réseau", "✓")}<span class="wire bad"></span>${k.broken === "server" ? node("Serveur", "✕", true) : node("Serveur", "?")}
</div>
<p class="lead">Ce n'est pas toi : ta connexion fonctionne. L'équipe surveille les sites en continu et intervient dès qu'un serveur tombe. Réessaie dans quelques minutes.</p>
<div class="actions" style="margin-top:28px"><a class="btn" href="">Réessayer</a>${statusLink(state)}</div>
<p class="note">Nouvel essai automatique dans 30 secondes.</p>`;
  return layout({ title: `${name} est indisponible`, host, refresh: 30, body, footer: footerOf({ site, state, code: shown, ray }) });
}
