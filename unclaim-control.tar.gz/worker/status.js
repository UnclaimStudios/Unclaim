// Page de statut publique (status.unclaim.fr), façon GitHub Status / Discord Status.
// Rendue par le Worker à partir des données publiées par Unclaim Control dans KV (clé « status »),
// et par le panneau pour l'aperçu. Autonome : CSS intégré, aucune ressource externe, aucun JavaScript requis.

const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);

const TZ = "Europe/Paris";
const fmt = (opts) => new Intl.DateTimeFormat("fr-FR", { timeZone: TZ, ...opts });
const F_TIME = fmt({ hour: "2-digit", minute: "2-digit" });
const F_DAY = fmt({ day: "numeric", month: "short", year: "numeric" });
const F_DAYTIME = fmt({ day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" });
const time = (iso) => F_TIME.format(new Date(iso)).replace(":", " h ");
const dayTime = (iso) => F_DAYTIME.format(new Date(iso)).replace(":", " h ").replace(" ", " ");
const dayLabel = (d) => F_DAY.format(new Date(`${d}T12:00:00Z`));

const SITE_STATUS = {
  online: ["Opérationnel", "ok"], degraded: ["Performances dégradées", "warn"], down: ["Panne", "bad"],
  maintenance: ["Maintenance", "maint"], unknown: ["Non vérifié", "none"],
};
const OVERALL = {
  operational: ["Tous les services sont opérationnels", "ok"],
  degraded: ["Certains services sont perturbés", "warn"],
  partial: ["Panne partielle en cours", "bad"],
  major: ["Panne majeure en cours", "bad"],
  maintenance: ["Maintenance en cours", "maint"],
};
const INCIDENT_STATUS = { investigating: "Enquête en cours", identified: "Cause identifiée", monitoring: "Surveillance", resolved: "Résolu" };
const IMPACT = { minor: "warn", major: "bad", critical: "bad" };

const pct = (r) => (r === null || r === undefined ? "—" : `${(Math.floor(r * 10000) / 100).toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} %`);

function barClass(x) {
  if (x.r === null) return x.maint ? "maint" : "none";
  if (x.r < 0.95) return "bad";
  if (x.r < 0.999 || x.deg > 0) return "warn";
  return "ok";
}

function barTitle(x, interval) {
  const label = dayLabel(x.d);
  if (x.r === null) return `${label} · ${x.maint ? "maintenance" : "pas de mesure"}`;
  const parts = [`${label} · ${pct(x.r)} de disponibilité`];
  if (x.down) parts.push(`env. ${Math.max(1, Math.round((x.down * interval) / 60))} min de panne`);
  if (x.deg) parts.push(`env. ${Math.max(1, Math.round((x.deg * interval) / 60))} min de lenteurs`);
  if (x.maint) parts.push("maintenance");
  return parts.join(" · ");
}

const CSS = `
:root{--bg:#0E0F12;--card:#16181C;--line:#2A2D34;--fg:#ECEAE4;--muted:#8A8C93;--accent:#FF5A1F;--ok:#6FA88F;--warn:#E8B04B;--bad:#F04438;--maint:#7C9CF0;--none:#2A2D34;
--display:"Bricolage Grotesque","Arial Narrow","Helvetica Neue",system-ui,sans-serif;--sans:Inter,system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;--mono:"Geist Mono",ui-monospace,SFMono-Regular,Consolas,monospace}
*{box-sizing:border-box;margin:0;padding:0}
html{color-scheme:dark}
body{background:var(--bg);color:var(--fg);font:15px/1.6 var(--sans);-webkit-font-smoothing:antialiased;border-top:4px solid var(--accent)}
a{color:inherit;text-underline-offset:3px}
a:hover{color:var(--accent)}
:focus-visible{outline:2px solid var(--accent);outline-offset:3px}
.wrap{max-width:860px;margin:0 auto;padding:0 20px}
header.top{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:20px 0;border-bottom:1px solid var(--line)}
.brand{font:800 20px var(--display);letter-spacing:-.04em;text-decoration:none}
.brand span{color:transparent;-webkit-text-stroke:1px var(--fg)}
.label{font:500 11px var(--mono);letter-spacing:.1em;text-transform:uppercase;color:var(--muted)}
h1{margin:44px 0 10px;font:800 clamp(30px,5.5vw,44px)/1.05 var(--display);letter-spacing:-.04em}
h2{font:800 20px var(--display);letter-spacing:-.03em;margin:44px 0 14px}
.intro{color:#C9C7C1;max-width:62ch;white-space:pre-line}
.announce{margin-top:22px;padding:12px 16px;border:1px solid var(--line);border-left:3px solid var(--accent);background:var(--card);white-space:pre-line}
.overall{display:flex;align-items:center;gap:14px;margin-top:28px;padding:18px 20px;border-radius:2px;font:700 18px var(--sans);color:#0E0F12}
.overall.ok{background:var(--ok)}.overall.warn{background:var(--warn)}.overall.bad{background:var(--bad)}.overall.maint{background:var(--maint)}
.overall .bloc{width:12px;height:12px;background:#0E0F12}
.overall small{margin-left:auto;font:500 12px var(--mono);opacity:.75}
.card{border:1px solid var(--line);background:var(--card);border-radius:2px}
.incident{padding:18px 20px;border-left:3px solid var(--warn);margin-top:12px}
.incident.bad{border-left-color:var(--bad)}.incident.maint{border-left-color:var(--maint)}
.incident h3{font:700 17px var(--sans);margin-bottom:4px}
.incident .meta{color:var(--muted);font-size:13px}
.updates{list-style:none;margin-top:14px;display:grid;gap:12px}
.updates li{display:grid;grid-template-columns:150px 1fr;gap:14px}
.updates b{font-weight:600}
.updates p{white-space:pre-line;color:#C9C7C1}
.updates time{display:block;color:var(--muted);font:500 12px var(--mono)}
.group{margin-top:16px}
.group>.label{display:block;margin:0 0 8px}
.comp{padding:16px 20px;border-bottom:1px solid var(--line)}
.comp:last-child{border-bottom:0}
.comp .row{display:flex;align-items:baseline;justify-content:space-between;gap:12px}
.comp .name{font-weight:600}
.comp .desc{color:var(--muted);font-size:13px}
.st{font:500 12px var(--mono);letter-spacing:.04em;white-space:nowrap}
.st.ok{color:var(--ok)}.st.warn{color:var(--warn)}.st.bad{color:var(--bad)}.st.maint{color:var(--maint)}.st.none{color:var(--muted)}
.st .ms{color:var(--muted);margin-right:10px}
.bars{display:flex;gap:2px;height:34px;margin-top:12px}
.bars i{flex:1;border-radius:1px;background:var(--none);min-width:2px;position:relative}
.bars i.ok{background:var(--ok)}.bars i.warn{background:var(--warn)}.bars i.bad{background:var(--bad)}.bars i.maint{background:var(--maint)}
.bars i:hover{opacity:.7}
.axis{display:flex;justify-content:space-between;gap:10px;margin-top:6px;color:var(--muted);font:500 11.5px var(--mono)}
.axis .line{flex:1;border-top:1px solid var(--line);margin-top:8px}
.legend{display:flex;flex-wrap:wrap;gap:14px;margin-top:12px;color:var(--muted);font-size:12.5px}
.legend span{display:inline-flex;align-items:center;gap:6px}
.legend i{width:10px;height:10px;display:inline-block;border-radius:1px}
.past .day{padding:14px 0;border-bottom:1px solid var(--line)}
.past .day>.label{display:block;margin-bottom:6px}
.past .none{color:var(--muted);font-size:14px}
.past .incident{margin-top:8px;border:1px solid var(--line);background:var(--card)}
details summary{cursor:pointer;list-style:none}
details summary::-webkit-details-marker{display:none}
details summary h3::after{content:" +";color:var(--muted);font-weight:400}
details[open] summary h3::after{content:" −"}
footer{display:flex;flex-wrap:wrap;justify-content:space-between;gap:12px;margin:56px 0 32px;padding-top:18px;border-top:1px solid var(--line);color:var(--muted);font-size:13px}
footer nav{display:flex;gap:16px;flex-wrap:wrap}
.axis .short{display:none}
@media (max-width:640px){.wrap{padding:0 16px}h1{margin-top:32px}.overall{font-size:16px;padding:16px}.overall small{display:none}
.updates li{grid-template-columns:1fr;gap:2px}.comp{padding:14px 16px}.bars i:nth-last-child(n+31){display:none}.axis .full{display:none}.axis .short{display:inline}}
`;

const ICON = "data:image/svg+xml," + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><rect width="32" height="32" fill="#0E0F12"/><rect x="11" y="11" width="10" height="10" fill="#6FA88F"/></svg>');

function updatesList(updates) {
  return `<ul class="updates">${updates.map((u) => `<li><div><b>${esc(INCIDENT_STATUS[u.status] || u.status)}</b><time datetime="${esc(u.created_at)}">${esc(dayTime(u.created_at))}</time></div><p>${esc(u.body)}</p></li>`).join("")}</ul>`;
}

function incidentCard(i, { open = true } = {}) {
  const head = `<h3>${esc(i.title)}</h3><div class="meta">${i.sites.length ? `Concerne : ${esc(i.sites.join(", "))} · ` : ""}${i.status === "resolved" && i.resolved_at
    ? `Résolu le ${esc(dayTime(i.resolved_at))}` : `${esc(INCIDENT_STATUS[i.status])} · depuis ${esc(dayTime(i.created_at))}`}</div>`;
  const cls = `card incident ${i.status === "resolved" ? "" : IMPACT[i.impact] || "warn"}`;
  if (open) return `<article class="${cls}" id="incident-${i.id}">${head}${updatesList(i.updates)}</article>`;
  return `<details class="${cls}" id="incident-${i.id}"><summary>${head}</summary>${updatesList(i.updates)}</details>`;
}

/** Page HTML complète. */
export function statusPage(data, { host = "" } = {}) {
  if (!data) {
    return shell("État des services", host, `<h1>État des services</h1><p class="intro">La page de statut n'a pas encore été publiée.</p>`, "");
  }
  const [overallText, overallCls] = OVERALL[data.overall] || OVERALL.operational;
  const days = data.history_days;
  const comps = data.groups.map((g) => `
    <section class="group">${g.name ? `<span class="label">${esc(g.name)}</span>` : ""}
      <div class="card">${g.sites.map((s) => {
        const [label, cls] = SITE_STATUS[s.status] || SITE_STATUS.unknown;
        return `<div class="comp">
          <div class="row"><div><span class="name">${esc(s.name)}</span>${s.description ? `<div class="desc">${esc(s.description)}</div>` : ""}</div>
            <span class="st ${cls}">${s.latency_ms ? `<span class="ms">${esc(s.latency_ms)} ms</span>` : ""}${esc(label)}</span></div>
          <div class="bars" role="img" aria-label="Disponibilité de ${esc(s.name)} sur ${days} jours : ${esc(pct(s.uptime))}">
            ${s.days.map((x) => `<i class="${barClass(x)}" title="${esc(barTitle(x, data.interval))}"></i>`).join("")}</div>
          <div class="axis"><span><span class="full">Il y a ${days} jours</span><span class="short">Il y a 30 jours</span></span><span class="line"></span><span>${esc(pct(s.uptime))} de disponibilité</span><span class="line"></span><span>Aujourd'hui</span></div>
        </div>`;
      }).join("")}</div>
    </section>`).join("");

  // Historique : les 14 derniers jours, jour par jour, comme les pages de statut classiques.
  const byDay = new Map();
  for (const i of data.history) {
    const d = new Intl.DateTimeFormat("en-CA", { timeZone: TZ }).format(new Date(i.resolved_at || i.created_at));
    if (!byDay.has(d)) byDay.set(d, []);
    byDay.get(d).push(i);
  }
  const past = [];
  for (let k = 0; k < 14; k++) {
    const d = new Intl.DateTimeFormat("en-CA", { timeZone: TZ }).format(new Date(Date.parse(data.updated_at) - k * 86_400_000));
    const list = byDay.get(d) || [];
    past.push(`<div class="day"><span class="label">${esc(dayLabel(d))}</span>${list.length ? list.map((i) => incidentCard(i, { open: false })).join("") : `<p class="none">Aucun incident signalé.</p>`}</div>`);
  }

  const body = `
    <h1>${esc(data.title)}</h1>
    ${data.intro ? `<p class="intro">${esc(data.intro)}</p>` : ""}
    ${data.announcement ? `<div class="announce">${esc(data.announcement)}</div>` : ""}
    <div class="overall ${overallCls}"><span class="bloc"></span>${esc(overallText)}<small>Mis à jour à ${esc(time(data.updated_at))}</small></div>
    ${data.incidents.length ? `<h2>Incidents en cours</h2>${data.incidents.map((i) => incidentCard(i)).join("")}` : ""}
    ${data.maintenances.length ? `<h2>Maintenance en cours</h2>${data.maintenances.map((m) => `<article class="card incident maint"><h3>${esc(m.site)}</h3>
      <div class="meta">${m.since ? `Depuis ${esc(dayTime(m.since))}` : ""}${m.until ? ` · fin estimée ${esc(dayTime(m.until))}` : ""}</div>
      ${m.message ? `<p class="intro" style="margin-top:8px">${esc(m.message)}</p>` : ""}</article>`).join("")}` : ""}
    <h2>Services</h2>
    ${comps || `<p class="intro">Aucun service affiché.</p>`}
    <div class="legend"><span><i style="background:var(--ok)"></i>Opérationnel</span><span><i style="background:var(--warn)"></i>Perturbations</span><span><i style="background:var(--bad)"></i>Panne</span><span><i style="background:var(--maint)"></i>Maintenance</span><span><i style="background:var(--none)"></i>Pas de mesure</span></div>
    <h2>Incidents passés</h2>
    <div class="past">${past.join("")}</div>`;
  const footer = `<span>Mis à jour le ${esc(dayTime(data.updated_at))}${data.contact ? ` · <a href="mailto:${esc(data.contact)}">${esc(data.contact)}</a>` : ""}</span>
    <nav><a href="/feed.atom">S'abonner (Atom)</a><a href="/api/status.json">API JSON</a></nav>`;
  return shell(data.title, host, body, footer, 60);
}

function shell(title, host, body, footer, refresh) {
  return `<!doctype html>
<html lang="fr"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="theme-color" content="#0E0F12">
${refresh ? `<meta http-equiv="refresh" content="${refresh}">` : ""}
<title>${esc(title)}</title><link rel="icon" href="${ICON}"><link rel="alternate" type="application/atom+xml" title="Incidents" href="/feed.atom">
<style>${CSS}</style></head><body>
<div class="wrap">
<header class="top"><a class="brand" href="https://unclaim.fr">UN<span>CLAIM</span></a><span class="label">${esc(host || "État des services")}</span></header>
<main>${body}</main>
<footer>${footer}</footer>
</div></body></html>`;
}

/** Résumé JSON public (compatible lecture simple, inspiré de /api/v2/summary.json de Statuspage). */
export function statusJson(data) {
  if (!data) return { status: null, updated_at: null };
  return {
    updated_at: data.updated_at,
    status: { indicator: data.overall, description: (OVERALL[data.overall] || OVERALL.operational)[0] },
    components: data.groups.flatMap((g) => g.sites.map((s) => ({ id: s.id, name: s.name, group: g.name || null, status: s.status, uptime: s.uptime }))),
    incidents: data.incidents.map(({ id, title, impact, status, sites, created_at, updates }) => ({ id, title, impact, status, sites, created_at, updates })),
    maintenances: data.maintenances,
  };
}

/** Flux Atom des incidents (en cours et 30 derniers jours). */
export function atomFeed(data, origin) {
  const items = data ? [...data.incidents, ...data.history] : [];
  const x = (s) => esc(s);
  return `<?xml version="1.0" encoding="utf-8"?>
<feed xmlns="http://www.w3.org/2005/Atom">
<title>${x(data?.title || "État des services")}</title><id>${x(origin)}/</id><link href="${x(origin)}/"/><link rel="self" href="${x(origin)}/feed.atom"/>
<updated>${x(data?.updated_at || new Date().toISOString())}</updated>
${items.map((i) => `<entry><id>${x(origin)}/#incident-${i.id}</id><title>${x(`[${INCIDENT_STATUS[i.status]}] ${i.title}`)}</title>
<link href="${x(origin)}/#incident-${i.id}"/><updated>${x(i.updates[0]?.created_at || i.created_at)}</updated><published>${x(i.created_at)}</published>
<content type="text">${x(i.updates.map((u) => `${INCIDENT_STATUS[u.status]} — ${u.body}`).join("\n\n"))}</content></entry>`).join("\n")}
</feed>`;
}
