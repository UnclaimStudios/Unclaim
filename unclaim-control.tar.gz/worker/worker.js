// Unclaim Edge — Worker Cloudflare placé devant tous les sites Unclaim (routes *.unclaim.fr/*).
//  1. Site en maintenance (état publié par Unclaim Control dans Workers KV) → page « Maintenance en cours »,
//     sauf pour le staff connecté au panneau (cookie uc_bypass signé avec BYPASS_SECRET).
//  2. Origine injoignable ou en erreur (502/503/504/52x/530) → page « Site indisponible » aux couleurs d'Unclaim.
//  3. Sinon la requête passe telle quelle (WebSocket et flux SSE compris).
// Liaisons : STATE (espace Workers KV), BYPASS_SECRET (secret). Voir README.md.
//  4. Nom d'hôte de la page de statut (status.unclaim.fr) → page de statut publique, sans aucun serveur derrière.
import { errorPage, maintenancePage } from "./pages.js";
import { atomFeed, statusJson, statusPage } from "./status.js";

const CF_ERRORS = new Set([520, 521, 522, 523, 524, 525, 526, 527, 530]); // toujours générées par Cloudflare
const ORIGIN_ERRORS = new Set([502, 503, 504]);
const TTL_MS = 15_000;

const cache = {};

/** Lecture KV avec cache mémoire ; si KV est indisponible, on garde la dernière version connue. */
async function load(env, key) {
  const c = cache[key];
  if (c?.value && Date.now() - c.at < TTL_MS) return c.value;
  try {
    cache[key] = { at: Date.now(), value: await env.STATE.get(key, { type: "json", cacheTtl: 30 }) };
  } catch {
    cache[key] = { at: Date.now(), value: c?.value ?? null };
  }
  return cache[key].value;
}

async function statusSite(request, env, url, host) {
  const data = await load(env, "status");
  const headers = { "Cache-Control": "public, max-age=30", "X-Unclaim-Edge": "status" };
  if (url.pathname === "/api/status.json" || url.pathname === "/status.json") {
    return jsonRes(statusJson(data), 200, { ...headers, "Access-Control-Allow-Origin": "*" });
  }
  if (url.pathname === "/feed.atom") {
    return new Response(atomFeed(data, url.origin), { headers: { ...headers, "Content-Type": "application/atom+xml; charset=utf-8" } });
  }
  if (url.pathname !== "/") return Response.redirect(`${url.origin}/`, 302);
  return new Response(statusPage(data, { host }), { headers: { ...headers, "Content-Type": "text/html; charset=utf-8" } });
}

const b64urlBytes = (s) => Uint8Array.from(atob(s.replace(/-/g, "+").replace(/_/g, "/") + "===".slice((s.length + 3) % 4)), (c) => c.charCodeAt(0));

async function hasBypass(request, env) {
  if (!env.BYPASS_SECRET) return false;
  const m = (request.headers.get("Cookie") || "").match(/(?:^|;\s*)uc_bypass=([^;]+)/);
  if (!m) return false;
  try {
    const [payload, sig] = decodeURIComponent(m[1]).split(".");
    if (!payload || !sig) return false;
    const enc = new TextEncoder();
    const key = await crypto.subtle.importKey("raw", enc.encode(env.BYPASS_SECRET), { name: "HMAC", hash: "SHA-256" }, false, ["verify"]);
    if (!(await crypto.subtle.verify("HMAC", key, b64urlBytes(sig), enc.encode(payload)))) return false;
    const { exp } = JSON.parse(new TextDecoder().decode(b64urlBytes(payload)));
    return Number(exp) * 1000 > Date.now();
  } catch {
    return false;
  }
}

const wantsHtml = (request) => request.method === "GET" && (request.headers.get("Accept") || "").includes("text/html");

function html(body, status, extra = {}) {
  return new Response(body, {
    status,
    headers: { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-store", "X-Robots-Tag": "noindex", ...extra },
  });
}

const jsonRes = (body, status, extra = {}) =>
  new Response(JSON.stringify(body), { status, headers: { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store", ...extra } });

function retryAfter(site) {
  const s = site?.until ? Math.round((new Date(site.until).getTime() - Date.now()) / 1000) : 0;
  return String(s > 60 ? Math.min(s, 86_400) : 300);
}

function maintenance(request, site, state, host) {
  const headers = { "Retry-After": retryAfter(site), "X-Unclaim-Edge": "maintenance" };
  if (!wantsHtml(request)) {
    return jsonRes({ error: "maintenance", message: site.message || "Site en maintenance", until: site.until || null }, 503, headers);
  }
  return html(maintenancePage({ site, state, host, ray: request.headers.get("Cf-Ray") }), 503, headers);
}

function failure(request, site, state, host, code) {
  const status = code === "unreachable" ? 502 : code;
  const headers = { "Retry-After": "30", "X-Unclaim-Edge": "error" };
  if (!wantsHtml(request)) return jsonRes({ error: "site_indisponible", code: status }, status, headers);
  return html(errorPage({ site, state, host, code, ray: request.headers.get("Cf-Ray") }), status, headers);
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const host = url.hostname.toLowerCase();
    const state = await load(env, "state");
    const statusHost = String(state?.status_host || env.STATUS_HOST || "").toLowerCase();
    if (statusHost && host === statusHost) return statusSite(request, env, url, host);

    const siteId = state?.hosts?.[host];
    const site = siteId ? state.sites?.[siteId] ?? null : null;

    if (site?.maintenance && !url.pathname.startsWith("/.well-known/") && !(await hasBypass(request, env))) {
      return maintenance(request, site, state, host);
    }

    let res;
    try {
      res = await fetch(request);
    } catch {
      return failure(request, site, state, host, "unreachable");
    }
    // Erreurs propres à Cloudflare : toujours remplacées. 502/503/504 : seulement pour une page HTML,
    // pour ne pas masquer les réponses d'API ni une page que l'application aurait voulu afficher (en-tête X-Unclaim-Passthrough).
    if (CF_ERRORS.has(res.status) || (ORIGIN_ERRORS.has(res.status) && wantsHtml(request) && !res.headers.has("X-Unclaim-Passthrough"))) {
      return failure(request, site, state, host, res.status);
    }
    return res;
  },
};
