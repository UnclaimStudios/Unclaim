// Assemble le Worker en un seul fichier (worker/dist/unclaim-edge.js), à coller dans l'éditeur du tableau
// de bord Cloudflare si tu ne veux pas utiliser Wrangler.  Run: npm run worker:build
import { mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";

const DIR = join(dirname(fileURLToPath(import.meta.url)), "..", "worker");
// Les deux modules définissent leur propre « esc » et « CSS » : chacun est enveloppé dans une portée isolée.
const wrap = (file, names) => {
  const src = readFileSync(join(DIR, file), "utf8").replace(/^export (function|const) /gm, "$1 ");
  return `const { ${names.join(", ")} } = (() => {\n${src}\nreturn { ${names.join(", ")} };\n})();\n`;
};
const pages = wrap("pages.js", ["errorPage", "maintenancePage"]) + wrap("status.js", ["atomFeed", "statusJson", "statusPage"]);
const worker = readFileSync(join(DIR, "worker.js"), "utf8").replace(/^import .* from "\.\/(pages|status)\.js";\r?\n/gm, "");
if (/from "\.\/(pages|status)\.js"/.test(worker)) throw new Error("Imports locaux non retirés");

mkdirSync(join(DIR, "dist"), { recursive: true });
const out = join(DIR, "dist", "unclaim-edge.js");
writeFileSync(out, `// Fichier généré par npm run worker:build — ne pas modifier, éditer worker/worker.js et worker/pages.js.\n${pages}\n${worker}`);
console.log(`Worker assemblé : ${out}`);
