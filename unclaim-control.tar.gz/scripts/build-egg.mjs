// Génère l'œuf Pelican (format PTDL_v2, importable dans Pelican comme dans Pterodactyl) d'Unclaim Control.
// Le script d'installation vit dans pelican/install-control.sh.  Run: npm run egg
import { readFileSync, writeFileSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";

const DIR = join(dirname(fileURLToPath(import.meta.url)), "..", "pelican");

const v = (name, env, description, def = "", rules = "nullable|string|max:500") =>
  ({ name, description, env_variable: env, default_value: def, user_viewable: true, user_editable: true, rules, field_type: "text" });

const egg = {
  _comment: "DO NOT EDIT: FILE GENERATED AUTOMATICALLY BY PTERODACTYL PANEL - PTERODACTYL.IO",
  meta: { version: "PTDL_v2", update_url: null },
  exported_at: new Date().toISOString().replace(/\.\d+Z$/, "+00:00"),
  name: "Unclaim Control",
  author: "dev.tomyy58@gmail.com",
  description: "Panneau staff des sites Unclaim (control.unclaim.fr) : état des serveurs Pelican, maintenance publiée vers le Worker Cloudflare, variables d'environnement par site. Node.js ≥ 22.13, aucune dépendance npm, base SQLite dans data/.",
  features: null,
  docker_images: { "Node.js 22": "ghcr.io/parkervcp/yolks:nodejs_22", "Node.js 24": "ghcr.io/parkervcp/yolks:nodejs_24" },
  file_denylist: [],
  startup: "PORT={{SERVER_PORT}} DATA_DIR=/home/container/data NODE_ENV=production node --env-file-if-exists=.env server.mjs",
  config: { files: "{}", startup: JSON.stringify({ done: "Unclaim Control sur" }), logs: "{}", stop: "^C" },
  scripts: {
    installation: {
      script: readFileSync(join(DIR, "install-control.sh"), "utf8").replace(/\r\n/g, "\n"),
      container: "ghcr.io/parkervcp/installers:debian",
      entrypoint: "bash",
    },
  },
  variables: [
    v("Dépôt Git", "GIT_REPO", "Adresse HTTPS du dépôt. Laisse vide pour utiliser ARCHIVE_URL ou déposer les fichiers à la main.", "", "nullable|string|max:300"),
    v("Branche Git", "GIT_BRANCH", "Branche à installer (vide : branche par défaut).", "", "nullable|string|max:100"),
    v("Sous-dossier du dépôt", "GIT_SUBDIR", "Si le panneau est dans un sous-dossier du dépôt (ex. unclaim-control).", "", "nullable|string|max:200"),
    v("Jeton Git (dépôt privé)", "GIT_TOKEN", "Jeton d'accès en lecture pour un dépôt privé.", "", "nullable|string|max:300"),
    v("URL de l'archive", "ARCHIVE_URL", "Alternative à Git : lien direct vers unclaim-control.tar.gz.", "", "nullable|url|max:500"),
    v("Adresse publique", "PUBLIC_URL", "Adresse HTTPS du panneau, sans / final.", "https://control.unclaim.fr", "required|url|max:200"),
    v("Unclaim Auth : adresse", "UNCLAIM_API_URL", "Passerelle de connexion.", "https://auth.unclaim.fr", "required|url|max:200"),
    v("Unclaim Auth : client_id", "UNCLAIM_CLIENT_ID", "Application « Unclaim Control » créée sur auth.unclaim.fr (URL de retour : <adresse publique>/auth/callback).", "", "nullable|string|max:200"),
    v("Unclaim Auth : client_secret", "UNCLAIM_CLIENT_SECRET", "Secret de l'application.", "", "nullable|string|max:300"),
    v("Super-admins (IDs Discord)", "ADMIN_DISCORD_IDS", "IDs Discord séparés par des virgules : accès complet (variables, staff, sites).", "", "required|string|max:500"),
    v("Pelican : adresse du panel", "PELICAN_URL", "Ex. https://panel.unclaim.fr", "", "nullable|url|max:200"),
    v("Pelican : clé API client", "PELICAN_CLIENT_KEY", "Clé API (Compte › Clés API) d'un compte qui a accès à tous les serveurs Unclaim.", "", "nullable|string|max:300"),
    v("Cloudflare : jeton API", "CF_API_TOKEN", "Jeton avec la permission « Workers KV Storage : Edit ».", "", "nullable|string|max:300"),
    v("Cloudflare : ID du compte", "CF_ACCOUNT_ID", "Visible dans le tableau de bord Cloudflare (barre latérale de Workers).", "", "nullable|string|max:100"),
    v("Cloudflare : ID du namespace KV", "CF_KV_NAMESPACE_ID", "Espace KV lié au Worker sous le nom STATE.", "", "nullable|string|max:100"),
    v("Secret de contournement", "BYPASS_SECRET", "Même valeur que le secret BYPASS_SECRET du Worker (openssl rand -hex 32).", "", "nullable|string|max:200"),
    v("Domaine du cookie staff", "COOKIE_DOMAIN", "Domaine commun à tous les sites, pour que le staff passe la maintenance partout.", ".unclaim.fr", "nullable|string|max:100"),
    v("Email public de contact", "PUBLIC_CONTACT_EMAIL", "Affiché sur les pages d'erreur et de maintenance (sauf email propre au site).", "contact@unclaim.fr", "nullable|email|max:200"),
    v("Page d'état publique", "STATUS_URL", "Facultatif : lien « État des services » sur les pages d'erreur.", "", "nullable|url|max:200"),
    v("Alertes Discord (webhook)", "DISCORD_WEBHOOK_URL", "Facultatif : message dans un salon quand un site tombe ou revient.", "", "nullable|url|max:300"),
    v("Intervalle de vérification (s)", "HEALTH_INTERVAL", "Fréquence des tests de chaque site.", "60", "required|integer|between:15,3600"),
  ],
};

writeFileSync(join(DIR, "egg-unclaim-control.json"), JSON.stringify(egg, null, 4) + "\n");
console.log(`egg-unclaim-control.json : ${egg.variables.length} variables`);
