#!/usr/bin/env node
// Unclaim Control — configure tout Cloudflare en une commande (Node ≥ 22, aucune dépendance) :
//   1. espace Workers KV « unclaim-state »          4. routes unclaim.fr/* et *.unclaim.fr/*
//   2. secret de contournement BYPASS_SECRET         5. DNS status.unclaim.fr (AAAA 100::, proxifié)
//   3. Worker « unclaim-edge » + liaisons STATE/BYPASS_SECRET
//   6. jeton limité à Workers KV pour le panneau (si ton jeton a le droit d'en créer)
// Puis écrit les valeurs à coller dans les variables du serveur Pelican (cloudflare-result.env).
//
//   node setup-cloudflare.mjs              montre ce qui va être fait, demande confirmation
//   node setup-cloudflare.mjs --dry-run    montre seulement, ne change rien
//   node setup-cloudflare.mjs --yes        sans confirmation
//   node setup-cloudflare.mjs --force      remplace une route déjà reliée à un autre Worker
// Options : --zone unclaim.fr  --status-host status.unclaim.fr  --worker unclaim-edge
// Jeton : variable CLOUDFLARE_API_TOKEN, sinon il est demandé au lancement. Il n'est jamais écrit sur disque.
import { createInterface } from "node:readline/promises";
import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";
import { randomBytes } from "node:crypto";

const HERE = dirname(fileURLToPath(import.meta.url));
const API = (process.env.CF_API_URL || "https://api.cloudflare.com/client/v4").replace(/\/+$/, "");
const args = process.argv.slice(2);
const flag = (f) => args.includes(f);
const opt = (name, def) => { const i = args.indexOf(name); return i >= 0 && args[i + 1] ? args[i + 1] : def; };

const ZONE = opt("--zone", "unclaim.fr");
const STATUS_HOST = opt("--status-host", `status.${ZONE}`);
const WORKER = opt("--worker", "unclaim-edge");
const KV_TITLE = opt("--kv", "unclaim-state");
const ROUTES = [`${ZONE}/*`, `*.${ZONE}/*`];
const DRY = flag("--dry-run");
const RESULT = join(process.cwd(), "cloudflare-result.env");

const say = (s = "") => console.log(s);
const ok = (s) => say(`  ✓ ${s}`);
const todo = (s) => say(`  → ${s}`);
const warn = (s) => say(`  ! ${s}`);
const die = (s) => { console.error(`\n✗ ${s}`); process.exit(1); };

let TOKEN = process.env.CLOUDFLARE_API_TOKEN || "";
const rl = createInterface({ input: process.stdin, output: process.stdout });

async function cf(method, path, body, { form = false, allowFail = false } = {}) {
  const headers = { Authorization: `Bearer ${TOKEN}` };
  if (body !== undefined && !form) headers["Content-Type"] = "application/json";
  let res;
  try {
    res = await fetch(`${API}${path}`, { method, headers, body: body === undefined ? undefined : form ? body : JSON.stringify(body), signal: AbortSignal.timeout(30_000) });
  } catch (e) {
    die(`Cloudflare injoignable (${e.cause?.code || e.message}).`);
  }
  const data = await res.json().catch(() => ({}));
  if (!res.ok || data.success === false) {
    const msg = (data.errors || []).map((e) => `${e.code} ${e.message}`).join(" ; ") || `HTTP ${res.status}`;
    if (allowFail) return { error: msg, status: res.status };
    die(`${method} ${path} : ${msg}\n  Vérifie les permissions du jeton (voir l'en-tête de ce script ou le tuto).`);
  }
  return data.result ?? data;
}

/** Valeurs d'un précédent lancement : on garde le même secret pour ne pas désynchroniser le panneau. */
function previous() {
  if (!existsSync(RESULT)) return {};
  const out = {};
  for (const line of readFileSync(RESULT, "utf8").split(/\r?\n/)) {
    const m = line.match(/^([A-Z_]+)=(.*)$/);
    if (m) out[m[1]] = m[2];
  }
  return out;
}

function workerCode() {
  for (const p of [join(HERE, "unclaim-edge.js"), join(HERE, "..", "worker", "dist", "unclaim-edge.js"), join(process.cwd(), "unclaim-edge.js")]) {
    if (existsSync(p)) return { path: p, code: readFileSync(p, "utf8") };
  }
  die("unclaim-edge.js introuvable. Place-le à côté de ce script (il est dans le dossier pelican/), ou lance d'abord : npm run worker:build");
}

async function main() {
  say("\nUnclaim Control — configuration Cloudflare");
  say(`Zone ${ZONE} · Worker ${WORKER} · page de statut ${STATUS_HOST}${DRY ? " · SIMULATION (rien ne sera modifié)" : ""}\n`);

  if (!TOKEN) TOKEN = (await rl.question("Colle ton jeton API Cloudflare puis Entrée : ")).trim();
  if (!TOKEN) die("Aucun jeton.");
  const { code, path: codePath } = workerCode();

  // ---------- lecture de l'existant ----------
  say("Lecture de ton compte…");
  const v = await cf("GET", "/user/tokens/verify", undefined, { allowFail: true });
  if (v.error) die(`Jeton refusé : ${v.error}`);
  ok("jeton valide");

  const zones = await cf("GET", `/zones?name=${encodeURIComponent(ZONE)}`);
  const zone = zones[0] ?? die(`Zone ${ZONE} introuvable avec ce jeton (permission « Zone › Zone › Lire » sur ${ZONE}).`);
  const account = zone.account.id;
  ok(`zone ${ZONE} (compte ${zone.account.name || account})`);

  const namespaces = await cf("GET", `/accounts/${account}/storage/kv/namespaces?per_page=100`);
  let ns = namespaces.find((n) => n.title === KV_TITLE);

  const routes = await cf("GET", `/zones/${zone.id}/workers/routes`);
  // Le droit DNS est facultatif (absent du modèle « Modifier les Workers Cloudflare ») : sans lui, DNS à faire à la main.
  const records = await cf("GET", `/zones/${zone.id}/dns_records?name=${encodeURIComponent(STATUS_HOST)}`, undefined, { allowFail: true });
  const dnsAllowed = Array.isArray(records);
  const prev = previous();
  const bypass = process.env.BYPASS_SECRET || prev.BYPASS_SECRET || randomBytes(32).toString("hex");

  // ---------- plan ----------
  say("\nCe qui va être fait :");
  ns ? ok(`espace KV « ${KV_TITLE} » existe déjà (${ns.id})`) : todo(`créer l'espace KV « ${KV_TITLE} »`);
  prev.BYPASS_SECRET || process.env.BYPASS_SECRET ? ok("BYPASS_SECRET repris du lancement précédent") : todo("générer un BYPASS_SECRET");
  todo(`envoyer le Worker « ${WORKER} » (${Math.round(code.length / 1024)} Ko, ${codePath}) avec les liaisons STATE et BYPASS_SECRET`);
  const routePlan = [];
  for (const pattern of ROUTES) {
    const r = routes.find((x) => x.pattern === pattern);
    if (!r) { todo(`créer la route ${pattern}`); routePlan.push({ pattern, action: "create" }); }
    else if (r.script === WORKER) { ok(`route ${pattern} déjà reliée à ${WORKER}`); }
    else if (flag("--force")) { todo(`remplacer la route ${pattern} (reliée à « ${r.script || "aucun Worker"} »)`); routePlan.push({ pattern, action: "update", id: r.id }); }
    else die(`La route ${pattern} est déjà reliée au Worker « ${r.script || "aucun"} ». Relance avec --force pour la remplacer, en sachant que ce Worker ne s'exécutera plus.`);
  }
  // Une route plus précise (ex. link.unclaim.fr/*) l'emporte sur *.unclaim.fr/* : ce site n'aura pas les pages Unclaim.
  for (const r of routes.filter((x) => !ROUTES.includes(x.pattern) && x.script && x.script !== WORKER)) {
    warn(`la route ${r.pattern} reste reliée à « ${r.script} » : ce site n'aura pas les pages maintenance/erreur.`);
  }
  const dns = dnsAllowed ? records[0] : null;
  if (!dnsAllowed) warn(`pas de droit DNS sur ce jeton : crée à la main ${STATUS_HOST} en AAAA 100::, proxifié (nuage orange).`);
  else if (!dns) todo(`créer le DNS ${STATUS_HOST} (AAAA 100::, proxifié)`);
  else if (!dns.proxied) warn(`${STATUS_HOST} existe (${dns.type} ${dns.content}) mais n'est pas proxifié : active le nuage orange, sinon la page de statut ne s'affichera pas.`);
  else ok(`DNS ${STATUS_HOST} existe et est proxifié`);
  todo("créer un jeton limité à « Workers KV : Modifier » pour le panneau (si ton jeton le permet)");

  if (DRY) { say("\nSimulation terminée : rien n'a été modifié."); rl.close(); return; }
  if (!flag("--yes")) {
    const a = (await rl.question("\nOn y va ? (o/N) ")).trim().toLowerCase();
    if (a !== "o" && a !== "oui" && a !== "y") { say("Annulé, rien n'a été modifié."); rl.close(); return; }
  }
  rl.close();

  // ---------- exécution ----------
  say("");
  if (!ns) {
    ns = await cf("POST", `/accounts/${account}/storage/kv/namespaces`, { title: KV_TITLE });
    ok(`espace KV créé (${ns.id})`);
  }

  const form = new FormData();
  form.append("metadata", new Blob([JSON.stringify({
    main_module: "worker.js",
    compatibility_date: "2026-10-01",
    bindings: [
      { type: "kv_namespace", name: "STATE", namespace_id: ns.id },
      { type: "secret_text", name: "BYPASS_SECRET", text: bypass },
      { type: "plain_text", name: "STATUS_HOST", text: STATUS_HOST },
    ],
  })], { type: "application/json" }));
  form.append("worker.js", new Blob([code], { type: "application/javascript+module" }), "worker.js");
  await cf("PUT", `/accounts/${account}/workers/scripts/${WORKER}`, form, { form: true });
  ok(`Worker « ${WORKER} » envoyé avec ses liaisons`);

  for (const r of routePlan) {
    if (r.action === "create") await cf("POST", `/zones/${zone.id}/workers/routes`, { pattern: r.pattern, script: WORKER });
    else await cf("PUT", `/zones/${zone.id}/workers/routes/${r.id}`, { pattern: r.pattern, script: WORKER });
    ok(`route ${r.pattern}`);
  }

  if (dnsAllowed && !dns) {
    await cf("POST", `/zones/${zone.id}/dns_records`, { type: "AAAA", name: STATUS_HOST, content: "100::", proxied: true, comment: "Page de statut servie par le Worker unclaim-edge" });
    ok(`DNS ${STATUS_HOST}`);
  }

  // Jeton dédié au panneau : seulement « Workers KV Storage : Modifier » sur ce compte.
  let panelToken = "";
  const groups = await cf("GET", "/user/tokens/permission_groups", undefined, { allowFail: true });
  const kvWrite = Array.isArray(groups) && groups.find((g) => /workers kv storage write/i.test(g.name));
  if (kvWrite) {
    const t = await cf("POST", "/user/tokens", {
      name: `Unclaim Control (KV) ${new Date().toISOString().slice(0, 10)}`,
      policies: [{ effect: "allow", resources: { [`com.cloudflare.api.account.${account}`]: "*" }, permission_groups: [{ id: kvWrite.id }] }],
    }, { allowFail: true });
    if (t.value) { panelToken = t.value; ok("jeton du panneau créé (Workers KV uniquement)"); }
    else warn(`jeton du panneau non créé (${t.error}).`);
  } else {
    warn("ton jeton n'a pas le droit de créer d'autres jetons.");
  }
  if (!panelToken) warn("Crée-le à la main : Mon profil › Jetons d'API › personnalisé › Compte · Workers KV Storage · Modifier, et mets-le dans CF_API_TOKEN.");

  // ---------- résultat ----------
  const lines = [
    "# Valeurs à coller dans les variables du serveur Pelican « Unclaim Control » (onglet Startup).",
    "# Ce fichier contient des secrets : supprime-le une fois les variables remplies.",
    `CF_ACCOUNT_ID=${account}`,
    `CF_KV_NAMESPACE_ID=${ns.id}`,
    `CF_API_TOKEN=${panelToken || "A_CREER_A_LA_MAIN"}`,
    `BYPASS_SECRET=${bypass}`,
    `COOKIE_DOMAIN=.${ZONE}`,
    `STATUS_HOST=${STATUS_HOST}`,
    "",
  ];
  writeFileSync(RESULT, lines.join("\n"), { mode: 0o600 });
  say(`\nTerminé. Valeurs pour Pelican écrites dans :\n  ${RESULT}\n`);
  say(lines.slice(2, -1).map((l) => `  ${l}`).join("\n"));
  say("\nÉtape suivante : colle ces valeurs dans l'onglet Startup du serveur Unclaim Control, puis démarre-le.");
  say("Le panneau publie l'état au démarrage ; status." + ZONE + " affiche « pas encore publiée » d'ici là.\n");
}

main().catch((e) => die(e.stack || e.message));
