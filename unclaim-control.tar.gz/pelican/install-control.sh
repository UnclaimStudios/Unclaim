#!/bin/bash
# Pelican — installation / mise à jour d'Unclaim Control (aucune dépendance npm).
# Source au choix : GIT_REPO (+ GIT_BRANCH, GIT_SUBDIR, GIT_TOKEN) ou ARCHIVE_URL (unclaim-control.tar.gz).
# Sans source : dépose le contenu de unclaim-control.tar.gz dans le gestionnaire de fichiers du panel.
# Le dossier data/ (base SQLite) et le fichier .env ne sont jamais touchés.
set -euo pipefail
SERVER_DIR="${SERVER_DIR:-/mnt/server}"
mkdir -p "$SERVER_DIR" && cd "$SERVER_DIR"

need() { command -v "$1" >/dev/null 2>&1; }
if ! need git || ! need curl || ! need tar; then
  export DEBIAN_FRONTEND=noninteractive
  apt-get update -qq >/dev/null && apt-get install -y -qq git curl ca-certificates tar >/dev/null
fi

WORK="$(mktemp -d)"
SRC=""
if [ -n "${GIT_REPO:-}" ]; then
  url="$GIT_REPO"
  [ -n "${GIT_TOKEN:-}" ] && url="https://${GIT_TOKEN}@${GIT_REPO#https://}"
  echo "Récupération du dépôt ${GIT_REPO} ${GIT_BRANCH:+(branche $GIT_BRANCH)}…"
  git clone --quiet --depth 1 ${GIT_BRANCH:+--branch "$GIT_BRANCH"} "$url" "$WORK/src"
  SRC="$WORK/src${GIT_SUBDIR:+/$GIT_SUBDIR}"
elif [ -n "${ARCHIVE_URL:-}" ]; then
  echo "Téléchargement de ${ARCHIVE_URL}…"
  curl -fsSL "$ARCHIVE_URL" -o "$WORK/app.tar.gz"
  mkdir "$WORK/src" && tar -xzf "$WORK/app.tar.gz" -C "$WORK/src"
  SRC="$WORK/src"
  # Archive avec un seul dossier racine : on descend dedans.
  if [ ! -f "$SRC/server.mjs" ] && [ "$(ls -A "$SRC" | wc -l)" -eq 1 ]; then SRC="$SRC/$(ls -A "$SRC")"; fi
fi

mkdir -p data
if [ -z "$SRC" ]; then
  echo "Aucune source indiquée (GIT_REPO ou ARCHIVE_URL)."
  echo "→ Dépose le contenu de unclaim-control.tar.gz dans le gestionnaire de fichiers, puis démarre le serveur."
  rm -rf "$WORK"
  exit 0
fi
[ -f "$SRC/server.mjs" ] || { echo "Erreur : server.mjs introuvable dans la source."; exit 1; }

rm -rf lib public worker
cp -a "$SRC/server.mjs" "$SRC/package.json" "$SRC/lib" "$SRC/public" "$SRC/worker" .
[ -f "$SRC/README.md" ] && cp -a "$SRC/README.md" .
rm -rf "$WORK"
echo "Unclaim Control installé. Démarre le serveur depuis le panel."
