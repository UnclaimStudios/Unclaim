// Unclaim Control — interface du panneau staff (aucune dépendance).
const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);

const STATUS = {
  online: "En ligne", degraded: "Dégradé", down: "Hors ligne", maintenance: "Maintenance", unknown: "Inconnu",
};
const PELICAN_STATE = { running: "Allumé", offline: "Éteint", starting: "Démarrage", stopping: "Arrêt" };
const ENV_MODE = { both: "Variables Pelican + fichier .env", startup: "Variables de démarrage Pelican", dotenv: "Fichier .env", none: "Aucune" };

let ME = null;
let CONFIG = {};
let SITES = [];
let refreshTimer = null;

// ---------- utilitaires ----------
class ApiError extends Error {}
async function api(method, path, body) {
  const res = await fetch(path, {
    method,
    headers: body !== undefined ? { "Content-Type": "application/json" } : {},
    body: body !== undefined ? JSON.stringify(body) : undefined,
    credentials: "same-origin",
  });
  if (res.status === 401) { renderLogin(); throw new ApiError("Connexion requise"); }
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new ApiError(data.error || `Erreur ${res.status}`);
  return data;
}

function toast(text, bad = false) {
  const el = document.createElement("div");
  el.className = `toast${bad ? " bad" : ""}`;
  el.textContent = text;
  $("#toasts").append(el);
  setTimeout(() => el.remove(), bad ? 7000 : 3500);
}

async function busy(btn, fn) {
  if (btn) btn.disabled = true;
  try { return await fn(); }
  catch (e) { if (!(e instanceof ApiError && e.message === "Connexion requise")) toast(e.message, true); }
  finally { if (btn) btn.disabled = false; }
}

function ago(iso) {
  if (!iso) return "jamais";
  const s = Math.round((Date.now() - new Date(iso).getTime()) / 1000);
  if (s < 45) return "à l'instant";
  if (s < 3600) return `il y a ${Math.round(s / 60)} min`;
  if (s < 86400) return `il y a ${Math.round(s / 3600)} h`;
  return `il y a ${Math.round(s / 86400)} j`;
}
const dateFr = (iso) => iso ? new Date(iso).toLocaleString("fr-FR", { weekday: "short", day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" }) : "";
const bytes = (n) => n == null ? "—" : n > 1 << 30 ? `${(n / (1 << 30)).toFixed(1)} Go` : `${Math.round(n / (1 << 20))} Mo`;
const duration = (ms) => {
  if (!ms) return "—";
  const m = Math.floor(ms / 60000);
  return m < 60 ? `${m} min` : m < 1440 ? `${Math.floor(m / 60)} h ${m % 60} min` : `${Math.floor(m / 1440)} j ${Math.floor((m % 1440) / 60)} h`;
};
const chip = (status) => `<span class="chip s-${esc(status)}"><span class="bloc"></span>${esc(STATUS[status] || status)}</span>`;
const isSuper = () => ME?.role === "super";
const toLocalInput = (iso) => {
  if (!iso) return "";
  const d = new Date(iso);
  return new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 16);
};

// ---------- navigation ----------
function go(href) {
  history.pushState(null, "", href);
  route();
}
addEventListener("popstate", () => route());
document.addEventListener("click", (e) => {
  const a = e.target.closest("a[data-nav]");
  if (!a || e.ctrlKey || e.metaKey || e.shiftKey || e.button !== 0) return;
  e.preventDefault();
  go(a.getAttribute("href"));
});

async function boot() {
  try {
    const r = await api("GET", "/api/me");
    ME = r.user;
    CONFIG = r.config;
    route();
  } catch { /* écran de connexion déjà affiché */ }
}

function shell(active) {
  if (!$("#main")) {
    $("#app").innerHTML = `
      <header class="top">
        <a class="brand" href="/" data-nav><b>UN<span>CLAIM</span></b><small class="label">Control</small></a>
        <nav class="tabs" id="tabs"></nav>
        <div class="me">
          <span class="avatar">${ME.avatar_url ? `<img class="avatar" src="${esc(ME.avatar_url)}" alt="">` : esc(ME.name.slice(0, 1))}</span>
          <span class="who"><b>${esc(ME.name)}</b> <span class="muted small">${ME.role === "super" ? "super-admin" : "staff"}</span></span>
          <button class="btn ghost sm" id="logout">Déconnexion</button>
        </div>
      </header>
      <main id="main" class="wrap"></main>`;
    $("#logout").onclick = async () => { await fetch("/auth/logout", { method: "POST" }); location.href = "/"; };
  }
  const tabs = [["/", "Sites", "sites"], ["/statut", "Statut", "statut"], ["/journal", "Journal", "journal"]];
  if (isSuper()) tabs.push(["/staff", "Staff", "staff"]);
  $("#tabs").innerHTML = tabs.map(([h, l, k]) => `<a class="tab${k === active ? " on" : ""}" href="${h}" data-nav>${l}</a>`).join("");
  return $("#main");
}

function route() {
  clearInterval(refreshTimer);
  const path = location.pathname.replace(/\/+$/, "") || "/";
  const site = path.match(/^\/sites\/([a-z0-9-]+)$/);
  if (site) return viewSite(site[1]);
  if (path === "/journal") return viewJournal();
  if (path === "/statut") return viewStatus();
  if (path === "/staff" && isSuper()) return viewStaff();
  return viewSites();
}

// ---------- connexion ----------
function renderLogin() {
  clearInterval(refreshTimer);
  document.title = "Connexion · Unclaim Control";
  $("#app").innerHTML = `
    <div class="center"><main class="notice">
      <span class="label">Unclaim Control</span>
      <h1>Panneau staff</h1>
      <p class="muted">État des sites Unclaim, maintenance et configuration. Accès réservé à l'équipe.</p>
      <a class="btn" href="/auth/start">Se connecter avec Unclaim</a>
      <form class="login-dev" id="devform" hidden>
        <span class="label">Connexion de test (local)</span>
        <input name="dev" placeholder="ID Discord" required pattern="\\d{3,32}">
        <input name="name" placeholder="Nom affiché">
        <button class="btn ghost">Entrer en local</button>
      </form>
    </main></div>`;
  // Le formulaire de test n'apparaît que si le serveur l'autorise (CONTROL_DEV_LOGIN=1, hors production).
  fetch("/health").then((r) => r.json()).then(({ dev_login }) => {
    const f = $("#devform");
    if (!dev_login || !f) return;
    f.hidden = false;
    f.onsubmit = (e) => {
      e.preventDefault();
      location.href = `/auth/start?${new URLSearchParams(new FormData(f))}`;
    };
  }).catch(() => {});
}

// ---------- liste des sites ----------
async function loadSites() {
  const r = await api("GET", "/api/sites");
  SITES = r.sites;
  if (r.edge_status) CONFIG.edge_status = r.edge_status;
  return SITES;
}

function banners() {
  const out = [];
  if (!CONFIG.pelican) out.push(`<div class="banner"><div><b>Pelican n'est pas relié</b><span class="muted">Renseigne PELICAN_URL et PELICAN_CLIENT_KEY : sans eux, pas d'état serveur, de redémarrage ni de variables.</span></div></div>`);
  if (!CONFIG.edge) out.push(`<div class="banner"><div><b>Cloudflare n'est pas relié</b><span class="muted">Renseigne CF_API_TOKEN, CF_ACCOUNT_ID et CF_KV_NAMESPACE_ID : sans eux, la maintenance n'est pas visible des visiteurs.</span></div></div>`);
  else if (CONFIG.edge_status?.ok === false) out.push(`<div class="banner bad"><div><b>La dernière publication vers Cloudflare a échoué</b><span class="muted">${esc(CONFIG.edge_status.error)} — nouvel essai automatique à chaque vérification.</span></div>${isSuper() ? `<button class="btn ghost sm" id="republish" style="margin-left:auto">Republier</button>` : ""}</div>`);
  const inMaint = SITES.filter((s) => s.maintenance);
  if (inMaint.length) out.push(`<div class="banner on"><div><b>${inMaint.length === SITES.length ? "Tous les sites sont en maintenance" : `${inMaint.length} site${inMaint.length > 1 ? "s" : ""} en maintenance`}</b><span class="muted">${inMaint.map((s) => esc(s.name)).join(", ")}</span></div></div>`);
  return out.join("");
}

function bindRepublish(root, after) {
  const b = $("#republish", root);
  if (b) b.onclick = () => busy(b, async () => { await api("POST", "/api/edge/publish"); toast("État publié sur Cloudflare"); CONFIG.edge_status.ok = true; after(); });
}

async function viewSites() {
  const main = shell("sites");
  document.title = "Sites · Unclaim Control";
  if (!SITES.length) main.innerHTML = `<p class="boot">Chargement des sites…</p>`;
  await busy(null, loadSites);
  const selected = new Set();

  const draw = () => {
    const count = (st) => SITES.filter((s) => s.status === st).length;
    main.innerHTML = `
      <div class="head">
        <div><h1>Sites</h1><p class="sub">${SITES.length} site${SITES.length > 1 ? "s" : ""} hébergé${SITES.length > 1 ? "s" : ""} sur Pelican · vérification automatique chaque minute</p></div>
        <div class="toolbar">
          <button class="btn ghost" id="checkall">Tout vérifier</button>
          <button class="btn ghost" id="maint">Maintenance…</button>
          ${isSuper() ? `<button class="btn ghost" id="import">Importer depuis Pelican</button><button class="btn" id="add">Ajouter un site</button>` : ""}
        </div>
      </div>
      ${banners()}
      <div class="stats">
        ${["online", "degraded", "down", "maintenance"].map((st) => `<div class="stat"><span class="label s-${st}"><span class="bloc"></span>${STATUS[st]}</span><b>${count(st)}</b></div>`).join("")}
      </div>
      ${SITES.length ? `
      <table class="table">
        <thead><tr>
          <th class="cell-check"><input type="checkbox" id="selall" aria-label="Tout sélectionner"></th>
          <th>Site</th><th>État</th><th class="hide-m">Serveur Pelican</th><th class="hide-m">Réponse</th><th class="hide-m">Contacts</th>
        </tr></thead>
        <tbody>${SITES.map((s) => `
          <tr class="link" data-id="${esc(s.id)}">
            <td class="cell-check"><input type="checkbox" class="sel" value="${esc(s.id)}" ${selected.has(s.id) ? "checked" : ""} aria-label="Sélectionner ${esc(s.name)}"></td>
            <td><div class="name">${esc(s.name)}</div><div class="hosts">${esc(s.hosts.join(" · ") || s.public_url || "—")}</div></td>
            <td>${chip(s.status)}<div class="detail">${esc(s.status_detail)}${s.checked_at ? ` · ${ago(s.checked_at)}` : ""}</div></td>
            <td class="hide-m"><div class="res">
              ${s.pelican_server ? `<b>${esc(PELICAN_STATE[s.pelican_state] || s.pelican_state || "—")}</b><span>${esc(s.pelican_server)}</span>
              ${s.resources ? `<span>${bytes(s.resources.memory_bytes)} · ${s.resources.cpu != null ? `${s.resources.cpu.toFixed(0)} % CPU` : ""}</span>` : ""}` : `<span>non relié</span>`}
            </div></td>
            <td class="hide-m"><div class="res">${s.http_code ? `<b>HTTP ${s.http_code}</b><span>${s.latency_ms} ms</span>` : "<span>—</span>"}</div></td>
            <td class="hide-m"><div class="contacts">${s.contacts.map((c) => `<a href="mailto:${esc(c)}">${esc(c)}</a>`).join("") || `<span class="muted">—</span>`}</div></td>
          </tr>`).join("")}
        </tbody>
      </table>` : `
      <div class="empty"><h3>Aucun site pour l'instant</h3><p>${isSuper() ? "Ajoute un site à la main ou importe tes serveurs Pelican." : "Un super-admin doit d'abord ajouter les sites."}</p></div>`}`;

    bindRepublish(main, draw);
    $("#checkall").onclick = (e) => busy(e.target, async () => {
      e.target.textContent = "Vérification…";
      SITES = (await api("POST", "/api/sites/check")).sites;
      draw();
      toast("Tous les sites ont été vérifiés");
    }).finally(() => { if ($("#checkall")) $("#checkall").textContent = "Tout vérifier"; });
    $("#maint").onclick = () => maintenanceModal([...selected], draw);
    if ($("#add")) $("#add").onclick = () => siteModal(null);
    if ($("#import")) $("#import").onclick = () => importModal();
    for (const tr of $$("tr.link", main)) {
      tr.onclick = (e) => { if (!e.target.closest("input, a")) go(`/sites/${tr.dataset.id}`); };
    }
    for (const cb of $$(".sel", main)) cb.onchange = () => { cb.checked ? selected.add(cb.value) : selected.delete(cb.value); syncSel(); };
    const all = $("#selall");
    const syncSel = () => {
      if (!all) return;
      all.checked = selected.size === SITES.length;
      all.indeterminate = selected.size > 0 && selected.size < SITES.length;
      $("#maint").textContent = selected.size ? `Maintenance (${selected.size})…` : "Maintenance…";
    };
    if (all) all.onchange = () => { for (const s of SITES) all.checked ? selected.add(s.id) : selected.delete(s.id); draw(); };
    syncSel();
  };
  draw();
  refreshTimer = setInterval(async () => {
    if (document.hidden || $(".overlay")) return;
    try { await loadSites(); draw(); } catch { /* réessai au prochain tour */ }
  }, 30_000);
}

// ---------- maintenance ----------
function maintenanceModal(preselected, after) {
  const pre = new Set(preselected);
  const allMode = !pre.size;
  const first = SITES.find((s) => pre.has(s.id) && s.maintenance);
  const modal = openModal(`
    <header><div><span class="label">Maintenance</span><h2>Mettre des sites en maintenance</h2></div><button class="icon-btn" data-close aria-label="Fermer">✕</button></header>
    <p class="muted">Les visiteurs voient la page « Maintenance en cours ». Toi et le staff connecté au panneau continuez d'accéder aux sites normalement.</p>
    <div class="form">
      <label class="check"><input type="radio" name="scope" value="all" ${allMode ? "checked" : ""}> <b>Tous les sites</b> <span class="muted">(${SITES.length})</span></label>
      <label class="check"><input type="radio" name="scope" value="some" ${allMode ? "" : "checked"}> <b>Seulement certains sites</b></label>
      <div class="picks" id="picks" ${allMode ? "hidden" : ""}>
        ${SITES.map((s) => `<label class="check"><input type="checkbox" value="${esc(s.id)}" ${pre.has(s.id) ? "checked" : ""}> ${esc(s.name)} ${s.maintenance ? `<span class="tag">en maintenance</span>` : ""}</label>`).join("")}
      </div>
      <label class="field"><span>Message affiché aux visiteurs</span>
        <textarea name="message" maxlength="1000" placeholder="Le site est momentanément fermé pour une opération de maintenance. Tout revient à la normale dès la fin de l'intervention.">${esc(first?.maintenance_message || "")}</textarea>
        <span class="hint">Facultatif. Vide : message par défaut.</span>
      </label>
      <label class="field"><span>Fin estimée</span>
        <input type="datetime-local" name="until" value="${esc(toLocalInput(first?.maintenance_until))}">
        <span class="quick">${[[30, "+30 min"], [60, "+1 h"], [120, "+2 h"], [240, "+4 h"]].map(([m, l]) => `<button type="button" class="btn ghost sm" data-add="${m}">${l}</button>`).join("")}<button type="button" class="btn ghost sm" data-add="0">Sans estimation</button></span>
      </label>
      <div class="actions">
        <button class="btn danger" id="off">Terminer la maintenance</button>
        <button class="btn" id="on">Activer la maintenance</button>
      </div>
    </div>`);
  const picks = $("#picks", modal);
  for (const r of $$("input[name=scope]", modal)) r.onchange = () => { picks.hidden = r.value === "all" && r.checked; };
  for (const b of $$("[data-add]", modal)) b.onclick = () => {
    const m = Number(b.dataset.add);
    $("input[name=until]", modal).value = m ? toLocalInput(new Date(Date.now() + m * 60000).toISOString()) : "";
  };
  const submit = (enabled) => async (e) => {
    const scopeAll = $("input[name=scope]:checked", modal).value === "all";
    const ids = scopeAll ? "all" : $$("#picks input:checked", modal).map((c) => c.value);
    if (!scopeAll && !ids.length) return toast("Choisis au moins un site", true);
    const n = scopeAll ? SITES.length : ids.length;
    if (enabled && scopeAll && !confirm(`Mettre les ${n} sites en maintenance ? Les visiteurs ne pourront plus y accéder.`)) return;
    await busy(e.target, async () => {
      const untilVal = $("input[name=until]", modal).value;
      const r = await api("POST", "/api/maintenance", {
        sites: ids,
        enabled,
        message: $("textarea[name=message]", modal).value,
        until: untilVal ? new Date(untilVal).toISOString() : null,
      });
      SITES = r.sites;
      CONFIG.edge_status = r.edge_status;
      closeModal();
      const label = enabled ? `Maintenance activée (${n} site${n > 1 ? "s" : ""})` : `Maintenance terminée (${n} site${n > 1 ? "s" : ""})`;
      if (CONFIG.edge && !r.published) toast(`${label}, mais la publication vers Cloudflare a échoué : ${r.edge_status.error}`, true);
      else toast(CONFIG.edge ? `${label} · visible en ligne d'ici 30 à 60 s` : `${label} (Cloudflare non relié : aucun effet pour les visiteurs)`);
      after?.();
    });
  };
  $("#on", modal).onclick = submit(true);
  $("#off", modal).onclick = submit(false);
}

// ---------- modales ----------
function openModal(html) {
  closeModal();
  const o = document.createElement("div");
  o.className = "overlay";
  o.innerHTML = `<div class="modal" role="dialog" aria-modal="true">${html}</div>`;
  o.addEventListener("click", (e) => { if (e.target === o || e.target.closest("[data-close]")) closeModal(); });
  document.body.append(o);
  $("input:not([type=radio]):not([type=checkbox]), textarea", o)?.focus();
  return $(".modal", o);
}
const closeModal = () => $(".overlay")?.remove();
addEventListener("keydown", (e) => { if (e.key === "Escape") closeModal(); });

function siteForm(s = {}) {
  return `
    <div class="row">
      <label class="field"><span>Nom</span><input name="name" required maxlength="80" value="${esc(s.name)}" placeholder="Unclaim Chat"></label>
      <label class="field"><span>Identifiant</span><input name="id" ${s.id && s.created_at ? "disabled" : "required"} pattern="[a-z0-9][a-z0-9-]{1,31}" value="${esc(s.id)}" placeholder="chat"></label>
    </div>
    <label class="field"><span>Description</span><input name="description" maxlength="300" value="${esc(s.description)}" placeholder="Chat de support multi-sites"></label>
    <div class="row">
      <label class="field"><span>Adresse publique</span><input name="public_url" type="url" value="${esc(s.public_url)}" placeholder="https://chat.unclaim.fr"></label>
      <label class="field"><span>Noms d'hôte servis</span><input name="hosts" value="${esc((s.hosts || []).join(", "))}" placeholder="chat.unclaim.fr"><span class="hint">Séparés par des virgules. Le Worker reconnaît le site par ces noms.</span></label>
    </div>
    <div class="row">
      <label class="field"><span>Serveur Pelican</span><input name="pelican_server" value="${esc(s.pelican_server)}" placeholder="1a2b3c4d"><span class="hint">Identifiant court du serveur (dans l'URL du panel Pelican).</span></label>
      <label class="field"><span>Adresse de test (facultative)</span><input name="health_url" type="url" value="${esc(s.health_url)}" placeholder="https://chat.unclaim.fr/health"><span class="hint">Vide : l'adresse publique.</span></label>
    </div>
    <div class="row">
      <label class="field"><span>Configuration</span><select name="env_mode">${Object.entries(ENV_MODE).map(([k, l]) => `<option value="${k}" ${(s.env_mode || "both") === k ? "selected" : ""}>${l}</option>`).join("")}</select></label>
      <label class="field"><span>Fichier .env</span><input name="env_file" value="${esc(s.env_file || "/.env")}"></label>
    </div>
    <div class="row">
      <label class="field"><span>Contacts (équipe)</span><input name="contacts" value="${esc((s.contacts || []).join(", "))}" placeholder="tom@unclaim.fr"><span class="hint">Responsables du site. Visibles par le staff seulement.</span></label>
      <label class="field"><span>Email public</span><input name="support_email" type="email" value="${esc(s.support_email)}" placeholder="support@unclaim.fr"><span class="hint">Affiché aux visiteurs sur les pages d'erreur et de maintenance.</span></label>
    </div>
    <span class="label" style="margin-top:8px">Surveillance — ce qui compte comme « joignable »</span>
    <div class="row3">
      <label class="field"><span>Codes HTTP acceptés</span><input name="health_expect" value="${esc(s.health_expect || "200-399")}" placeholder="200-399"><span class="hint">Ex. 200-399 ou 200,204.</span></label>
      <label class="field"><span>Texte attendu (facultatif)</span><input name="health_keyword" value="${esc(s.health_keyword)}" placeholder="Unclaim"><span class="hint">Doit apparaître dans la page.</span></label>
      <label class="field"><span>Délai max (s)</span><input name="health_timeout" type="number" min="2" max="60" value="${esc(s.health_timeout || 8)}"></label>
    </div>
    <span class="label" style="margin-top:8px">Page de statut publique</span>
    <label class="check"><input type="checkbox" name="status_public" ${s.status_public === 0 ? "" : "checked"}> Afficher ce site sur la page de statut</label>
    <div class="row3">
      <label class="field"><span>Nom public</span><input name="public_name" maxlength="80" value="${esc(s.public_name)}" placeholder="${esc(s.name || "Nom du site")}"></label>
      <label class="field"><span>Groupe</span><input name="status_group" maxlength="60" value="${esc(s.status_group)}" placeholder="Services, Jeux…"></label>
      <label class="field"><span>Description publique</span><input name="public_description" maxlength="200" value="${esc(s.public_description)}" placeholder="Site vitrine"></label>
    </div>`;
}
const formData = (el) => Object.fromEntries($$("input[name], select[name], textarea[name]", el).filter((i) => !i.disabled)
  .map((i) => [i.name, i.type === "checkbox" ? i.checked : i.value]));

function siteModal(prefill) {
  const modal = openModal(`
    <header><div><span class="label">Nouveau site</span><h2>Ajouter un site</h2></div><button class="icon-btn" data-close aria-label="Fermer">✕</button></header>
    <form class="form" id="f">${siteForm(prefill || {})}
      <div class="actions"><button type="button" class="btn ghost" data-close>Annuler</button><button class="btn">Ajouter</button></div>
    </form>`);
  $("#f", modal).onsubmit = (e) => {
    e.preventDefault();
    busy(e.submitter, async () => {
      const r = await api("POST", "/api/sites", formData(e.target));
      closeModal();
      toast(`${r.site.name} ajouté`);
      go(`/sites/${r.site.id}`);
    });
  };
}

async function importModal() {
  const modal = openModal(`
    <header><div><span class="label">Pelican</span><h2>Importer des serveurs</h2></div><button class="icon-btn" data-close aria-label="Fermer">✕</button></header>
    <div id="list"><p class="muted">Lecture des serveurs Pelican…</p></div>`);
  try {
    const { servers } = await api("GET", "/api/pelican/servers");
    $("#list", modal).innerHTML = servers.length ? `<table class="vars"><thead><tr><th>Serveur</th><th>Identifiant</th><th></th></tr></thead><tbody>
      ${servers.map((s, i) => `<tr><td><b>${esc(s.name)}</b><div class="vname">${esc(s.description)}</div></td><td class="key">${esc(s.identifier)}</td>
        <td style="text-align:right">${s.site_id ? `<span class="tag">déjà relié : ${esc(s.site_id)}</span>` : `<button class="btn ghost sm" data-i="${i}">Ajouter</button>`}</td></tr>`).join("")}
      </tbody></table>` : `<p class="muted">Aucun serveur visible avec cette clé.</p>`;
    for (const b of $$("[data-i]", modal)) b.onclick = () => {
      const s = servers[Number(b.dataset.i)];
      const slug = s.name.toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 32);
      siteModal({ name: s.name, id: slug, description: s.description, pelican_server: s.identifier });
    };
  } catch (e) {
    $("#list", modal).innerHTML = `<div class="banner bad"><div><b>Lecture impossible</b><span class="muted">${esc(e.message)}</span></div></div>`;
  }
}

// ---------- historique de disponibilité ----------
const siteWithUptime = (r) => ({ ...r.site, uptime_days: r.uptime });
const pctFr = (r) => (r == null ? "—" : `${(Math.floor(r * 10000) / 100).toLocaleString("fr-FR", { minimumFractionDigits: 2 })} %`);
function uptimeBars(days) {
  if (!days?.length) return "";
  const cls = (x) => x.r === null ? (x.maint ? "maint" : "none") : x.r < 0.95 ? "bad" : x.r < 0.999 || x.deg ? "warn" : "ok";
  let ok = 0, n = 0;
  for (const x of days) if (x.r !== null) { const t = x.down + x.deg + 1; ok += x.r * t; n += t; }
  const title = (x) => `${new Date(`${x.d}T12:00:00Z`).toLocaleDateString("fr-FR", { day: "numeric", month: "short" })} · ${x.r === null ? (x.maint ? "maintenance" : "pas de mesure") : `${pctFr(x.r)}${x.ms ? ` · ${x.ms} ms en moyenne` : ""}`}`;
  return `<div class="ubars">${days.map((x) => `<i class="${cls(x)}" title="${esc(title(x))}"></i>`).join("")}</div>
    <div class="uaxis"><span>${days.length} jours</span><span>≈ ${pctFr(n ? ok / n : null)} de disponibilité</span><span>Aujourd'hui</span></div>`;
}

// ---------- page de statut publique : incidents et réglages ----------
const INC_STATUS = { investigating: "Enquête en cours", identified: "Cause identifiée", monitoring: "Surveillance", resolved: "Résolu" };
const INC_IMPACT = { minor: "Mineur", major: "Majeur", critical: "Critique" };
const OVERALL_LABEL = { operational: ["Tous les services sont opérationnels", "online"], degraded: ["Certains services sont perturbés", "degraded"], partial: ["Panne partielle", "down"], major: ["Panne majeure", "down"], maintenance: ["Maintenance en cours", "maintenance"] };

async function viewStatus() {
  const main = shell("statut");
  document.title = "Statut · Unclaim Control";
  main.innerHTML = `<p class="boot">Chargement…</p>`;
  if (!SITES.length) await busy(null, loadSites);

  const draw = async () => {
    const r = await api("GET", "/api/status");
    const st = r.settings;
    const [ovText, ovCls] = OVERALL_LABEL[r.overall] || OVERALL_LABEL.operational;
    const open = r.incidents.filter((i) => i.status !== "resolved");
    const done = r.incidents.filter((i) => i.status === "resolved");
    const siteName = (id) => SITES.find((s) => s.id === id)?.name || id;
    const card = (i) => `
      <article class="card inc" data-id="${i.id}">
        <div class="inc-head"><div><h3>${esc(i.title)}</h3>
          <div class="muted small">${i.sites.map(siteName).map(esc).join(", ") || "Aucun site précisé"} · ouvert ${esc(dateFr(i.created_at))}${i.auto ? ` · <span class="tag">automatique</span>` : ""}</div></div>
          <div class="toolbar"><span class="chip s-${i.status === "resolved" ? "online" : i.impact === "minor" ? "degraded" : "down"}">${esc(INC_STATUS[i.status])}</span>
          ${i.status !== "resolved" ? `<button class="btn sm" data-upd="${i.id}">Mettre à jour</button>` : ""}
          ${isSuper() ? `<button class="icon-btn" data-del="${i.id}" title="Supprimer">✕</button>` : ""}</div></div>
        <ol class="timeline">${i.updates.map((u) => `<li><b>${esc(INC_STATUS[u.status])}</b> <span class="muted small">${esc(dateFr(u.created_at))} · ${esc(u.author || "surveillance automatique")}</span><p>${esc(u.body)}</p></li>`).join("")}</ol>
      </article>`;
    main.innerHTML = `
      <div class="head">
        <div><h1>Page de statut</h1><p class="sub">Publique sur <a href="https://${esc(st.host)}" target="_blank" rel="noopener">${esc(st.host || "—")}</a> · mise à jour automatiquement à chaque changement d'état.</p></div>
        <div class="toolbar"><a class="btn ghost" href="/status" target="_blank">Voir la page</a><button class="btn ghost" id="pub">Republier</button><button class="btn" id="new">Déclarer un incident</button></div>
      </div>
      ${CONFIG.edge ? "" : `<div class="banner"><div><b>Cloudflare n'est pas relié</b><span class="muted">La page n'est visible qu'ici, sur /status du panneau, tant que CF_API_TOKEN, CF_ACCOUNT_ID et CF_KV_NAMESPACE_ID ne sont pas renseignés.</span></div></div>`}
      <div class="banner ${ovCls === "online" ? "" : ovCls === "down" ? "bad" : "on"}" style="border-left-color:var(--${ovCls === "online" ? "ok" : ovCls === "degraded" ? "warn" : ovCls === "down" ? "danger" : "accent"})"><div><b>Ce que voient les visiteurs : ${esc(ovText)}</b></div></div>
      <h2 style="margin:26px 0 12px">Incidents en cours <span class="tag">${open.length}</span></h2>
      ${open.map(card).join("") || `<div class="empty">Aucun incident en cours.</div>`}
      ${done.length ? `<h2 style="margin:30px 0 12px">Incidents résolus</h2>${done.slice(0, 15).map(card).join("")}` : ""}
      ${isSuper() ? `
      <h2 style="margin:30px 0 12px">Réglages de la page</h2>
      <section class="card"><form class="form" id="settings">
        <div class="row">
          <label class="field"><span>Titre</span><input name="title" maxlength="120" value="${esc(st.title)}"></label>
          <label class="field"><span>Nom d'hôte</span><input name="host" value="${esc(st.host)}" placeholder="status.unclaim.fr"><span class="hint">Doit être couvert par une route du Worker (DNS proxifié).</span></label>
        </div>
        <label class="field"><span>Introduction</span><textarea name="intro" maxlength="1000" placeholder="Retrouvez ici l'état en temps réel des services Unclaim.">${esc(st.intro)}</textarea></label>
        <label class="field"><span>Annonce (bandeau)</span><textarea name="announcement" maxlength="1000" placeholder="Facultatif : une info à mettre en avant en haut de la page.">${esc(st.announcement)}</textarea></label>
        <div class="row3">
          <label class="field"><span>Historique affiché</span><select name="history_days">${[30, 60, 90].map((d) => `<option value="${d}" ${Number(st.history_days) === d ? "selected" : ""}>${d} jours</option>`).join("")}</select></label>
          <label class="field"><span>Incident auto après (s)</span><input name="auto_delay" type="number" min="0" max="3600" value="${esc(st.auto_delay)}"><span class="hint">Durée de panne avant ouverture.</span></label>
          <div class="field" style="align-content:center;gap:10px">
            <label class="check"><input type="checkbox" name="auto_incidents" ${st.auto_incidents ? "checked" : ""}> Incidents automatiques</label>
            <label class="check"><input type="checkbox" name="show_latency" ${st.show_latency ? "checked" : ""}> Afficher les temps de réponse</label>
          </div>
        </div>
        <p class="hint">Les sites affichés, leur nom public, leur groupe et ce qui est testé se règlent dans les Réglages de chaque site.</p>
        <div class="actions"><button class="btn">Enregistrer</button></div>
      </form></section>` : ""}`;

    $("#new", main).onclick = () => incidentModal(null, draw);
    $("#pub", main).onclick = (e) => busy(e.target, async () => {
      if (!CONFIG.edge) return toast("Cloudflare n'est pas relié : rien à publier", true);
      await api("POST", "/api/status/publish");
      toast("Page de statut publiée");
    });
    for (const b of $$("[data-upd]", main)) b.onclick = () => incidentModal(r.incidents.find((i) => i.id === Number(b.dataset.upd)), draw);
    for (const b of $$("[data-del]", main)) b.onclick = () => {
      if (!confirm("Supprimer cet incident de la page de statut ?")) return;
      busy(b, async () => { await api("DELETE", `/api/incidents/${b.dataset.del}`); toast("Incident supprimé"); await draw(); });
    };
    const f = $("#settings", main);
    if (f) f.onsubmit = (e) => {
      e.preventDefault();
      busy(e.submitter, async () => {
        const d = formData(f);
        const res = await api("PUT", "/api/status/settings", { ...d, auto_delay: Number(d.auto_delay), history_days: Number(d.history_days) });
        toast(res.published || !CONFIG.edge ? "Réglages enregistrés" : "Réglages enregistrés, mais la publication Cloudflare a échoué", !res.published && CONFIG.edge);
        await draw();
      });
    };
  };
  await busy(null, draw);
}

function incidentModal(incident, after) {
  const isNew = !incident;
  const modal = openModal(`
    <header><div><span class="label">${isNew ? "Nouvel incident" : `Incident #${incident.id}`}</span><h2>${isNew ? "Déclarer un incident" : esc(incident.title)}</h2></div><button class="icon-btn" data-close aria-label="Fermer">✕</button></header>
    <form class="form" id="f">
      ${isNew ? `
      <label class="field"><span>Titre (public)</span><input name="title" required maxlength="160" placeholder="Connexion impossible sur le chat"></label>
      <div class="row">
        <label class="field"><span>Impact</span><select name="impact">${Object.entries(INC_IMPACT).map(([k, l]) => `<option value="${k}">${l}</option>`).join("")}</select></label>
        <label class="field"><span>État</span><select name="status">${Object.entries(INC_STATUS).filter(([k]) => k !== "resolved").map(([k, l]) => `<option value="${k}">${l}</option>`).join("")}</select></label>
      </div>
      <div class="field"><span>Sites concernés</span><div class="picks">${SITES.map((s) => `<label class="check"><input type="checkbox" value="${esc(s.id)}"> ${esc(s.name)}</label>`).join("")}</div></div>` : `
      <label class="field"><span>Nouvel état</span><select name="status">${Object.entries(INC_STATUS).map(([k, l]) => `<option value="${k}" ${k === incident.status ? "selected" : ""}>${l}</option>`).join("")}</select></label>`}
      <label class="field"><span>Message public</span><textarea name="body" required maxlength="4000" placeholder="${isNew ? "Nous enquêtons sur des difficultés de connexion au chat." : "Le correctif est déployé, nous surveillons la situation."}"></textarea><span class="hint">Visible par tout le monde sur la page de statut.</span></label>
      <div class="actions"><button type="button" class="btn ghost" data-close>Annuler</button><button class="btn">${isNew ? "Publier l'incident" : "Publier la mise à jour"}</button></div>
    </form>`);
  $("#f", modal).onsubmit = (e) => {
    e.preventDefault();
    busy(e.submitter, async () => {
      const d = formData(e.target);
      if (isNew) await api("POST", "/api/incidents", { title: d.title, impact: d.impact, status: d.status, body: d.body, sites: $$(".picks input:checked", modal).map((c) => c.value) });
      else await api("POST", `/api/incidents/${incident.id}/updates`, { status: d.status, body: d.body });
      closeModal();
      toast(isNew ? "Incident publié" : "Mise à jour publiée");
      await after();
    });
  };
}

// ---------- page d'un site ----------
async function viewSite(id) {
  const main = shell("sites");
  let site;
  try { site = siteWithUptime(await api("GET", `/api/sites/${id}`)); }
  catch (e) { main.innerHTML = `<a class="crumb" href="/" data-nav>← Sites</a><div class="empty"><h3>${esc(e.message)}</h3></div>`; return; }
  document.title = `${site.name} · Unclaim Control`;
  const tabs = [["apercu", "Aperçu"]];
  if (isSuper()) tabs.push(["variables", "Variables"], ["config", "Réglages"]);
  tabs.push(["journal", "Journal"]);
  let tab = location.hash.slice(1);
  if (!tabs.some(([k]) => k === tab)) tab = "apercu";

  const head = () => `
    <a class="crumb" href="/" data-nav>← Sites</a>
    <div class="head">
      <div><h1>${esc(site.name)}</h1><p class="sub">${chip(site.status)} <span>${esc(site.status_detail)}</span></p></div>
      <div class="toolbar">
        <button class="btn ghost" data-act="check">Vérifier</button>
        ${site.pelican_server ? `
          ${site.pelican_state === "offline" ? `<button class="btn ghost" data-act="start">Démarrer</button>` : `<button class="btn ghost" data-act="restart">Redémarrer</button>`}
          ${isSuper() && site.pelican_state !== "offline" ? `<button class="btn danger" data-act="stop">Arrêter</button>` : ""}` : ""}
        <button class="btn${site.maintenance ? " danger" : ""}" data-act="maint">${site.maintenance ? "Terminer la maintenance" : "Maintenance…"}</button>
      </div>
    </div>
    ${site.maintenance ? `<div class="banner on"><div><b>En maintenance depuis ${esc(dateFr(site.maintenance_since))}</b><span class="muted">${site.maintenance_until ? `Fin estimée : ${esc(dateFr(site.maintenance_until))}. ` : ""}${esc(site.maintenance_message || "Message par défaut.")}</span></div></div>` : ""}
    <nav class="subtabs">${tabs.map(([k, l]) => `<button data-tab="${k}" class="${k === tab ? "on" : ""}">${l}</button>`).join("")}</nav>
    <div id="pane"></div>`;

  const draw = () => {
    main.innerHTML = head();
    for (const b of $$("[data-tab]", main)) b.onclick = () => { tab = b.dataset.tab; history.replaceState(null, "", `#${tab}`); draw(); };
    for (const b of $$("[data-act]", main)) b.onclick = () => act(b);
    const pane = $("#pane", main);
    const fn = { apercu: paneOverview, variables: paneVariables, config: paneConfig, journal: paneJournal }[tab];
    busy(null, async () => fn(pane, site, reload));
  };
  const reload = async () => { site = siteWithUptime(await api("GET", `/api/sites/${id}`)); draw(); };

  const act = (b) => {
    const a = b.dataset.act;
    if (a === "maint") {
      if (!site.maintenance) return maintenanceModal([site.id], reload);
      return busy(b, async () => {
        const r = await api("POST", "/api/maintenance", { sites: [site.id], enabled: false });
        SITES = r.sites;
        toast(r.published || !CONFIG.edge ? "Maintenance terminée" : `Maintenance terminée, mais Cloudflare n'a pas été mis à jour : ${r.edge_status.error}`, !r.published && CONFIG.edge);
        await reload();
      });
    }
    if (a === "check") return busy(b, async () => { site = (await api("POST", `/api/sites/${id}/check`)).site; draw(); toast("Vérifié"); });
    const label = { start: "démarrer", restart: "redémarrer", stop: "arrêter" }[a];
    if (!confirm(`Voulez-vous vraiment ${label} ${site.name} ?`)) return;
    busy(b, async () => {
      await api("POST", `/api/sites/${id}/power`, { signal: a });
      toast(`Ordre envoyé à Pelican : ${label}. Nouvelle vérification dans quelques secondes.`);
      setTimeout(() => reload().catch(() => {}), 9000);
    });
  };
  draw();
  refreshTimer = setInterval(() => { if (!document.hidden && tab === "apercu" && !$(".overlay")) reload().catch(() => {}); }, 30_000);
}

function paneOverview(pane, s) {
  const r = s.resources;
  pane.innerHTML = `
    <div class="grid2">
      <section class="card"><h3>Site</h3><dl class="kv">
        <dt>Adresse</dt><dd>${s.public_url ? `<a href="${esc(s.public_url)}" target="_blank" rel="noopener">${esc(s.public_url)}</a>` : "—"}</dd>
        <dt>Noms d'hôte</dt><dd class="mono">${esc(s.hosts.join(", ") || "—")}</dd>
        <dt>Description</dt><dd>${esc(s.description || "—")}</dd>
        <dt>Contacts</dt><dd>${s.contacts.map((c) => `<a href="mailto:${esc(c)}">${esc(c)}</a>`).join("<br>") || "—"}</dd>
        <dt>Email public</dt><dd>${esc(s.support_email || "par défaut")}</dd>
      </dl></section>
      <section class="card"><h3>Surveillance</h3><dl class="kv">
        <dt>État</dt><dd>${chip(s.status)} <span class="muted small">depuis ${esc(ago(s.status_since))}</span></dd>
        <dt>Dernier test</dt><dd>${s.checked_at ? `${esc(ago(s.checked_at))} · ${s.http_code ? `HTTP ${s.http_code} en ${s.latency_ms} ms` : "pas de réponse"}` : "jamais"}</dd>
        <dt>Adresse testée</dt><dd class="mono">${esc(s.health_url || s.public_url || "—")}</dd>
        <dt>Serveur Pelican</dt><dd>${s.pelican_server ? `<span class="mono">${esc(s.pelican_server)}</span> · ${esc(PELICAN_STATE[s.pelican_state] || s.pelican_state || "état inconnu")}${CONFIG.pelican_url ? ` · <a href="${esc(CONFIG.pelican_url)}/server/${esc(s.pelican_server)}" target="_blank" rel="noopener">ouvrir</a>` : ""}` : "non relié"}</dd>
        ${r ? `<dt>Ressources</dt><dd>${bytes(r.memory_bytes)} de RAM · ${r.cpu != null ? r.cpu.toFixed(1) : "—"} % CPU · ${bytes(r.disk_bytes)} de disque</dd>
        <dt>Allumé depuis</dt><dd>${duration(r.uptime_ms)}</dd>` : ""}
      </dl></section>
    </div>
    ${s.uptime_days ? `<section class="card" style="margin-top:16px"><h3>Disponibilité ${s.status_public === 0 ? `<span class="tag">masqué de la page de statut</span>` : ""}</h3>${uptimeBars(s.uptime_days)}</section>` : ""}
    <section class="card" style="margin-top:16px"><h3>Pages vues par les visiteurs</h3>
      <p class="muted" style="margin-bottom:12px">Servies par le Worker Cloudflare devant ${esc(s.hosts[0] || "le site")}, même quand le serveur est éteint.</p>
      <div class="toolbar">
        <a class="btn ghost sm" href="/preview/maintenance/${esc(s.id)}" target="_blank">Aperçu : maintenance</a>
        <a class="btn ghost sm" href="/preview/error/${esc(s.id)}?code=521" target="_blank">Aperçu : serveur éteint (521)</a>
        <a class="btn ghost sm" href="/preview/error/${esc(s.id)}?code=522" target="_blank">Aperçu : délai dépassé (522)</a>
        <a class="btn ghost sm" href="/preview/error/${esc(s.id)}?code=502" target="_blank">Aperçu : application plantée (502)</a>
      </div>
    </section>`;
}

function paneConfig(pane, s, reload) {
  pane.innerHTML = `
    <section class="card"><form class="form" id="f">${siteForm(s)}
      <div class="actions"><button type="button" class="btn danger" id="del" style="margin-right:auto">Supprimer le site</button><button class="btn">Enregistrer</button></div>
    </form></section>`;
  $("#f", pane).onsubmit = (e) => {
    e.preventDefault();
    busy(e.submitter, async () => { await api("PATCH", `/api/sites/${s.id}`, formData(e.target)); toast("Réglages enregistrés"); await reload(); });
  };
  $("#del", pane).onclick = (e) => {
    if (prompt(`Pour retirer ${s.name} du panneau (le serveur Pelican n'est pas touché), tape son identifiant : ${s.id}`) !== s.id) return;
    busy(e.target, async () => { await api("DELETE", `/api/sites/${s.id}`); toast("Site retiré"); go("/"); });
  };
}

async function paneJournal(pane, s) {
  pane.innerHTML = `<p class="muted">Chargement…</p>`;
  const { entries } = await api("GET", s ? `/api/sites/${s.id}/audit` : "/api/audit");
  pane.innerHTML = entries.length ? `<table class="table"><thead><tr><th>Quand</th><th>Qui</th><th>Action</th>${s ? "" : "<th>Site</th>"}<th class="hide-m">Détail</th></tr></thead><tbody>
    ${entries.map((e) => `<tr><td class="mono" title="${esc(e.at)}">${esc(dateFr(e.at))}</td><td>${esc(e.user_name)}</td><td>${esc(e.action)}</td>${s ? "" : `<td>${e.site_id ? `<a href="/sites/${esc(e.site_id)}" data-nav>${esc(e.site_id)}</a>` : "—"}</td>`}<td class="hide-m muted">${esc(e.detail)}</td></tr>`).join("")}
  </tbody></table>` : `<div class="empty">Rien pour l'instant.</div>`;
}

// ---------- variables d'environnement ----------
async function paneVariables(pane, s) {
  if (!s.pelican_server) { pane.innerHTML = `<div class="empty"><h3>Aucun serveur Pelican relié</h3><p>Indique l'identifiant du serveur dans Réglages.</p></div>`; return; }
  if (s.env_mode === "none") { pane.innerHTML = `<div class="empty"><h3>Configuration désactivée pour ce site</h3><p>Change le mode dans Réglages.</p></div>`; return; }
  pane.innerHTML = `<p class="muted">Lecture de la configuration sur Pelican…</p>`;
  let env;
  try { env = await api("GET", `/api/sites/${s.id}/env`); }
  catch (e) { pane.innerHTML = `<div class="banner bad"><div><b>Lecture impossible</b><span class="muted">${esc(e.message)}</span></div></div>`; return; }

  const startupKeys = new Set((env.startup?.variables || []).map((v) => v.key));
  const shown = new Set();
  const secretInput = (attrs, value, secret, disabled) =>
    `<div class="val"><input ${attrs} type="${secret ? "password" : "text"}" value="${esc(value)}" ${disabled ? "disabled" : ""} autocomplete="off" spellcheck="false">${secret ? `<button type="button" class="icon-btn" data-eye title="Afficher / masquer">👁</button>` : ""}</div>`;

  pane.innerHTML = `
    <div class="banner"><div><b>Les modifications s'appliquent au prochain démarrage du serveur</b><span class="muted">Coche « Redémarrer ensuite » pour les appliquer tout de suite. Chaque enregistrement est inscrit au journal (noms des variables seulement, jamais les valeurs).</span></div></div>
    ${env.startup ? `<section class="card" id="startup" style="margin-bottom:16px"><h3>Variables de démarrage Pelican <span class="tag">${env.startup.variables?.length ?? 0}</span></h3>
      ${env.startup.error ? `<p class="muted">${esc(env.startup.error)}</p>` : `
      <p class="hint" style="margin-bottom:10px">Définies par l'œuf ; elles l'emportent sur le fichier .env. Les variables verrouillées ne se modifient que dans l'administration Pelican.</p>
      <table class="vars"><thead><tr><th>Variable</th><th>Valeur</th></tr></thead><tbody>
        ${env.startup.variables.map((v) => `<tr data-key="${esc(v.key)}"><td><div class="key">${esc(v.key)} ${v.editable ? "" : `<span class="tag">verrouillée</span>`}</div><div class="vname" title="${esc(v.description)}">${esc(v.name)}</div></td>
          <td>${secretInput(`data-orig="${esc(v.value)}" placeholder="${esc(v.default ? `défaut : ${v.default}` : "")}"`, v.value, v.secret, !v.editable)}</td></tr>`).join("")}
      </tbody></table>
      <div class="savebar"><label class="check"><input type="checkbox" class="restart"> Redémarrer ensuite</label><button class="btn" id="save-startup" disabled>Enregistrer</button></div>`}
    </section>` : ""}
    ${env.dotenv ? `<section class="card" id="dotenv"><h3><span>Fichier <span class="mono">${esc(env.dotenv.file)}</span></span><span class="toolbar"><button class="btn ghost sm" id="rawmode">Texte brut</button></span></h3>
      ${env.dotenv.error ? `<p class="muted">${esc(env.dotenv.error)}</p>` : `
      ${env.dotenv.exists ? "" : `<p class="hint" style="margin-bottom:10px">Le fichier n'existe pas encore : il sera créé au premier enregistrement.</p>`}
      <div id="table-mode"><table class="vars"><thead><tr><th>Variable</th><th>Valeur</th><th></th></tr></thead><tbody id="rows"></tbody></table>
        <button class="btn ghost sm" id="addrow" style="margin-top:10px">+ Ajouter une variable</button></div>
      <div id="raw-mode" hidden><textarea class="code" spellcheck="false">${esc(env.dotenv.raw)}</textarea><p class="hint">Le fichier est réécrit tel quel. Les commentaires sont conservés.</p></div>
      <div class="savebar"><label class="check"><input type="checkbox" class="restart"> Redémarrer ensuite</label><button class="btn" id="save-dotenv" disabled>Enregistrer</button></div>`}
    </section>` : ""}`;

  pane.addEventListener("click", (e) => {
    const eye = e.target.closest("[data-eye]");
    if (!eye) return;
    const input = eye.previousElementSibling;
    input.type = input.type === "password" ? "text" : "password";
  });

  // --- variables de démarrage ---
  const st = $("#startup", pane);
  if (st && !env.startup.error) {
    const changes = () => Object.fromEntries($$("tr[data-key]", st).map((tr) => [tr.dataset.key, $("input", tr)]).filter(([, i]) => !i.disabled && i.value !== i.dataset.orig).map(([k, i]) => [k, i.value]));
    st.addEventListener("input", () => {
      for (const tr of $$("tr[data-key]", st)) { const i = $("input", tr); tr.classList.toggle("changed", i.value !== i.dataset.orig); }
      $("#save-startup", st).disabled = !Object.keys(changes()).length;
    });
    $("#save-startup", st).onclick = (e) => busy(e.target, async () => {
      const c = changes();
      const restart = $(".restart", st).checked;
      await api("PUT", `/api/sites/${s.id}/env/startup`, { changes: c, restart });
      toast(`${Object.keys(c).length} variable(s) enregistrée(s)${restart ? ", redémarrage lancé" : ""}`);
      for (const tr of $$("tr[data-key]", st)) { const i = $("input", tr); i.dataset.orig = i.value; tr.classList.remove("changed"); }
      e.target.disabled = true;
    });
  }

  // --- fichier .env ---
  const de = $("#dotenv", pane);
  if (de && !env.dotenv.error) {
    let rows = env.dotenv.entries.map((x) => ({ key: x.key, value: x.value, orig: x.value, secret: x.secret, removed: false, fresh: false }));
    let raw = false;
    const textarea = $("#raw-mode textarea", de);
    const dirty = () => raw ? textarea.value !== env.dotenv.raw : rows.some((r) => r.removed || r.fresh || r.value !== r.orig);
    const sync = () => { $("#save-dotenv", de).disabled = !dirty(); };
    const drawRows = () => {
      $("#rows", de).innerHTML = rows.map((r, i) => `
        <tr data-i="${i}" class="${r.removed ? "removed" : r.fresh || r.value !== r.orig ? "changed" : ""}">
          <td>${r.fresh ? `<input class="k" value="${esc(r.key)}" placeholder="NOM_DE_VARIABLE" spellcheck="false">` : `<div class="key">${esc(r.key)}</div>`}
            ${startupKeys.has(r.key) ? `<span class="tag warn" title="Une variable de démarrage Pelican du même nom l'emporte sur cette ligne.">écrasée par Pelican</span>` : ""}</td>
          <td>${secretInput(`class="v"`, r.value, r.secret && !shown.has(i), r.removed)}</td>
          <td style="width:40px;text-align:right"><button type="button" class="icon-btn" data-rm title="${r.removed ? "Rétablir" : "Supprimer"}">${r.removed ? "↺" : "✕"}</button></td>
        </tr>`).join("") || `<tr><td colspan="3" class="muted">Aucune variable.</td></tr>`;
      sync();
    };
    $("#rows", de).addEventListener("input", (e) => {
      const tr = e.target.closest("tr[data-i]");
      const r = rows[Number(tr.dataset.i)];
      if (e.target.classList.contains("k")) r.key = e.target.value.trim();
      if (e.target.classList.contains("v")) r.value = e.target.value;
      tr.className = r.removed ? "removed" : r.fresh || r.value !== r.orig ? "changed" : "";
      sync();
    });
    $("#rows", de).addEventListener("click", (e) => {
      if (!e.target.closest("[data-rm]")) return;
      const i = Number(e.target.closest("tr").dataset.i);
      if (rows[i].fresh) rows.splice(i, 1); else rows[i].removed = !rows[i].removed;
      drawRows();
    });
    $("#addrow", de).onclick = () => { rows.push({ key: "", value: "", orig: null, secret: false, removed: false, fresh: true }); drawRows(); $$("#rows input.k", de).at(-1)?.focus(); };
    textarea.oninput = sync;
    $("#rawmode", de).onclick = (e) => {
      if (dirty() && !confirm("Les modifications non enregistrées seront perdues. Continuer ?")) return;
      raw = !raw;
      textarea.value = env.dotenv.raw;
      rows = rows.filter((r) => !r.fresh).map((r) => ({ ...r, value: r.orig, removed: false }));
      $("#table-mode", de).hidden = raw;
      $("#raw-mode", de).hidden = !raw;
      e.target.textContent = raw ? "Tableau" : "Texte brut";
      drawRows();
    };
    $("#save-dotenv", de).onclick = (e) => busy(e.target, async () => {
      const restart = $(".restart", de).checked;
      let payload;
      if (raw) payload = { raw: textarea.value, restart };
      else {
        const changes = {};
        for (const r of rows) {
          if (r.fresh && !r.key) continue;
          if (r.fresh && !/^[A-Za-z_][A-Za-z0-9_]*$/.test(r.key)) throw new ApiError(`Nom de variable invalide : ${r.key}`);
          if (r.removed) changes[r.key] = null;
          else if (r.fresh || r.value !== r.orig) changes[r.key] = r.value;
        }
        payload = { changes, restart };
      }
      const res = await api("PUT", `/api/sites/${s.id}/env/dotenv`, payload);
      env.dotenv.raw = res.raw;
      env.dotenv.exists = true;
      textarea.value = res.raw;
      rows = res.entries.map((x) => ({ key: x.key, value: x.value, orig: x.value, secret: x.secret, removed: false, fresh: false }));
      drawRows();
      toast(`${env.dotenv.file} enregistré${restart ? ", redémarrage lancé" : ""}`);
    });
    drawRows();
  }
}

// ---------- journal global ----------
async function viewJournal() {
  const main = shell("journal");
  document.title = "Journal · Unclaim Control";
  main.innerHTML = `<div class="head"><div><h1>Journal</h1><p class="sub">Connexions, maintenances, modifications et changements d'état, du plus récent au plus ancien.</p></div></div><div id="pane"></div>`;
  await busy(null, () => paneJournal($("#pane", main), null));
}

// ---------- staff ----------
async function viewStaff() {
  const main = shell("staff");
  document.title = "Staff · Unclaim Control";
  const draw = async () => {
    const r = await api("GET", "/api/staff");
    const person = (p) => `<div style="display:flex;gap:10px;align-items:center">${p.avatar_url ? `<img class="avatar" src="${esc(p.avatar_url)}" alt="">` : `<span class="avatar">${esc((p.name || "?").slice(0, 1))}</span>`}<div><b>${esc(p.name || "Jamais connecté")}</b><div class="mono muted">${esc(p.discord_id)}</div></div></div>`;
    main.innerHTML = `
      <div class="head"><div><h1>Staff</h1><p class="sub">Le staff voit l'état des sites, gère la maintenance et peut démarrer ou redémarrer un serveur. Seuls les super-admins voient et modifient les variables.</p></div></div>
      <div class="grid2">
        <section class="card"><h3>Super-admins <span class="tag">ADMIN_DISCORD_IDS</span></h3>
          <div class="form">${r.supers.map(person).join("") || `<p class="muted">Aucun.</p>`}</div>
          <p class="hint" style="margin-top:14px">Se modifie dans les variables du serveur du panneau.</p></section>
        <section class="card"><h3>Staff <span class="tag">${r.staff.length}</span></h3>
          <div class="form">
            ${r.staff.map((p) => `<div style="display:flex;justify-content:space-between;align-items:center;gap:10px">${person(p)}<span class="muted small">${esc(p.note)}</span><button class="btn danger sm" data-rm="${esc(p.discord_id)}">Retirer</button></div>`).join("") || `<p class="muted">Personne pour l'instant.</p>`}
            <form id="add" class="form" style="border-top:1px solid var(--line);padding-top:14px">
              <div class="row"><label class="field"><span>ID Discord</span><input name="discord_id" required pattern="\\d{15,22}" placeholder="1429078624056905731"></label>
              <label class="field"><span>Note</span><input name="note" maxlength="120" placeholder="Modération, support…"></label></div>
              <div class="actions"><button class="btn">Ajouter au staff</button></div>
            </form>
          </div></section>
      </div>`;
    $("#add", main).onsubmit = (e) => { e.preventDefault(); busy(e.submitter, async () => { await api("POST", "/api/staff", formData(e.target)); toast("Ajouté au staff"); await draw(); }); };
    for (const b of $$("[data-rm]", main)) b.onclick = () => {
      if (!confirm("Retirer cette personne du staff ? Sa session est fermée immédiatement.")) return;
      busy(b, async () => { await api("DELETE", `/api/staff/${b.dataset.rm}`); toast("Retiré du staff"); await draw(); });
    };
  };
  await busy(null, draw);
}

boot();
